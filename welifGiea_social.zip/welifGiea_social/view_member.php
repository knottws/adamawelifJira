<?php
require_once 'config.php';
requireLogin();

$id = $_GET['id'] ?? 0;

// Check if user has permission to view member
$roleAccess = getRoleAccess($pdo);
if ($_SESSION['user_role'] == 'member') {
    // Members can only view their own profile
    $currentUser = getCurrentUser($pdo);
    if ($currentUser['member_id'] != $id) {
        header('Location: dashboard.php');
        exit();
    }
} else {
    // Other roles need view_members permission
    $roleAccess->requirePermission('view_members');
}

// Get member details with comprehensive information
$stmt = $pdo->prepare("
    SELECT m.*,
           COUNT(DISTINCT fm.id) as total_family_members,
           COUNT(DISTINCT CASE WHEN fm.family_side = 'own' THEN fm.id END) as own_family_count,
           COUNT(DISTINCT CASE WHEN fm.family_side = 'wife' THEN fm.id END) as wife_family_count,
           COUNT(DISTINCT fa.id) as total_payments,
           COALESCE(SUM(fa.amount), 0) as total_contributions,
           MAX(fa.payment_date) as last_payment_date,
           COUNT(DISTINCT CASE WHEN cs.status = 'overdue' THEN cs.id END) as overdue_months,
           DATEDIFF(CURDATE(), m.registration_date) as membership_days,
           TIMESTAMPDIFF(YEAR, m.registration_date, CURDATE()) as membership_years,
           (SELECT COUNT(*) FROM users WHERE member_id = m.id) as has_user_account
    FROM members m
    LEFT JOIN family_members fm ON m.id = fm.member_id
    LEFT JOIN financial_activities fa ON m.id = fa.member_id
    LEFT JOIN contribution_schedule cs ON m.id = cs.member_id AND cs.status = 'overdue'
    WHERE m.id = ?
    GROUP BY m.id
");
$stmt->execute([$id]);
$member = $stmt->fetch();

if (!$member) {
    header('Location: members.php');
    exit();
}

// Get family members grouped by side
$family = [
    'own' => $pdo->prepare("
        SELECT * FROM family_members 
        WHERE member_id = ? AND family_side = 'own'
        ORDER BY 
            CASE relationship_category
                WHEN 'parent' THEN 1
                WHEN 'spouse' THEN 2
                WHEN 'child' THEN 3
                WHEN 'sibling' THEN 4
                ELSE 5
            END,
            specific_relationship
    ")->execute([$id])->fetchAll(),
    
    'wife' => $pdo->prepare("
        SELECT * FROM family_members 
        WHERE member_id = ? AND family_side = 'wife'
        ORDER BY relationship_category, specific_relationship
    ")->execute([$id])->fetchAll()
];

// Get payment history with details
$payments = $pdo->prepare("
    SELECT fa.*, 
           u.username as recorded_by_name,
           cs.status as schedule_status,
           cs.due_date,
           DATEDIFF(fa.payment_date, cs.due_date) as days_after_due
    FROM financial_activities fa
    LEFT JOIN contribution_schedule cs ON fa.member_id = cs.member_id 
        AND cs.year = fa.contribution_year 
        AND cs.month = fa.contribution_month
    LEFT JOIN users u ON fa.recorded_by = u.id
    WHERE fa.member_id = ?
    ORDER BY fa.payment_date DESC
");
$payments->execute([$id]);
$paymentHistory = $payments->fetchAll();

// Get payment summary by year
$yearlySummary = $pdo->prepare("
    SELECT 
        YEAR(payment_date) as year,
        COUNT(*) as payment_count,
        SUM(amount) as yearly_total,
        AVG(amount) as average_payment,
        MIN(amount) as min_payment,
        MAX(amount) as max_payment
    FROM financial_activities
    WHERE member_id = ?
    GROUP BY YEAR(payment_date)
    ORDER BY year DESC
");
$yearlySummary->execute([$id]);
$yearlyStats = $yearlySummary->fetchAll();

// Get contribution schedule
$schedule = $pdo->prepare("
    SELECT * FROM contribution_schedule 
    WHERE member_id = ?
    ORDER BY year DESC, month DESC
    LIMIT 12
");
$schedule->execute([$id]);
$contributionSchedule = $schedule->fetchAll();

// Get uploaded documents
$documents = $pdo->prepare("
    SELECT * FROM file_uploads 
    WHERE related_table = 'members' AND related_id = ?
    ORDER BY uploaded_at DESC
");
$documents->execute([$id]);
$memberDocuments = $documents->fetchAll();

// Get recent activity
$activities = $pdo->prepare("
    SELECT ual.*, u.username 
    FROM user_activity_log ual
    JOIN users u ON ual.user_id = u.id
    WHERE ual.description LIKE ? OR ual.module = 'members'
    ORDER BY ual.created_at DESC
    LIMIT 10
");
$activities->execute(['%' . $member['full_name'] . '%']);
$recentActivities = $activities->fetchAll();

// Calculate statistics
$stats = [
    'payment_rate' => $member['total_payments'] > 0 ? 
        round(($member['total_payments'] / max(12, $member['membership_months'] ?? 1)) * 100, 2) : 0,
    'average_payment' => $member['total_payments'] > 0 ? 
        $member['total_contributions'] / $member['total_payments'] : 0,
    'months_active' => $member['membership_days'] ? 
        round($member['membership_days'] / 30, 1) : 0,
    'compliance_score' => calculateComplianceScore($member, $paymentHistory)
];

function calculateComplianceScore($member, $payments) {
    $score = 100;
    
    // Deduct for overdue payments
    if ($member['overdue_months'] > 0) {
        $score -= min(30, $member['overdue_months'] * 10);
    }
    
    // Deduct for irregular payments
    $paymentDates = array_column($payments, 'payment_date');
    if (count($paymentDates) > 1) {
        $intervals = [];
        for ($i = 1; $i < count($paymentDates); $i++) {
            $intervals[] = abs(strtotime($paymentDates[$i]) - strtotime($paymentDates[$i-1])) / (30 * 24 * 60 * 60);
        }
        $avgInterval = array_sum($intervals) / count($intervals);
        if ($avgInterval > 1.5) {
            $score -= 20;
        }
    }
    
    return max(0, $score);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Profile - <?php echo htmlspecialchars($member['full_name']); ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .profile-header {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
        }
        
        .profile-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 300px;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            opacity: 0.05;
            clip-path: polygon(100% 0, 0% 100%, 100% 100%);
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
            font-weight: 700;
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
            border: 4px solid white;
        }
        
        .profile-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 15px;
            border-radius: 30px;
            font-size: 13px;
            font-weight: 600;
            margin-right: 10px;
        }
        
        .badge-active { background: #e8f5e9; color: #2e7d32; }
        .badge-inactive { background: #ffebee; color: #c62828; }
        .badge-premium { background: #fff3e0; color: #f57c00; }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }
        
        .stat-icon.blue { background: #e3f2fd; color: #1976d2; }
        .stat-icon.green { background: #e8f5e9; color: #2e7d32; }
        .stat-icon.orange { background: #fff3e0; color: #f57c00; }
        .stat-icon.purple { background: #f3e5f5; color: #7b1fa2; }
        
        .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 14px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .info-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }
        
        .family-tree {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .family-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .family-card.own { border-top: 4px solid #667eea; }
        .family-card.wife { border-top: 4px solid #f06292; }
        
        .family-member {
            display: flex;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
            transition: background 0.3s;
        }
        
        .family-member:hover {
            background: #f8f9fa;
        }
        
        .family-member:last-child {
            border-bottom: none;
        }
        
        .member-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            color: #666;
        }
        
        .member-details {
            flex: 1;
        }
        
        .member-name {
            font-weight: 600;
            color: #333;
        }
        
        .member-relation {
            font-size: 12px;
            color: #666;
        }
        
        .member-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
        }
        
        .badge-dependent { background: #fff3e0; color: #f57c00; }
        .badge-emergency { background: #ffebee; color: #c62828; }
        
        .payment-timeline {
            position: relative;
            padding: 20px 0;
        }
        
        .timeline-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 20px;
            position: relative;
        }
        
        .timeline-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #4CAF50;
            margin-right: 20px;
            margin-top: 5px;
            position: relative;
        }
        
        .timeline-dot.overdue { background: #f44336; }
        .timeline-dot.pending { background: #FF9800; }
        
        .timeline-content {
            flex: 1;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
        }
        
        .compliance-meter {
            width: 100%;
            height: 10px;
            background: #f0f0f0;
            border-radius: 5px;
            overflow: hidden;
            margin: 10px 0;
        }
        
        .compliance-fill {
            height: 100%;
            background: linear-gradient(90deg, #f44336, #FF9800, #4CAF50);
            border-radius: 5px;
            transition: width 0.3s;
        }
        
        .document-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .document-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .document-card:hover {
            background: #e3f2fd;
            transform: translateY(-2px);
        }
        
        .document-icon {
            font-size: 40px;
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .quick-actions {
            position: absolute;
            top: 30px;
            right: 30px;
            display: flex;
            gap: 10px;
        }
        
        .action-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: white;
            border: none;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .action-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .tab-container {
            margin-top: 30px;
        }
        
        .tabs {
            display: flex;
            gap: 10px;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 8px 8px 0 0;
            transition: all 0.3s;
        }
        
        .tab:hover {
            background: #f5f5f5;
        }
        
        .tab.active {
            background: #667eea;
            color: white;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <!-- Profile Header -->
            <div class="profile-header">
                <div style="display: flex; align-items: center; gap: 30px;">
                    <div class="profile-avatar">
                        <?php echo strtoupper(substr($member['full_name'], 0, 1)); ?>
                    </div>
                    
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                            <h1 style="font-size: 32px;"><?php echo htmlspecialchars($member['full_name']); ?></h1>
                            <span class="profile-badge badge-<?php echo $member['status']; ?>">
                                <?php echo ucfirst($member['status']); ?>
                            </span>
                            <span class="profile-badge" style="background: #e3f2fd; color: #1976d2;">
                                #<?php echo $member['member_number']; ?>
                            </span>
                        </div>
                        
                        <div style="display: flex; gap: 30px; color: #666;">
                            <div><span class="material-icons" style="font-size: 16px; vertical-align: middle;">phone</span> <?php echo $member['phone'] ?: 'Not provided'; ?></div>
                            <div><span class="material-icons" style="font-size: 16px; vertical-align: middle;">email</span> <?php echo $member['email'] ?: 'Not provided'; ?></div>
                            <div><span class="material-icons" style="font-size: 16px; vertical-align: middle;">event</span> Member since <?php echo date('F Y', strtotime($member['registration_date'])); ?></div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Stats -->
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-top: 30px;">
                    <div class="stat-card">
                        <div class="stat-icon blue">
                            <span class="material-icons">people</span>
                        </div>
                        <div class="stat-value"><?php echo $member['total_family_members']; ?></div>
                        <div class="stat-label">Family Members</div>
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">
                            Own: <?php echo $member['own_family_count']; ?> | Wife's: <?php echo $member['wife_family_count']; ?>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon green">
                            <span class="material-icons">payments</span>
                        </div>
                        <div class="stat-value">ETB <?php echo number_format($member['total_contributions'], 0); ?></div>
                        <div class="stat-label">Total Contributions</div>
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">
                            <?php echo $member['total_payments']; ?> payments
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon orange">
                            <span class="material-icons">warning</span>
                        </div>
                        <div class="stat-value"><?php echo $member['overdue_months']; ?></div>
                        <div class="stat-label">Overdue Months</div>
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">
                            Last payment: <?php echo $member['last_payment_date'] ? date('M Y', strtotime($member['last_payment_date'])) : 'Never'; ?>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon purple">
                            <span class="material-icons">verified</span>
                        </div>
                        <div class="stat-value"><?php echo $stats['compliance_score']; ?>%</div>
                        <div class="stat-label">Compliance Score</div>
                        <div class="compliance-meter" style="margin-top: 10px;">
                            <div class="compliance-fill" style="width: <?php echo $stats['compliance_score']; ?>%;"></div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="quick-actions">
                    <?php if ($roleAccess->hasPermission('edit_members')): ?>
                        <button class="action-btn" onclick="location.href='edit_member.php?id=<?php echo $id; ?>'" title="Edit Member">
                            <span class="material-icons">edit</span>
                        </button>
                    <?php endif; ?>
                    
                    <?php if ($roleAccess->hasPermission('record_payments')): ?>
                        <button class="action-btn" onclick="location.href='add_payment.php?member_id=<?php echo $id; ?>'" title="Record Payment">
                            <span class="material-icons">payment</span>
                        </button>
                    <?php endif; ?>
                    
                    <button class="action-btn" onclick="window.print()" title="Print Profile">
                        <span class="material-icons">print</span>
                    </button>
                    
                    <button class="action-btn" onclick="exportProfile(<?php echo $id; ?>)" title="Export Profile">
                        <span class="material-icons">download</span>
                    </button>
                </div>
            </div>
            
            <!-- Tabs Navigation -->
            <div class="tab-container">
                <div class="tabs">
                    <div class="tab active" onclick="showTab('overview')">Overview</div>
                    <div class="tab" onclick="showTab('family')">Family Tree</div>
                    <div class="tab" onclick="showTab('payments')">Payment History</div>
                    <div class="tab" onclick="showTab('schedule')">Contribution Schedule</div>
                    <div class="tab" onclick="showTab('documents')">Documents</div>
                    <div class="tab" onclick="showTab('activity')">Activity Log</div>
                </div>
                
                <!-- Overview Tab -->
                <div id="tab-overview" class="tab-content active">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <!-- Personal Information -->
                        <div style="background: white; border-radius: 15px; padding: 25px;">
                            <h3 style="margin-bottom: 20px;">Personal Information</h3>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Full Name</div>
                                    <div class="info-value"><?php echo htmlspecialchars($member['full_name']); ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Member Number</div>
                                    <div class="info-value"><?php echo $member['member_number']; ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Phone</div>
                                    <div class="info-value"><?php echo $member['phone'] ?: 'Not provided'; ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Email</div>
                                    <div class="info-value"><?php echo $member['email'] ?: 'Not provided'; ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Occupation</div>
                                    <div class="info-value"><?php echo $member['occupation'] ?: 'Not provided'; ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">Registration Date</div>
                                    <div class="info-value"><?php echo date('F j, Y', strtotime($member['registration_date'])); ?></div>
                                </div>
                                
                                <?php if ($member['marital_status']): ?>
                                <div class="info-item">
                                    <div class="info-label">Marital Status</div>
                                    <div class="info-value"><?php echo ucfirst($member['marital_status']); ?></div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($member['spouse_name']): ?>
                                <div class="info-item">
                                    <div class="info-label">Spouse Name</div>
                                    <div class="info-value"><?php echo htmlspecialchars($member['spouse_name']); ?></div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($member['address']): ?>
                            <div style="margin-top: 20px;">
                                <div class="info-label">Address</div>
                                <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; margin-top: 5px;">
                                    <?php echo nl2br(htmlspecialchars($member['address'])); ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Quick Stats & Charts -->
                        <div style="background: white; border-radius: 15px; padding: 25px;">
                            <h3 style="margin-bottom: 20px;">Payment Analytics</h3>
                            
                            <canvas id="paymentChart" style="height: 200px; margin-bottom: 20px;"></canvas>
                            
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                                <div style="text-align: center; padding: 15px; background: #f5f5f5; border-radius: 8px;">
                                    <div style="font-size: 12px; color: #666;">Average Payment</div>
                                    <div style="font-size: 24px; font-weight: 700;">ETB <?php echo number_format($stats['average_payment'], 0); ?></div>
                                </div>
                                
                                <div style="text-align: center; padding: 15px; background: #f5f5f5; border-radius: 8px;">
                                    <div style="font-size: 12px; color: #666;">Payment Rate</div>
                                    <div style="font-size: 24px; font-weight: 700;"><?php echo $stats['payment_rate']; ?>%</div>
                                </div>
                                
                                <div style="text-align: center; padding: 15px; background: #f5f5f5; border-radius: 8px;">
                                    <div style="font-size: 12px; color: #666;">Months Active</div>
                                    <div style="font-size: 24px; font-weight: 700;"><?php echo $stats['months_active']; ?></div>
                                </div>
                                
                                <div style="text-align: center; padding: 15px; background: #f5f5f5; border-radius: 8px;">
                                    <div style="font-size: 12px; color: #666;">Account Status</div>
                                    <div style="font-size: 24px; font-weight: 700;">
                                        <?php echo $member['has_user_account'] ? 'Active' : 'No'; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Recent Activity Preview -->
                            <div style="margin-top: 20px;">
                                <h4>Recent Activity</h4>
                                <?php foreach (array_slice($recentActivities, 0, 3) as $activity): ?>
                                <div style="padding: 10px 0; border-bottom: 1px solid #f0f0f0;">
                                    <div style="font-size: 13px;"><?php echo $activity['action']; ?></div>
                                    <div style="font-size: 11px; color: #999;"><?php echo date('M j, Y H:i', strtotime($activity['created_at'])); ?></div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Family Tree Tab -->
                <div id="tab-family" class="tab-content">
                    <div class="family-tree">
                        <!-- Own Family -->
                        <div class="family-card own">
                            <h3 style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px;">
                                <span class="material-icons" style="color: #667eea;">family_restroom</span>
                                My Family (<?php echo count($family['own']); ?> members)
                            </h3>
                            
                            <?php if (count($family['own']) > 0): ?>
                                <?php foreach ($family['own'] as $relative): ?>
                                <div class="family-member">
                                    <div class="member-avatar">
                                        <span class="material-icons">person</span>
                                    </div>
                                    <div class="member-details">
                                        <div class="member-name"><?php echo htmlspecialchars($relative['full_name']); ?></div>
                                        <div class="member-relation">
                                            <?php echo ucfirst(str_replace('_', ' ', $relative['specific_relationship'])); ?>
                                            <?php if ($relative['age']): ?> • <?php echo $relative['age']; ?> years<?php endif; ?>
                                        </div>
                                    </div>
                                    <div>
                                        <?php if ($relative['is_dependent']): ?>
                                            <span class="member-badge badge-dependent">Dependent</span>
                                        <?php endif; ?>
                                        <?php if ($relative['emergency_contact']): ?>
                                            <span class="member-badge badge-emergency">Emergency</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="no-data">No family members registered</p>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Wife's Family -->
                        <div class="family-card wife">
                            <h3 style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px;">
                                <span class="material-icons" style="color: #f06292;">diversity_3</span>
                                Wife's Family (<?php echo count($family['wife']); ?> members)
                            </h3>
                            
                            <?php if (count($family['wife']) > 0): ?>
                                <?php foreach ($family['wife'] as $relative): ?>
                                <div class="family-member">
                                    <div class="member-avatar">
                                        <span class="material-icons">person</span>
                                    </div>
                                    <div class="member-details">
                                        <div class="member-name"><?php echo htmlspecialchars($relative['full_name']); ?></div>
                                        <div class="member-relation">
                                            <?php echo ucfirst(str_replace('_', ' ', $relative['specific_relationship'])); ?>
                                            <?php if ($relative['age']): ?> • <?php echo $relative['age']; ?> years<?php endif; ?>
                                        </div>
                                    </div>
                                    <div>
                                        <?php if ($relative['is_dependent']): ?>
                                            <span class="member-badge badge-dependent">Dependent</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="no-data">No wife's family members registered</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Family Summary -->
                    <div style="background: white; border-radius: 15px; padding: 20px; margin-top: 20px;">
                        <h4>Family Summary</h4>
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-top: 15px;">
                            <div style="text-align: center;">
                                <div style="font-size: 28px; font-weight: 700;"><?php echo $member['total_family_members']; ?></div>
                                <div style="color: #666;">Total Dependents</div>
                            </div>
                            <div style="text-align: center;">
                                <div style="font-size: 28px; font-weight: 700;">
                                    <?php echo array_sum(array_column($family['own'], 'is_dependent')) + array_sum(array_column($family['wife'], 'is_dependent')); ?>
                                </div>
                                <div style="color: #666;">Dependents</div>
                            </div>
                            <div style="text-align: center;">
                                <div style="font-size: 28px; font-weight: 700;">
                                    <?php echo array_sum(array_column($family['own'], 'emergency_contact')) + array_sum(array_column($family['wife'], 'emergency_contact')); ?>
                                </div>
                                <div style="color: #666;">Emergency Contacts</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Payment History Tab -->
                <div id="tab-payments" class="tab-content">
                    <div style="background: white; border-radius: 15px; padding: 20px;">
                        <h3 style="margin-bottom: 20px;">Payment History</h3>
                        
                        <!-- Yearly Summary -->
                        <div style="display: flex; gap: 15px; margin-bottom: 20px; overflow-x: auto;">
                            <?php foreach ($yearlyStats as $year): ?>
                            <div style="background: #f5f5f5; border-radius: 8px; padding: 15px; min-width: 150px;">
                                <div style="font-weight: 600;"><?php echo $year['year']; ?></div>
                                <div style="font-size: 20px; font-weight: 700; color: #4CAF50;">
                                    ETB <?php echo number_format($year['yearly_total'], 0); ?>
                                </div>
                                <div style="font-size: 12px; color: #666;">
                                    <?php echo $year['payment_count']; ?> payments
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <!-- Payment Timeline -->
                        <div class="payment-timeline">
                            <?php foreach ($paymentHistory as $payment): ?>
                            <div class="timeline-item">
                                <div class="timeline-dot <?php echo $payment['payment_status']; ?>"></div>
                                <div class="timeline-content">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <strong><?php echo date('F j, Y', strtotime($payment['payment_date'])); ?></strong>
                                            <span style="margin-left: 10px; color: #666;">
                                                (<?php echo date('F Y', strtotime($payment['year'] . '-' . $payment['month'] . '-01')); ?> contribution)
                                            </span>
                                        </div>
                                        <span style="font-size: 20px; font-weight: 700; color: #4CAF50;">
                                            ETB <?php echo number_format($payment['amount'], 2); ?>
                                        </span>
                                    </div>
                                    
                                    <div style="display: flex; gap: 20px; margin-top: 10px; font-size: 13px;">
                                        <span>Method: <?php echo ucfirst($payment['payment_method']); ?></span>
                                        <?php if ($payment['transaction_reference']): ?>
                                            <span>Ref: <?php echo $payment['transaction_reference']; ?></span>
                                        <?php endif; ?>
                                        <?php if ($payment['receipt_number']): ?>
                                            <span>Receipt: <?php echo $payment['receipt_number']; ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if ($payment['days_after_due'] > 0): ?>
                                    <div style="margin-top: 8px; color: #f44336; font-size: 12px;">
                                        Paid <?php echo $payment['days_after_due']; ?> days after due date
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div style="margin-top: 8px; font-size: 11px; color: #999;">
                                        Recorded by: <?php echo $payment['recorded_by_name'] ?? 'System'; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Contribution Schedule Tab -->
                <div id="tab-schedule" class="tab-content">
                    <div style="background: white; border-radius: 15px; padding: 20px;">
                        <h3 style="margin-bottom: 20px;">Contribution Schedule (Last 12 Months)</h3>
                        
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Month</th>
                                    <th>Year</th>
                                    <th>Due Date</th>
                                    <th>Expected</th>
                                    <th>Status</th>
                                    <th>Payment Date</th>
                                    <th>Days Overdue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($contributionSchedule as $schedule): ?>
                                <?php
                                    $statusClass = '';
                                    $statusText = '';
                                    $dueDate = strtotime($schedule['due_date']);
                                    $now = time();
                                    
                                    if ($schedule['status'] == 'paid') {
                                        $statusClass = 'paid';
                                        $statusText = 'Paid';
                                    } elseif ($schedule['status'] == 'overdue') {
                                        $statusClass = 'overdue';
                                        $statusText = 'Overdue';
                                    } elseif ($now > $dueDate) {
                                        $statusClass = 'grace';
                                        $statusText = 'Grace Period';
                                    } else {
                                        $statusClass = 'pending';
                                        $statusText = 'Pending';
                                    }
                                ?>
                                <tr class="<?php echo $statusClass == 'overdue' ? 'row-overdue' : ''; ?>">
                                    <td><?php echo date('F', mktime(0, 0, 0, $schedule['month'], 1)); ?></td>
                                    <td><?php echo $schedule['year']; ?></td>
                                    <td><?php echo date('M j, Y', strtotime($schedule['due_date'])); ?></td>
                                    <td>ETB <?php echo number_format($schedule['expected_amount'], 2); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $statusClass; ?>">
                                            <?php echo $statusText; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($schedule['payment_id']): ?>
                                            <?php 
                                            $payment = array_filter($paymentHistory, fn($p) => $p['id'] == $schedule['payment_id']);
                                            $payment = reset($payment);
                                            echo $payment ? date('M j, Y', strtotime($payment['payment_date'])) : '-';
                                            ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($schedule['status'] == 'overdue'): ?>
                                            <?php echo abs(round(($now - $dueDate) / (60 * 60 * 24))); ?> days
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Documents Tab -->
                <div id="tab-documents" class="tab-content">
                    <div style="background: white; border-radius: 15px; padding: 20px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                            <h3>Member Documents</h3>
                            <?php if ($roleAccess->hasPermission('edit_members')): ?>
                                <button class="btn btn-primary" onclick="uploadDocument(<?php echo $id; ?>)">
                                    <span class="material-icons">upload</span> Upload Document
                                </button>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (count($memberDocuments) > 0): ?>
                            <div class="document-grid">
                                <?php foreach ($memberDocuments as $doc): ?>
                                <div class="document-card" onclick="viewDocument('<?php echo $doc['file_path']; ?>')">
                                    <div class="document-icon">
                                        <?php
                                        $ext = pathinfo($doc['file_name'], PATHINFO_EXTENSION);
                                        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                                            echo '<span class="material-icons">image</span>';
                                        } elseif ($ext == 'pdf') {
                                            echo '<span class="material-icons">picture_as_pdf</span>';
                                        } else {
                                            echo '<span class="material-icons">description</span>';
                                        }
                                        ?>
                                    </div>
                                    <div style="font-weight: 600; font-size: 14px; margin-bottom: 5px;">
                                        <?php echo htmlspecialchars(substr($doc['file_name'], 0, 20)) . (strlen($doc['file_name']) > 20 ? '...' : ''); ?>
                                    </div>
                                    <div style="font-size: 11px; color: #666;">
                                        <?php echo date('M j, Y', strtotime($doc['uploaded_at'])); ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="no-data">No documents uploaded</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Activity Log Tab -->
                <div id="tab-activity" class="tab-content">
                    <div style="background: white; border-radius: 15px; padding: 20px;">
                        <h3 style="margin-bottom: 20px;">Recent Activity</h3>
                        
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date/Time</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Module</th>
                                    <th>Description</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentActivities as $activity): ?>
                                <tr>
                                    <td><?php echo date('M j, Y H:i', strtotime($activity['created_at'])); ?></td>
                                    <td><?php echo $activity['username']; ?></td>
                                    <td><?php echo $activity['action']; ?></td>
                                    <td><?php echo $activity['module']; ?></td>
                                    <td><?php echo $activity['description']; ?></td>
                                    <td><?php echo $activity['ip_address']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        // Initialize payment chart
        const ctx = document.getElementById('paymentChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column(array_reverse($yearlyStats), 'year')); ?>,
                datasets: [{
                    label: 'Yearly Contributions',
                    data: <?php echo json_encode(array_column(array_reverse($yearlyStats), 'yearly_total')); ?>,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'ETB ' + value;
                            }
                        }
                    }
                }
            }
        });
        
        // Tab switching
        function showTab(tabName) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            event.target.classList.add('active');
            document.getElementById('tab-' + tabName).classList.add('active');
        }
        
        // Export profile
        function exportProfile(id) {
            window.location.href = 'export_profile.php?id=' + id;
        }
        
        // View document
        function viewDocument(path) {
            window.open(path, '_blank');
        }
        
        // Upload document
        function uploadDocument(memberId) {
            // Create file input
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.pdf,.jpg,.jpeg,.png,.doc,.docx';
            
            input.onchange = function(e) {
                const file = e.target.files[0];
                if (file) {
                    const formData = new FormData();
                    formData.append('file', file);
                    formData.append('member_id', memberId);
                    
                    fetch('upload_document.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Document uploaded successfully!');
                            location.reload();
                        } else {
                            alert('Error uploading document: ' + data.error);
                        }
                    });
                }
            };
            
            input.click();
        }
        
        // Print functionality
        window.onbeforeprint = function() {
            // Hide sidebar and top bar when printing
            document.querySelector('.sidebar').style.display = 'none';
            document.querySelector('.top-bar').style.display = 'none';
            document.querySelector('.quick-actions').style.display = 'none';
        };
        
        window.onafterprint = function() {
            // Restore elements after printing
            document.querySelector('.sidebar').style.display = 'block';
            document.querySelector('.top-bar').style.display = 'flex';
            document.querySelector('.quick-actions').style.display = 'flex';
        };
    </script>
</body>
</html>