<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';
$user = [];
$recent_activities = [];
$statistics = [];

try {
    // First, check if users table exists and has the correct structure
    $table_check = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($table_check->rowCount() == 0) {
        throw new Exception("Users table does not exist. Please run the database setup script.");
    }
    
    // Get user details with proper error handling
    $stmt = $pdo->prepare("
        SELECT u.*, 
               COALESCE(r.role_name, 'Member') as role_name, 
               r.role_description 
        FROM users u 
        LEFT JOIN roles r ON u.role = r.role_code 
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        // User not found - destroy session and redirect
        error_log("User not found for ID: " . $user_id);
        session_destroy();
        header("Location: login.php?error=user_not_found");
        exit();
    }
    
    // Set default values for missing fields
    $default_user = [
        'id' => $user_id,
        'username' => 'Unknown',
        'full_name' => 'Unknown User',
        'email' => 'unknown@example.com',
        'phone' => '',
        'address' => '',
        'role' => 'member',
        'role_name' => 'Member',
        'profile_photo' => '',
        'is_active' => 1,
        'is_locked' => 0,
        'two_factor_enabled' => 0,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => null,
        'last_login' => null,
        'login_attempts' => 0
    ];
    
    // Merge user data with defaults to avoid undefined keys
    $user = array_merge($default_user, $user);
    
    // Get user statistics with error handling
    try {
        // Check if transactions table exists
        $transactions_exist = $pdo->query("SHOW TABLES LIKE 'transactions'")->rowCount() > 0;
        
        if ($transactions_exist) {
            $stats_sql = "
                SELECT 
                    (SELECT COUNT(*) FROM transactions WHERE user_id = :user_id) as total_transactions,
                    (SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = :user_id AND type = 'income') as total_income,
                    (SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = :user_id AND type = 'expense') as total_expense
            ";
            $stats_stmt = $pdo->prepare($stats_sql);
            $stats_stmt->execute([':user_id' => $user_id]);
            $statistics = $stats_stmt->fetch(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        // Transactions table might not exist yet
        error_log("Statistics error: " . $e->getMessage());
        $statistics = [
            'total_transactions' => 0,
            'total_income' => 0,
            'total_expense' => 0
        ];
    }
    
    // Ensure statistics have default values
    $statistics = array_merge([
        'total_transactions' => 0,
        'total_income' => 0,
        'total_expense' => 0
    ], $statistics ?: []);
    
    // Get login history
    try {
        $login_history_sql = "
            SELECT * FROM login_history 
            WHERE user_id = :user_id 
            ORDER BY login_time DESC 
            LIMIT 5
        ";
        $login_stmt = $pdo->prepare($login_history_sql);
        $login_stmt->execute([':user_id' => $user_id]);
        $login_history = $login_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $statistics['total_logins'] = count($login_history);
        $statistics['last_login'] = !empty($login_history) ? $login_history[0]['login_time'] : null;
    } catch (PDOException $e) {
        error_log("Login history error: " . $e->getMessage());
        $login_history = [];
        $statistics['total_logins'] = 0;
        $statistics['last_login'] = null;
    }
    
    // Get recent activities
    try {
        $activities = [];
        
        // Add login activities
        foreach ($login_history as $login) {
            $activities[] = [
                'activity_type' => 'login',
                'activity_time' => $login['login_time'],
                'ip_address' => $login['ip_address'] ?? 'Unknown',
                'description' => 'User logged in'
            ];
        }
        
        // Add transaction activities if table exists
        if ($transactions_exist) {
            $trans_stmt = $pdo->prepare("
                SELECT 'transaction' as activity_type, 
                       created_at as activity_time, 
                       NULL as ip_address, 
                       CONCAT(type, ': ', COALESCE(description, 'No description')) as description 
                FROM transactions 
                WHERE user_id = :user_id 
                ORDER BY created_at DESC 
                LIMIT 5
            ");
            $trans_stmt->execute([':user_id' => $user_id]);
            $trans_activities = $trans_stmt->fetchAll(PDO::FETCH_ASSOC);
            $activities = array_merge($activities, $trans_activities);
        }
        
        // Sort activities by time (most recent first)
        usort($activities, function($a, $b) {
            return strtotime($b['activity_time']) - strtotime($a['activity_time']);
        });
        
        $recent_activities = array_slice($activities, 0, 10);
        
    } catch (PDOException $e) {
        error_log("Activities error: " . $e->getMessage());
        $recent_activities = [];
    }
    
} catch (Exception $e) {
    $error = "System error: " . $e->getMessage();
    error_log("Profile page error: " . $e->getMessage());
    
    // Create a minimal user array to prevent undefined errors
    $user = [
        'id' => $user_id,
        'username' => $_SESSION['username'] ?? 'User',
        'full_name' => $_SESSION['user_name'] ?? 'User',
        'email' => '',
        'phone' => '',
        'address' => '',
        'role' => $_SESSION['user_role'] ?? 'member',
        'role_name' => ucfirst($_SESSION['user_role'] ?? 'Member'),
        'profile_photo' => '',
        'is_active' => 1,
        'is_locked' => 0,
        'two_factor_enabled' => 0,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => null,
        'last_login' => null,
        'login_attempts' => 0
    ];
    $statistics = [
        'total_transactions' => 0,
        'total_income' => 0,
        'total_expense' => 0,
        'total_logins' => 0,
        'last_login' => null
    ];
    $recent_activities = [];
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $full_name = trim($_POST['full_name'] ?? $user['full_name']);
        $email = trim($_POST['email'] ?? $user['email']);
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        
        // Validation
        if (empty($full_name)) {
            $error = "Full name is required.";
        } elseif (empty($email)) {
            $error = "Email is required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        } else {
            try {
                // Check if email exists for another user
                $check = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $check->execute([$email, $user_id]);
                
                if ($check->fetch()) {
                    $error = "Email already in use by another account.";
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET full_name = ?, email = ?, phone = ?, address = ?, updated_at = NOW() 
                        WHERE id = ?
                    ");
                    $result = $stmt->execute([$full_name, $email, $phone, $address, $user_id]);
                    
                    if ($result) {
                        // Update session
                        $_SESSION['user_name'] = $full_name;
                        
                        $success = "Profile updated successfully!";
                        
                        // Refresh user data
                        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        $user = array_merge($user, $stmt->fetch(PDO::FETCH_ASSOC) ?: []);
                    } else {
                        $error = "Failed to update profile.";
                    }
                }
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
                error_log("Profile update error: " . $e->getMessage());
            }
        }
    }
    
    // Handle password change
    elseif (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = "All password fields are required.";
        } elseif ($new_password !== $confirm_password) {
            $error = "New passwords do not match.";
        } elseif (strlen($new_password) < 8) {
            $error = "Password must be at least 8 characters long.";
        } elseif (!password_verify($current_password, $user['password'])) {
            $error = "Current password is incorrect.";
        } else {
            try {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                $result = $stmt->execute([$hashed_password, $user_id]);
                
                if ($result) {
                    $success = "Password changed successfully!";
                } else {
                    $error = "Failed to change password.";
                }
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
    
    // Handle profile picture upload
    elseif (isset($_POST['upload_photo'])) {
        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $file_type = $_FILES['profile_photo']['type'];
            $file_size = $_FILES['profile_photo']['size'];
            
            if (!in_array($file_type, $allowed_types)) {
                $error = "Only JPG, PNG, and GIF images are allowed.";
            } elseif ($file_size > 2 * 1024 * 1024) { // 2MB max
                $error = "File size must be less than 2MB.";
            } else {
                $upload_dir = __DIR__ . '/uploads/profiles/';
                
                // Create directory if it doesn't exist
                if (!file_exists($upload_dir)) {
                    if (!mkdir($upload_dir, 0777, true)) {
                        $error = "Failed to create upload directory.";
                    }
                }
                
                if (empty($error)) {
                    $file_extension = pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION);
                    $file_name = 'profile_' . $user_id . '_' . time() . '.' . $file_extension;
                    $upload_path = $upload_dir . $file_name;
                    
                    if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $upload_path)) {
                        // Delete old profile photo if exists
                        if (!empty($user['profile_photo']) && file_exists($upload_dir . $user['profile_photo'])) {
                            @unlink($upload_dir . $user['profile_photo']);
                        }
                        
                        // Update database
                        $stmt = $pdo->prepare("UPDATE users SET profile_photo = ? WHERE id = ?");
                        $result = $stmt->execute([$file_name, $user_id]);
                        
                        if ($result) {
                            $success = "Profile photo updated successfully!";
                            
                            // Refresh user data
                            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                            $stmt->execute([$user_id]);
                            $user = array_merge($user, $stmt->fetch(PDO::FETCH_ASSOC) ?: []);
                        } else {
                            $error = "Failed to update database.";
                        }
                    } else {
                        $error = "Failed to upload file.";
                    }
                }
            }
        } else {
            $error = "Please select a file to upload.";
        }
    }
}

// Get current page for sidebar
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container-fluid {
            padding: 20px;
        }
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            position: relative;
            overflow: hidden;
        }
        .profile-header::after {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: rgba(255,255,255,0.1);
            transform: rotate(45deg);
        }
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid white;
            object-fit: cover;
            background: #f8f9fa;
            position: relative;
            z-index: 1;
        }
        .profile-name {
            font-size: 2rem;
            font-weight: 600;
            margin: 10px 0 5px;
            position: relative;
            z-index: 1;
        }
        .profile-role {
            background: rgba(255,255,255,0.2);
            padding: 5px 15px;
            border-radius: 20px;
            display: inline-block;
            font-size: 0.9rem;
            position: relative;
            z-index: 1;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 20px;
        }
        .card-header {
            background: white;
            border-bottom: 2px solid #f0f0f0;
            padding: 15px 20px;
            font-weight: 600;
        }
        .card-header i {
            margin-right: 10px;
            color: #667eea;
        }
        .info-label {
            color: #6c757d;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .info-value {
            font-size: 1.1rem;
            font-weight: 500;
            margin-bottom: 15px;
        }
        .stat-card {
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2.5rem;
            color: #667eea;
            margin-bottom: 10px;
        }
        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: #333;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .activity-item {
            padding: 15px;
            border-left: 3px solid #667eea;
            background: #f8f9fa;
            margin-bottom: 10px;
            border-radius: 0 5px 5px 0;
        }
        .activity-time {
            color: #6c757d;
            font-size: 0.85rem;
        }
        .activity-type {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 10px;
        }
        .type-login { background: #e3f2fd; color: #1976d2; }
        .type-transaction { background: #e8f5e9; color: #388e3c; }
        .type-profile_update { background: #fff3e0; color: #f57c00; }
        .nav-tabs .nav-link {
            color: #495057;
            border: none;
            padding: 10px 20px;
            font-weight: 500;
        }
        .nav-tabs .nav-link.active {
            color: #667eea;
            border-bottom: 3px solid #667eea;
            background: transparent;
        }
        .tab-content {
            padding: 20px;
            background: white;
            border-radius: 0 0 10px 10px;
        }
        .photo-upload-container {
            position: relative;
            display: inline-block;
        }
        .photo-upload-overlay {
            position: absolute;
            bottom: 0;
            right: 0;
            background: #667eea;
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        .photo-upload-overlay:hover {
            background: #5a67d8;
            transform: scale(1.1);
        }
        #profile_photo {
            display: none;
        }
        @media print {
            .no-print { display: none; }
        }
        .debug-info {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Debug Info (remove in production) -->
        <?php if (isset($_GET['debug'])): ?>
            <div class="debug-info">
                <strong>Debug Information:</strong>
                <pre><?php print_r(['user' => $user, 'statistics' => $statistics]); ?></pre>
            </div>
        <?php endif; ?>
        
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white rounded mb-4 shadow-sm no-print">
            <div class="container-fluid">
                <span class="navbar-brand">
                    <i class="material-icons" style="vertical-align: middle;">account_circle</i>
                    My Profile
                </span>
                <div class="navbar-nav ml-auto">
                    <a href="dashboard.php" class="nav-link">
                        <i class="material-icons" style="vertical-align: middle;">dashboard</i>
                        Dashboard
                    </a>
                    <a href="logout.php" class="nav-link text-danger">
                        <i class="material-icons" style="vertical-align: middle;">exit_to_app</i>
                        Logout
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Error/Success Messages -->
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="material-icons" style="vertical-align: middle;">error</i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="material-icons" style="vertical-align: middle;">check_circle</i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="row align-items-center">
                <div class="col-md-2 text-center">
                    <div class="photo-upload-container">
                        <?php 
                        $avatar_url = 'https://ui-avatars.com/api/?name=' . urlencode($user['full_name'] ?? $user['username']) . '&background=667eea&color=fff&size=120';
                        if (!empty($user['profile_photo']) && file_exists(__DIR__ . '/uploads/profiles/' . $user['profile_photo'])): 
                        ?>
                            <img src="uploads/profiles/<?php echo htmlspecialchars($user['profile_photo']); ?>" 
                                 alt="Profile" class="profile-avatar">
                        <?php else: ?>
                            <img src="<?php echo $avatar_url; ?>" alt="Profile Avatar" class="profile-avatar">
                        <?php endif; ?>
                        
                        <!-- Upload overlay -->
                        <label for="profile_photo" class="photo-upload-overlay no-print">
                            <i class="material-icons" style="font-size: 18px;">camera_alt</i>
                        </label>
                        
                        <form method="POST" enctype="multipart/form-data" id="photoForm">
                            <input type="file" id="profile_photo" name="profile_photo" accept="image/*">
                            <input type="hidden" name="upload_photo" value="1">
                        </form>
                    </div>
                </div>
                <div class="col-md-10">
                    <h1 class="profile-name"><?php echo htmlspecialchars($user['full_name'] ?? $user['username'] ?? 'User'); ?></h1>
                    <div class="profile-role">
                        <i class="material-icons" style="font-size: 16px; vertical-align: middle;">work</i>
                        <?php echo htmlspecialchars($user['role_name'] ?? $user['role'] ?? 'Member'); ?>
                    </div>
                    <p class="mt-3">
                        <i class="material-icons" style="font-size: 18px; vertical-align: middle;">email</i>
                        <?php echo htmlspecialchars($user['email'] ?? 'No email provided'); ?>
                        <?php if (!empty($user['phone'])): ?>
                            &nbsp;&nbsp;
                            <i class="material-icons" style="font-size: 18px; vertical-align: middle;">phone</i>
                            <?php echo htmlspecialchars($user['phone']); ?>
                        <?php endif; ?>
                    </p>
                    <p class="mb-0">
                        <small>
                            <i class="material-icons" style="font-size: 14px; vertical-align: middle;">event</i>
                            Member since: 
                            <?php 
                            if (!empty($user['created_at']) && $user['created_at'] != '1970-01-01 00:00:00') {
                                echo date('F j, Y', strtotime($user['created_at']));
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </small>
                    </p>
                </div>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-value">KES <?php echo number_format($statistics['total_income'] ?? 0, 2); ?></div>
                    <div class="stat-label">Total Income</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">💸</div>
                    <div class="stat-value">KES <?php echo number_format($statistics['total_expense'] ?? 0, 2); ?></div>
                    <div class="stat-label">Total Expenses</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-value"><?php echo number_format($statistics['total_transactions'] ?? 0); ?></div>
                    <div class="stat-label">Transactions</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">🔐</div>
                    <div class="stat-value"><?php echo number_format($statistics['total_logins'] ?? 0); ?></div>
                    <div class="stat-label">Total Logins</div>
                </div>
            </div>
        </div>
        
        <!-- Main Content Tabs -->
        <div class="card no-print">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" id="profileTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="profile-tab" data-toggle="tab" href="#profile" role="tab">
                            <i class="material-icons" style="vertical-align: middle;">person</i> Profile Information
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="security-tab" data-toggle="tab" href="#security" role="tab">
                            <i class="material-icons" style="vertical-align: middle;">security</i> Security
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="activity-tab" data-toggle="tab" href="#activity" role="tab">
                            <i class="material-icons" style="vertical-align: middle;">history</i> Recent Activity
                        </a>
                    </li>
                </ul>
            </div>
            
            <div class="tab-content">
                <!-- Profile Information Tab -->
                <div class="tab-pane fade show active" id="profile" role="tabpanel">
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="info-label">Username</label>
                                    <input type="text" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['username'] ?? 'N/A'); ?>" disabled>
                                    <small class="text-muted">Username cannot be changed</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="info-label">Full Name *</label>
                                    <input type="text" name="full_name" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="info-label">Email Address *</label>
                                    <input type="email" name="email" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="info-label">Phone Number</label>
                                    <input type="text" name="phone" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="info-label">Address</label>
                            <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="info-label">Role</label>
                                    <input type="text" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['role_name'] ?? $user['role'] ?? 'Member'); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="info-label">Account Status</label>
                                    <div>
                                        <?php if (!empty($user['is_locked'])): ?>
                                            <span class="badge badge-danger">Locked</span>
                                        <?php elseif (!empty($user['is_active'])): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Inactive</span>
                                        <?php endif; ?>
                                        
                                        <?php if (!empty($user['two_factor_enabled'])): ?>
                                            <span class="badge badge-info ml-2">2FA Enabled</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="material-icons" style="vertical-align: middle;">save</i> Update Profile
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="material-icons" style="vertical-align: middle;">undo</i> Reset
                        </button>
                    </form>
                </div>
                
                <!-- Security Tab -->
                <div class="tab-pane fade" id="security" role="tabpanel">
                    <h5 class="mb-4">Change Password</h5>
                    
                    <form method="POST" class="col-md-6">
                        <div class="form-group">
                            <label class="info-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="info-label">New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                            <small class="text-muted">Minimum 8 characters</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="info-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        
                        <button type="submit" name="change_password" class="btn btn-warning">
                            <i class="material-icons" style="vertical-align: middle;">vpn_key</i> Change Password
                        </button>
                    </form>
                    
                    <hr class="my-4">
                    
                    <h5 class="mb-4">Two-Factor Authentication</h5>
                    
                    <div class="col-md-6">
                        <?php if (!empty($user['two_factor_enabled'])): ?>
                            <div class="alert alert-success">
                                <i class="material-icons" style="vertical-align: middle;">check_circle</i>
                                Two-factor authentication is enabled for your account.
                            </div>
                            <a href="disable_2fa.php" class="btn btn-danger" 
                               onclick="return confirm('Disable two-factor authentication?')">
                                <i class="material-icons" style="vertical-align: middle;">lock_open</i> Disable 2FA
                            </a>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="material-icons" style="vertical-align: middle;">info</i>
                                Two-factor authentication adds an extra layer of security to your account.
                            </div>
                            <a href="enable_2fa.php" class="btn btn-success">
                                <i class="material-icons" style="vertical-align: middle;">lock</i> Enable 2FA
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <hr class="my-4">
                    
                    <h5 class="mb-4">Login Sessions</h5>
                    
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Login Time</th>
                                    <th>IP Address</th>
                                    <th>User Agent</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($login_history)): ?>
                                    <?php foreach ($login_history as $session): ?>
                                    <tr>
                                        <td><?php echo date('Y-m-d H:i:s', strtotime($session['login_time'] ?? 'now')); ?></td>
                                        <td><?php echo htmlspecialchars($session['ip_address'] ?? 'N/A'); ?></td>
                                        <td>
                                            <small><?php echo htmlspecialchars(substr($session['user_agent'] ?? 'N/A', 0, 50) . '...'); ?></small>
                                        </td>
                                        <td>
                                            <?php if (($session['login_time'] ?? '') == ($statistics['last_login'] ?? '')): ?>
                                                <span class="badge badge-success">Current</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Past</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No login history found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Recent Activity Tab -->
                <div class="tab-pane fade" id="activity" role="tabpanel">
                    <h5 class="mb-4">Recent Activity</h5>
                    
                    <?php if (empty($recent_activities)): ?>
                        <div class="alert alert-info">No recent activity found.</div>
                    <?php else: ?>
                        <?php foreach ($recent_activities as $activity): ?>
                            <div class="activity-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>
                                            <?php 
                                            switch ($activity['activity_type'] ?? '') {
                                                case 'login':
                                                    echo '🔐 Login';
                                                    break;
                                                case 'transaction':
                                                    echo '💰 Transaction';
                                                    break;
                                                case 'profile_update':
                                                    echo '👤 Profile Update';
                                                    break;
                                                default:
                                                    echo '📝 ' . ucfirst($activity['activity_type'] ?? 'Activity');
                                            }
                                            ?>
                                        </strong>
                                        <span class="activity-type type-<?php echo $activity['activity_type'] ?? 'other'; ?>">
                                            <?php echo $activity['activity_type'] ?? 'other'; ?>
                                        </span>
                                        <p class="mb-1"><?php echo htmlspecialchars($activity['description'] ?? 'No description'); ?></p>
                                        <?php if (!empty($activity['ip_address'])): ?>
                                            <small class="text-muted">IP: <?php echo $activity['ip_address']; ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="activity-time">
                                        <?php echo date('M j, Y g:i A', strtotime($activity['activity_time'] ?? 'now')); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Account Information Card (visible in print) -->
        <div class="card d-print-block" style="display: none;">
            <div class="card-header">
                <h5>Account Information</h5>
            </div>
            <div class="card-body">
                <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username'] ?? 'N/A'); ?></p>
                <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['full_name'] ?? 'N/A'); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email'] ?? 'N/A'); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></p>
                <p><strong>Role:</strong> <?php echo htmlspecialchars($user['role_name'] ?? $user['role'] ?? 'Member'); ?></p>
                <p><strong>Member Since:</strong> 
                    <?php 
                    if (!empty($user['created_at']) && $user['created_at'] != '1970-01-01 00:00:00') {
                        echo date('F j, Y', strtotime($user['created_at']));
                    } else {
                        echo 'N/A';
                    }
                    ?>
                </p>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
    // Auto-submit photo upload
    document.getElementById('profile_photo')?.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            document.getElementById('photoForm').submit();
        }
    });
    
    // Password strength indicator
    document.querySelector('input[name="new_password"]')?.addEventListener('input', function() {
        let password = this.value;
        let strength = 0;
        
        if (password.length >= 8) strength += 1;
        if (password.match(/[a-z]+/)) strength += 1;
        if (password.match(/[A-Z]+/)) strength += 1;
        if (password.match(/[0-9]+/)) strength += 1;
        if (password.match(/[$@#&!]+/)) strength += 1;
        
        let indicator = document.getElementById('password-strength');
        if (!indicator) {
            indicator = document.createElement('small');
            indicator.id = 'password-strength';
            indicator.className = 'form-text';
            this.parentNode.appendChild(indicator);
        }
        
        let strengthText = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong'];
        let strengthColor = ['#dc3545', '#dc3545', '#ffc107', '#17a2b8', '#28a745', '#28a745'];
        
        indicator.textContent = 'Strength: ' + strengthText[strength];
        indicator.style.color = strengthColor[strength];
    });
    
    // Confirm before leaving unsaved changes
    let formChanged = false;
    
    document.querySelectorAll('form input, form textarea, form select').forEach(input => {
        input.addEventListener('change', () => formChanged = true);
    });
    
    window.addEventListener('beforeunload', function(e) {
        if (formChanged) {
            e.preventDefault();
            e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
        }
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    </script>
    
    <style>
    @media print {
        .no-print, .nav-tabs, .btn, .alert {
            display: none !important;
        }
        .tab-pane {
            display: block !important;
            opacity: 1 !important;
        }
        .card {
            break-inside: avoid;
        }
    }
    </style>
</body>
</html>