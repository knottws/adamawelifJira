<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';
$password_strength = 0;
$user = [];

// Get user details
try {
    $stmt = $pdo->prepare("SELECT username, email, full_name, password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        session_destroy();
        header("Location: login.php");
        exit();
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    error_log("Change password error: " . $e->getMessage());
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validation
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "All password fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match.";
    } elseif (strlen($new_password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } elseif (!preg_match('/[A-Z]/', $new_password)) {
        $error = "Password must contain at least one uppercase letter.";
    } elseif (!preg_match('/[a-z]/', $new_password)) {
        $error = "Password must contain at least one lowercase letter.";
    } elseif (!preg_match('/[0-9]/', $new_password)) {
        $error = "Password must contain at least one number.";
    } elseif (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $new_password)) {
        $error = "Password must contain at least one special character (!@#$%^&* etc).";
    } elseif ($current_password === $new_password) {
        $error = "New password must be different from current password.";
    } else {
        try {
            // Verify current password
            if (!password_verify($current_password, $user['password'])) {
                $error = "Current password is incorrect.";
                
                // Log failed attempt
                logActivity($pdo, 'password_change_failed', 'security', 'Failed password change attempt - incorrect current password');
            } else {
                // Check password history to prevent reuse
                $history_check = checkPasswordHistory($pdo, $user_id, $new_password);
                if (!$history_check['allowed']) {
                    $error = $history_check['message'];
                } else {
                    // Hash new password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    
                    // Start transaction
                    $pdo->beginTransaction();
                    
                    // Update password
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET password = ?, 
                            password_changed_at = NOW(),
                            password_expires_at = DATE_ADD(NOW(), INTERVAL 90 DAY),
                            updated_at = NOW() 
                        WHERE id = ?
                    ");
                    $stmt->execute([$hashed_password, $user_id]);
                    
                    // Save to password history
                    savePasswordHistory($pdo, $user_id, $hashed_password);
                    
                    // Invalidate all other sessions except current
                    if (function_exists('invalidateOtherSessions')) {
                        invalidateOtherSessions($pdo, $user_id);
                    } else {
                        // Simple session cleanup
                        $stmt = $pdo->prepare("
                            UPDATE user_sessions 
                            SET is_active = 0 
                            WHERE user_id = ? AND session_token != ?
                        ");
                        $stmt->execute([$user_id, $_SESSION['session_token'] ?? '']);
                    }
                    
                    // Log activity
                    logActivity($pdo, 'password_change', 'security', 'Password changed successfully');
                    
                    // Commit transaction
                    $pdo->commit();
                    
                    $success = "Password changed successfully! You will be redirected to login page in 3 seconds.";
                    
                    // Force logout after password change (optional - uncomment if you want to force re-login)
                    // session_destroy();
                    // header("refresh:3;url=login.php?password_changed=1");
                    
                    // Or just stay logged in with success message
                    header("refresh:3;url=profile.php?password_changed=1");
                    exit();
                }
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Database error: " . $e->getMessage();
            error_log("Password change error: " . $e->getMessage());
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "System error: " . $e->getMessage();
            error_log("Password change system error: " . $e->getMessage());
        }
    }
}

// Password strength checker function
function checkPasswordStrength($password) {
    $strength = 0;
    $feedback = [];
    
    if (strlen($password) >= 8) {
        $strength += 20;
    } else {
        $feedback[] = "Password should be at least 8 characters";
    }
    
    if (preg_match('/[A-Z]/', $password)) {
        $strength += 20;
    } else {
        $feedback[] = "Add uppercase letters";
    }
    
    if (preg_match('/[a-z]/', $password)) {
        $strength += 20;
    } else {
        $feedback[] = "Add lowercase letters";
    }
    
    if (preg_match('/[0-9]/', $password)) {
        $strength += 20;
    } else {
        $feedback[] = "Add numbers";
    }
    
    if (preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $strength += 20;
    } else {
        $feedback[] = "Add special characters";
    }
    
    return ['score' => $strength, 'feedback' => $feedback];
}

// Check password history
function checkPasswordHistory($pdo, $user_id, $new_password) {
    try {
        // Check if password_history table exists
        $table_check = $pdo->query("SHOW TABLES LIKE 'password_history'");
        if ($table_check->rowCount() == 0) {
            // Create password history table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS password_history (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id)
                )
            ");
        }
        
        // Get last 5 passwords
        $stmt = $pdo->prepare("
            SELECT password FROM password_history 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $stmt->execute([$user_id]);
        $history = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($history as $old_hash) {
            if (password_verify($new_password, $old_hash)) {
                return [
                    'allowed' => false,
                    'message' => 'You have used this password recently. Please choose a different password.'
                ];
            }
        }
        
        return ['allowed' => true, 'message' => ''];
        
    } catch (PDOException $e) {
        error_log("Password history check error: " . $e->getMessage());
        return ['allowed' => true, 'message' => '']; // Allow if table doesn't exist
    }
}

// Save password to history
function savePasswordHistory($pdo, $user_id, $password) {
    try {
        $stmt = $pdo->prepare("INSERT INTO password_history (user_id, password) VALUES (?, ?)");
        $stmt->execute([$user_id, $password]);
        
        // Keep only last 10 passwords
        $pdo->prepare("
            DELETE FROM password_history 
            WHERE user_id = ? 
            AND id NOT IN (
                SELECT id FROM (
                    SELECT id FROM password_history 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT 10
                ) AS tmp
            )
        ")->execute([$user_id, $user_id]);
        
    } catch (PDOException $e) {
        error_log("Save password history error: " . $e->getMessage());
        // Non-critical, continue
    }
}

// Log activity function (if not defined elsewhere)
if (!function_exists('logActivity')) {
    function logActivity($pdo, $action, $section, $description) {
        try {
            // Check if user_activities table exists
            $table_check = $pdo->query("SHOW TABLES LIKE 'user_activities'");
            if ($table_check->rowCount() > 0) {
                $stmt = $pdo->prepare("
                    INSERT INTO user_activities (user_id, action, section, description, ip_address, user_agent, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $_SESSION['user_id'] ?? 0,
                    $action,
                    $section,
                    $description,
                    $_SERVER['REMOTE_ADDR'] ?? null,
                    $_SERVER['HTTP_USER_AGENT'] ?? null
                ]);
            }
        } catch (PDOException $e) {
            // Silently fail - logging shouldn't break main functionality
            error_log("Log activity error: " . $e->getMessage());
        }
    }
}

// Generate password suggestions
function generatePasswordSuggestions() {
    $suggestions = [];
    
    // Suggestion 1: Random strong password
    $upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lower = 'abcdefghijklmnopqrstuvwxyz';
    $numbers = '0123456789';
    $special = '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    $password = '';
    $password .= $upper[random_int(0, strlen($upper)-1)];
    $password .= $lower[random_int(0, strlen($lower)-1)];
    $password .= $numbers[random_int(0, strlen($numbers)-1)];
    $password .= $special[random_int(0, strlen($special)-1)];
    
    // Fill remaining characters randomly
    $all = $upper . $lower . $numbers . $special;
    for ($i = 0; $i < 8; $i++) {
        $password .= $all[random_int(0, strlen($all)-1)];
    }
    
    // Shuffle password
    $suggestions[] = str_shuffle($password);
    
    // Suggestion 2: Memorable phrase based
    $words = ['Blue', 'Red', 'Green', 'Yellow', 'Happy', 'Sunny', 'Cloud', 'Star', 'Moon', 'Tree'];
    $word1 = $words[array_rand($words)];
    $word2 = $words[array_rand($words)];
    $number = random_int(10, 99);
    $symbol = ['!', '@', '#', '$', '%'][array_rand(['!', '@', '#', '$', '%'])];
    
    $suggestions[] = $word1 . $word2 . $number . $symbol;
    
    // Suggestion 3: Pattern based
    $suggestions[] = 'P@ssw0rd' . random_int(10, 99) . '!';
    
    return $suggestions;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .password-container {
            max-width: 500px;
            width: 100%;
            padding: 20px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            border: none;
            overflow: hidden;
        }
        .card-header {
            background: white;
            border-bottom: 2px solid #f0f0f0;
            padding: 30px 30px 20px;
            text-align: center;
        }
        .card-header h2 {
            color: #333;
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .card-header p {
            color: #6c757d;
            font-size: 14px;
        }
        .card-body {
            padding: 30px;
        }
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        .form-group label {
            font-weight: 500;
            color: #495057;
            margin-bottom: 8px;
            display: block;
        }
        .input-group {
            position: relative;
        }
        .input-group .material-icons {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 10;
        }
        .form-control {
            height: 50px;
            border-radius: 10px;
            border: 2px solid #e0e0e0;
            padding: 10px 15px 10px 45px;
            font-size: 16px;
            transition: all 0.3s;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
            z-index: 10;
        }
        .toggle-password:hover {
            color: #667eea;
        }
        .password-strength {
            margin-top: 10px;
        }
        .progress {
            height: 8px;
            border-radius: 4px;
            background: #e0e0e0;
            margin-bottom: 5px;
        }
        .progress-bar {
            border-radius: 4px;
            transition: width 0.3s;
        }
        .strength-text {
            font-size: 13px;
            color: #6c757d;
        }
        .feedback-item {
            font-size: 12px;
            color: #dc3545;
            margin: 2px 0;
            display: flex;
            align-items: center;
        }
        .feedback-item i {
            font-size: 14px;
            margin-right: 5px;
        }
        .password-requirements {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 25px;
        }
        .requirement {
            display: flex;
            align-items: center;
            margin: 8px 0;
            color: #6c757d;
            font-size: 13px;
        }
        .requirement i {
            margin-right: 10px;
            font-size: 16px;
        }
        .requirement.met {
            color: #28a745;
        }
        .requirement.met i {
            color: #28a745;
        }
        .btn-change {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            height: 50px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 15px;
        }
        .btn-change:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .btn-change:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        .btn-cancel {
            background: white;
            color: #6c757d;
            border: 2px solid #e0e0e0;
            height: 50px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover {
            background: #f8f9fa;
            border-color: #6c757d;
            color: #495057;
        }
        .alert {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
        }
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
        }
        .info-box {
            background: #e3f2fd;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        .info-box h5 {
            color: #1976d2;
            font-size: 14px;
            margin-bottom: 10px;
            font-weight: 600;
        }
        .password-suggestion {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 5px;
            padding: 8px 12px;
            margin: 5px 0;
            font-family: monospace;
            font-size: 14px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .password-suggestion:hover {
            background: #f8f9fa;
            border-color: #667eea;
        }
        .password-suggestion i {
            color: #28a745;
            font-size: 16px;
        }
        .user-info {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 600;
            margin: 0 auto 15px;
        }
        .user-name {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        .user-email {
            font-size: 14px;
            color: #6c757d;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        .shake {
            animation: shake 0.5s;
        }
    </style>
</head>
<body>
    <div class="password-container">
        <div class="card">
            <div class="card-header">
                <h2>Change Password</h2>
                <p>Secure your account with a strong password</p>
            </div>
            
            <div class="card-body">
                <!-- User Info -->
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($user['full_name'] ?? $user['username'] ?? 'U', 0, 1)); ?>
                    </div>
                    <div class="user-name"><?php echo htmlspecialchars($user['full_name'] ?? $user['username'] ?? 'User'); ?></div>
                    <div class="user-email"><?php echo htmlspecialchars($user['email'] ?? ''); ?></div>
                </div>
                
                <!-- Error/Success Messages -->
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show shake" role="alert">
                        <i class="material-icons" style="vertical-align: middle;">error</i>
                        <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="material-icons" style="vertical-align: middle;">check_circle</i>
                        <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                
                <!-- Password Change Form -->
                <form method="POST" action="" id="passwordForm">
                    <div class="form-group">
                        <label>Current Password</label>
                        <div class="input-group">
                            <i class="material-icons">lock</i>
                            <input type="password" name="current_password" id="current_password" 
                                   class="form-control" placeholder="Enter current password" required>
                            <span class="toggle-password" onclick="togglePassword('current_password')">
                                <i class="material-icons">visibility</i>
                            </span>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password</label>
                        <div class="input-group">
                            <i class="material-icons">vpn_key</i>
                            <input type="password" name="new_password" id="new_password" 
                                   class="form-control" placeholder="Enter new password" required
                                   onkeyup="checkPasswordStrength()">
                            <span class="toggle-password" onclick="togglePassword('new_password')">
                                <i class="material-icons">visibility</i>
                            </span>
                        </div>
                        
                        <!-- Password Strength Meter -->
                        <div class="password-strength">
                            <div class="progress">
                                <div class="progress-bar" id="strengthBar" style="width: 0%"></div>
                            </div>
                            <span class="strength-text" id="strengthText">Enter a password</span>
                            <div id="feedbackList"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <div class="input-group">
                            <i class="material-icons">lock_outline</i>
                            <input type="password" name="confirm_password" id="confirm_password" 
                                   class="form-control" placeholder="Confirm new password" required
                                   onkeyup="checkPasswordMatch()">
                            <span class="toggle-password" onclick="togglePassword('confirm_password')">
                                <i class="material-icons">visibility</i>
                            </span>
                        </div>
                        <small id="passwordMatchMsg" class="form-text"></small>
                    </div>
                    
                    <!-- Password Requirements -->
                    <div class="password-requirements">
                        <h6>Password Requirements:</h6>
                        <div class="requirement" id="req-length">
                            <i class="material-icons">check_circle_outline</i> At least 8 characters
                        </div>
                        <div class="requirement" id="req-uppercase">
                            <i class="material-icons">check_circle_outline</i> At least one uppercase letter
                        </div>
                        <div class="requirement" id="req-lowercase">
                            <i class="material-icons">check_circle_outline</i> At least one lowercase letter
                        </div>
                        <div class="requirement" id="req-number">
                            <i class="material-icons">check_circle_outline</i> At least one number
                        </div>
                        <div class="requirement" id="req-special">
                            <i class="material-icons">check_circle_outline</i> At least one special character
                        </div>
                    </div>
                    
                    <!-- Password Suggestions -->
                    <div class="info-box">
                        <h5>Suggested Strong Passwords:</h5>
                        <?php $suggestions = generatePasswordSuggestions(); ?>
                        <?php foreach ($suggestions as $suggestion): ?>
                            <div class="password-suggestion" onclick="useSuggestion('<?php echo $suggestion; ?>')">
                                <span><?php echo $suggestion; ?></span>
                                <i class="material-icons">content_copy</i>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Security Tips -->
                    <div class="info-box" style="background: #fff3e0;">
                        <h5 style="color: #f57c00;">Security Tips:</h5>
                        <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #6c757d;">
                            <li>Use a unique password you don't use elsewhere</li>
                            <li>Mix uppercase, lowercase, numbers, and symbols</li>
                            <li>Avoid personal information like names or birthdays</li>
                            <li>Change your password regularly</li>
                        </ul>
                    </div>
                    
                    <button type="submit" class="btn-change" id="submitBtn">
                        <i class="material-icons" style="vertical-align: middle;">vpn_key</i> Change Password
                    </button>
                    
                    <a href="profile.php" class="btn-cancel">
                        <i class="material-icons" style="vertical-align: middle;">cancel</i> Cancel
                    </a>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
    // Toggle password visibility
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const icon = field.nextElementSibling.querySelector('i');
        
        if (field.type === 'password') {
            field.type = 'text';
            icon.textContent = 'visibility_off';
        } else {
            field.type = 'password';
            icon.textContent = 'visibility';
        }
    }
    
    // Check password strength
    function checkPasswordStrength() {
        const password = document.getElementById('new_password').value;
        let strength = 0;
        let feedback = [];
        
        // Length check
        if (password.length >= 8) {
            strength += 20;
            document.getElementById('req-length').classList.add('met');
        } else {
            document.getElementById('req-length').classList.remove('met');
            feedback.push('Password should be at least 8 characters');
        }
        
        // Uppercase check
        if (/[A-Z]/.test(password)) {
            strength += 20;
            document.getElementById('req-uppercase').classList.add('met');
        } else {
            document.getElementById('req-uppercase').classList.remove('met');
            feedback.push('Add uppercase letters');
        }
        
        // Lowercase check
        if (/[a-z]/.test(password)) {
            strength += 20;
            document.getElementById('req-lowercase').classList.add('met');
        } else {
            document.getElementById('req-lowercase').classList.remove('met');
            feedback.push('Add lowercase letters');
        }
        
        // Number check
        if (/[0-9]/.test(password)) {
            strength += 20;
            document.getElementById('req-number').classList.add('met');
        } else {
            document.getElementById('req-number').classList.remove('met');
            feedback.push('Add numbers');
        }
        
        // Special character check
        if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
            strength += 20;
            document.getElementById('req-special').classList.add('met');
        } else {
            document.getElementById('req-special').classList.remove('met');
            feedback.push('Add special characters');
        }
        
        // Update strength bar
        const bar = document.getElementById('strengthBar');
        const text = document.getElementById('strengthText');
        const feedbackList = document.getElementById('feedbackList');
        
        bar.style.width = strength + '%';
        
        if (strength <= 20) {
            bar.className = 'progress-bar bg-danger';
            text.textContent = 'Very Weak';
        } else if (strength <= 40) {
            bar.className = 'progress-bar bg-danger';
            text.textContent = 'Weak';
        } else if (strength <= 60) {
            bar.className = 'progress-bar bg-warning';
            text.textContent = 'Fair';
        } else if (strength <= 80) {
            bar.className = 'progress-bar bg-info';
            text.textContent = 'Good';
        } else {
            bar.className = 'progress-bar bg-success';
            text.textContent = 'Strong';
        }
        
        // Display feedback
        if (feedback.length > 0 && password.length > 0) {
            let html = '';
            feedback.forEach(item => {
                html += `<div class="feedback-item"><i class="material-icons">info</i> ${item}</div>`;
            });
            feedbackList.innerHTML = html;
        } else {
            feedbackList.innerHTML = '';
        }
        
        checkPasswordMatch();
    }
    
    // Check if passwords match
    function checkPasswordMatch() {
        const newPass = document.getElementById('new_password').value;
        const confirmPass = document.getElementById('confirm_password').value;
        const msg = document.getElementById('passwordMatchMsg');
        const submitBtn = document.getElementById('submitBtn');
        
        if (confirmPass.length > 0) {
            if (newPass === confirmPass) {
                msg.innerHTML = '<span style="color: #28a745;">✓ Passwords match</span>';
                msg.style.color = '#28a745';
            } else {
                msg.innerHTML = '<span style="color: #dc3545;">✗ Passwords do not match</span>';
                msg.style.color = '#dc3545';
            }
        } else {
            msg.innerHTML = '';
        }
    }
    
    // Use suggested password
    function useSuggestion(password) {
        document.getElementById('new_password').value = password;
        document.getElementById('confirm_password').value = password;
        checkPasswordStrength();
        checkPasswordMatch();
    }
    
    // Form validation before submit
    document.getElementById('passwordForm').addEventListener('submit', function(e) {
        const newPass = document.getElementById('new_password').value;
        const confirmPass = document.getElementById('confirm_password').value;
        const strength = document.getElementById('strengthBar').style.width;
        
        if (newPass !== confirmPass) {
            e.preventDefault();
            alert('Passwords do not match!');
            return false;
        }
        
        if (parseInt(strength) < 60) {
            if (!confirm('Your password strength is weak. Are you sure you want to continue?')) {
                e.preventDefault();
                return false;
            }
        }
        
        return true;
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    
    // Add shake animation on error
    <?php if ($error): ?>
        document.querySelector('.alert-danger').classList.add('shake');
    <?php endif; ?>
    </script>
    
    <style>
    /* Additional styles for password requirements */
    .requirement.met i {
        color: #28a745 !important;
    }
    .requirement.met {
        color: #28a745 !important;
    }
    .feedback-item {
        color: #dc3545;
        font-size: 12px;
        margin: 2px 0;
    }
    .password-suggestion {
        cursor: pointer;
    }
    </style>
</body>
</html>