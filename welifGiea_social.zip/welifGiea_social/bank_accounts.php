<?php
require_once 'config.php';
requireLogin(['admin', 'finance']);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_account'])) {
        $stmt = $pdo->prepare("
            INSERT INTO bank_accounts (
                bank_name, account_number, account_holder, branch_name,
                branch_code, swift_code, iban, currency, opening_balance,
                current_balance, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_POST['bank_name'],
            $_POST['account_number'],
            $_POST['account_holder'],
            $_POST['branch_name'],
            $_POST['branch_code'],
            $_POST['swift_code'],
            $_POST['iban'],
            $_POST['currency'],
            $_POST['opening_balance'],
            $_POST['opening_balance'], // Start with opening balance
            isset($_POST['is_active']) ? 1 : 0
        ]);
        $success = "Bank account added successfully!";
    }
    
    if (isset($_POST['reconcile'])) {
        $stmt = $pdo->prepare("
            INSERT INTO bank_reconciliation (
                bank_account_id, reconciliation_date, statement_balance,
                system_balance, difference, notes, reconciled_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_POST['account_id'],
            $_POST['reconciliation_date'],
            $_POST['statement_balance'],
            $_POST['system_balance'],
            $_POST['statement_balance'] - $_POST['system_balance'],
            $_POST['notes'],
            $_SESSION['user_id']
        ]);
        
        // Update account balance
        $pdo->prepare("UPDATE bank_accounts SET current_balance = ?, last_reconciliation = ? WHERE id = ?")
            ->execute([$_POST['statement_balance'], $_POST['reconciliation_date'], $_POST['account_id']]);
        
        $success = "Account reconciled successfully!";
    }
}

// Get all bank accounts
$accounts = $pdo->query("
    SELECT ba.*, 
           COUNT(DISTINCT br.id) as reconciliation_count,
           MAX(br.reconciliation_date) as last_reconciliation
    FROM bank_accounts ba
    LEFT JOIN bank_reconciliation br ON ba.id = br.bank_account_id
    GROUP BY ba.id
    ORDER BY ba.bank_name
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Accounts Management - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Bank Accounts Management</h1>
                <button class="btn btn-primary" onclick="toggleAccountForm()">
                    <span class="material-icons">add_bank</span> Add Bank Account
                </button>
            </header>
            
            <!-- Add Account Form -->
            <div id="addAccountForm" style="display: none; background: white; border-radius: 15px; padding: 20px; margin-bottom: 20px;">
                <h3>Add New Bank Account</h3>
                <form method="POST" action="">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Bank Name *</label>
                            <input type="text" name="bank_name" required>
                        </div>
                        <div class="form-group">
                            <label>Account Number *</label>
                            <input type="text" name="account_number" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Account Holder *</label>
                            <input type="text" name="account_holder" required>
                        </div>
                        <div class="form-group">
                            <label>Branch Name</label>
                            <input type="text" name="branch_name">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Branch Code</label>
                            <input type="text" name="branch_code">
                        </div>
                        <div class="form-group">
                            <label>SWIFT Code</label>
                            <input type="text" name="swift_code">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>IBAN</label>
                            <input type="text" name="iban">
                        </div>
                        <div class="form-group">
                            <label>Currency</label>
                            <select name="currency">
                                <option value="ETB">ETB</option>
                                <option value="USD">USD</option>
                                <option value="EUR">EUR</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Opening Balance</label>
                            <input type="number" name="opening_balance" value="0" step="0.01">
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="is_active" checked>
                                Active Account
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="add_account" class="btn btn-primary">Save Account</button>
                        <button type="button" class="btn btn-secondary" onclick="toggleAccountForm()">Cancel</button>
                    </div>
                </form>
            </div>
            
            <!-- Bank Accounts List -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px;">
                <?php foreach ($accounts as $account): ?>
                <div style="background: white; border-radius: 15px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3><?php echo htmlspecialchars($account['bank_name']); ?></h3>
                        <span class="status-badge status-<?php echo $account['is_active'] ? 'active' : 'inactive'; ?>">
                            <?php echo $account['is_active'] ? 'Active' : 'Inactive'; ?>
                        </span>
                    </div>
                    
                    <p><strong>Account:</strong> <?php echo $account['account_number']; ?></p>
                    <p><strong>Holder:</strong> <?php echo $account['account_holder']; ?></p>
                    
                    <div style="margin: 15px 0; padding: 15px; background: #f5f5f5; border-radius: 8px;">
                        <div style="display: flex; justify-content: space-between;">
                            <span>Current Balance:</span>
                            <span style="font-size: 20px; font-weight: 700; color: <?php echo $account['current_balance'] >= 0 ? '#4CAF50' : '#f44336'; ?>;">
                                <?php echo $account['currency']; ?> <?php echo number_format($account['current_balance'], 2); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div style="font-size: 13px; color: #666; margin-bottom: 15px;">
                        <div>Last Reconciliation: <?php echo $account['last_reconciliation'] ? date('M j, Y', strtotime($account['last_reconciliation'])) : 'Never'; ?></div>
                        <div>Reconciliations: <?php echo $account['reconciliation_count']; ?></div>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <button class="btn btn-secondary btn-small" onclick="reconcileAccount(<?php echo $account['id']; ?>, '<?php echo $account['bank_name']; ?>', <?php echo $account['current_balance']; ?>)">
                            <span class="material-icons">sync</span> Reconcile
                        </button>
                        <a href="account_statements.php?id=<?php echo $account['id']; ?>" class="btn btn-secondary btn-small">
                            <span class="material-icons">history</span> History
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Reconciliation Modal -->
            <div id="reconciliationModal" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; border-radius: 15px; padding: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.2); z-index: 1000; width: 500px; max-width: 90%;">
                <h3 style="margin-bottom: 20px;">Reconcile Bank Account</h3>
                <form method="POST" action="" id="reconciliationForm">
                    <input type="hidden" name="account_id" id="reconcile_account_id">
                    
                    <div class="form-group">
                        <label>Bank Name</label>
                        <input type="text" id="reconcile_bank_name" readonly style="background: #f5f5f5;">
                    </div>
                    
                    <div class="form-group">
                        <label>Reconciliation Date</label>
                        <input type="date" name="reconciliation_date" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>System Balance</label>
                        <input type="text" id="reconcile_system_balance" readonly style="background: #f5f5f5;">
                    </div>
                    
                    <div class="form-group">
                        <label>Statement Balance *</label>
                        <input type="number" name="statement_balance" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Notes</label>
                        <textarea name="notes" rows="3"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="reconcile" class="btn btn-primary">Reconcile</button>
                        <button type="button" class="btn btn-secondary" onclick="closeReconciliationModal()">Cancel</button>
                    </div>
                </form>
            </div>
            
            <div id="modalOverlay" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 999;" onclick="closeReconciliationModal()"></div>
        </main>
    </div>
    
    <script>
        function toggleAccountForm() {
            const form = document.getElementById('addAccountForm');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }
        
        function reconcileAccount(id, bankName, balance) {
            document.getElementById('reconcile_account_id').value = id;
            document.getElementById('reconcile_bank_name').value = bankName;
            document.getElementById('reconcile_system_balance').value = balance;
            
            document.getElementById('reconciliationModal').style.display = 'block';
            document.getElementById('modalOverlay').style.display = 'block';
        }
        
        function closeReconciliationModal() {
            document.getElementById('reconciliationModal').style.display = 'none';
            document.getElementById('modalOverlay').style.display = 'none';
        }
    </script>
</body>
</html>