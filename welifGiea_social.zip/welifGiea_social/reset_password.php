<?php
require_once 'config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    
    // Get user
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();
    
    if ($user) {
        $hash = password_hash($new_password, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE users SET password = ?, login_attempts = 0, is_locked = 0 WHERE id = ?");
        
        if ($update->execute([$hash, $user['id']])) {
            $message = "<div class='success'>Password reset successful for " . htmlspecialchars($user['username']) . "<br>
                       New hash: " . $hash . "</div>";
        } else {
            $message = "<div class='error'>Failed to reset password</div>";
        }
    } else {
        $message = "<div class='error'>User not found</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .container { max-width: 500px; margin: 0 auto; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input[type="text"], input[type="password"] { width: 100%; padding: 8px; }
        button { background: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 3px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 3px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset User Password</h2>
        
        <?php echo $message; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Username or Email:</label>
                <input type="text" name="username" required>
            </div>
            
            <div class="form-group">
                <label>New Password:</label>
                <input type="text" name="new_password" required value="Admin@123">
                <small>Default: Admin@123</small>
            </div>
            
            <button type="submit">Reset Password</button>
        </form>
        
        <div style="margin-top: 20px; padding: 10px; background: #f5f5f5;">
            <h4>Test Accounts:</h4>
            <ul>
                <li>admin@example.com / Admin@123</li>
                <li>finance@example.com / Finance@123</li>
                <li>registration@example.com / Reg@123</li>
                <li>member@example.com / Member@123</li>
            </ul>
        </div>
    </div>
</body>
</html>