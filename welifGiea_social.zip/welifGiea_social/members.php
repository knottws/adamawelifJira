<?php
require_once 'config.php';
requireRole('registration'); // Allow registration, finance, and admin to access

$pdo = getDB();

// Pagination settings
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Search and filter
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
$status = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$family_type = isset($_GET['family_type']) ? sanitizeInput($_GET['family_type']) : '';

// Build query
$where_conditions = [];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(m.member_number LIKE ? OR m.full_name LIKE ? OR m.phone LIKE ? OR m.email LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
}

if (!empty($status)) {
    $where_conditions[] = "m.status = ?";
    $params[] = $status;
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// Get total count for pagination
$count_query = "SELECT COUNT(DISTINCT m.id) as total FROM members m $where_clause";
$count_stmt = $pdo->prepare($count_query);
$count_stmt->execute($params);
$total_members = $count_stmt->fetch()['total'];
$total_pages = ceil($total_members / $limit);

// Get members with their statistics
$query = "
    SELECT 
        m.*,
        COUNT(DISTINCT fm.id) as total_family_members,
        COUNT(DISTINCT CASE WHEN fm.family_type = 'own_family' THEN fm.id END) as own_family_count,
        COUNT(DISTINCT CASE WHEN fm.family_type = 'wife_family' THEN fm.id END) as wife_family_count,
        COUNT(DISTINCT c.id) as total_contributions,
        SUM(c.amount) as total_paid,
        MAX(c.contribution_date) as last_payment_date,
        CASE 
            WHEN EXISTS (
                SELECT 1 FROM contributions 
                WHERE member_id = m.id 
                AND status = 'pending' 
                AND payment_month = DATE_FORMAT(CURDATE(), '%Y-%m-01')
            ) THEN 'pending'
            WHEN NOT EXISTS (
                SELECT 1 FROM contributions 
                WHERE member_id = m.id 
                AND payment_month = DATE_FORMAT(CURDATE(), '%Y-%m-01')
            ) THEN 'overdue'
            ELSE 'paid'
        END as current_month_status
    FROM members m
    LEFT JOIN family_members fm ON m.id = fm.member_id
    LEFT JOIN contributions c ON m.id = c.member_id
    $where_clause
    GROUP BY m.id
    ORDER BY m.created_at DESC
    LIMIT $offset, $limit
";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$members = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Management - WelifGiea</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- DataTables CSS for advanced tables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f5f5;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5em;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 0.9em;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .menu-item i {
            width: 20px;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h1 {
            font-size: 1.8em;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .logout-btn {
            padding: 8px 20px;
            background: #ff4444;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .logout-btn:hover {
            background: #cc0000;
        }

        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5em;
        }

        .stat-info h3 {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 5px;
        }

        .stat-info .number {
            font-size: 1.8em;
            font-weight: 700;
            color: #333;
        }

        .filters-section {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .filters-form {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: flex-end;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: 500;
            font-size: 0.9em;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 0.95em;
            transition: all 0.3s ease;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 0.95em;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .btn-success {
            background: #2ecc71;
            color: white;
        }

        .btn-success:hover {
            background: #27ae60;
        }

        .btn-warning {
            background: #f39c12;
            color: white;
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid #667eea;
            color: #667eea;
        }

        .btn-outline:hover {
            background: #667eea;
            color: white;
        }

        .members-table-container {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow-x: auto;
        }

        .members-table {
            width: 100%;
            border-collapse: collapse;
        }

        .members-table th {
            text-align: left;
            padding: 15px 10px;
            background: #f8f9fa;
            color: #555;
            font-weight: 600;
            font-size: 0.9em;
            white-space: nowrap;
        }

        .members-table td {
            padding: 15px 10px;
            border-bottom: 1px solid #f0f0f0;
            vertical-align: middle;
        }

        .members-table tr:hover {
            background: #f8f9fa;
        }

        .member-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 600;
        }

        .status-active {
            background: #d4edda;
            color: #155724;
        }

        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }

        .payment-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 600;
        }

        .status-paid {
            background: #d4edda;
            color: #155724;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-overdue {
            background: #f8d7da;
            color: #721c24;
        }

        .family-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #e9ecef;
            padding: 3px 8px;
            border-radius: 15px;
            font-size: 0.8em;
            margin: 2px;
        }

        .family-badge i {
            color: #667eea;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .action-btn {
            width: 35px;
            height: 35px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .action-btn.view {
            background: #667eea;
        }

        .action-btn.view:hover {
            background: #5a67d8;
        }

        .action-btn.edit {
            background: #f39c12;
        }

        .action-btn.edit:hover {
            background: #e67e22;
        }

        .action-btn.family {
            background: #2ecc71;
        }

        .action-btn.family:hover {
            background: #27ae60;
        }

        .action-btn.payment {
            background: #9b59b6;
        }

        .action-btn.payment:hover {
            background: #8e44ad;
        }

        .action-btn.delete {
            background: #e74c3c;
        }

        .action-btn.delete:hover {
            background: #c0392b;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 30px;
        }

        .page-item {
            padding: 8px 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            color: #667eea;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .page-item:hover,
        .page-item.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }

        .page-item.disabled {
            color: #999;
            pointer-events: none;
            border-color: #e0e0e0;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }

        .modal-content {
            background: white;
            margin: 50px auto;
            padding: 30px;
            border-radius: 20px;
            max-width: 900px;
            width: 90%;
            position: relative;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .close-modal {
            position: absolute;
            right: 25px;
            top: 20px;
            font-size: 28px;
            font-weight: bold;
            color: #999;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close-modal:hover {
            color: #333;
        }

        .modal-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-body {
            max-height: 70vh;
            overflow-y: auto;
            padding-right: 10px;
        }

        .family-tree {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .family-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
        }

        .family-section h3 {
            color: #333;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1em;
        }

        .family-member {
            background: white;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .family-member .relationship {
            color: #667eea;
            font-weight: 600;
            font-size: 0.9em;
            margin-bottom: 5px;
        }

        .family-member .name {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .family-member .details {
            font-size: 0.9em;
            color: #666;
        }

        .contribution-history {
            margin-top: 20px;
        }

        .contribution-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #f0f0f0;
        }

        .contribution-item:last-child {
            border-bottom: none;
        }

        .contribution-date {
            color: #666;
            font-size: 0.9em;
        }

        .contribution-amount {
            font-weight: 600;
            color: #2ecc71;
        }

        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }

        .summary-card .label {
            font-size: 0.9em;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .summary-card .value {
            font-size: 2em;
            font-weight: 700;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            .sidebar-header h2,
            .sidebar-header p,
            .menu-item span {
                display: none;
            }
            .main-content {
                margin-left: 80px;
            }
            .menu-item {
                justify-content: center;
            }
            .menu-item i {
                margin: 0;
            }
        }

        @media (max-width: 768px) {
            .filters-form {
                flex-direction: column;
            }
            .filter-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>WelifGiea</h2>
                <p>Member Management</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="members.php" class="menu-item active">
                    <i class="fas fa-users"></i>
                    <span>Members</span>
                </a>
                <a href="register_member.php" class="menu-item">
                    <i class="fas fa-user-plus"></i>
                    <span>Register Member</span>
                </a>
                <?php if (hasRole('finance') || hasRole('admin')): ?>
                <a href="finance.php" class="menu-item">
                    <i class="fas fa-chart-line"></i>
                    <span>Finance</span>
                </a>
                <a href="contributions.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Contributions</span>
                </a>
                <?php endif; ?>
                <a href="reports.php" class="menu-item">
                    <i class="fas fa-file-alt"></i>
                    <span>Reports</span>
                </a>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1>
                    <i class="fas fa-users"></i>
                    Member Management
                </h1>
                <div class="user-info">
                    <span><i class="fas fa-user"></i> <?php echo $_SESSION['user_name']; ?></span>
                    <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Summary Cards -->
            <?php
            // Get summary statistics
            $summary_query = "
                SELECT 
                    COUNT(*) as total_members,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_members,
                    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_members,
                    (SELECT COUNT(*) FROM family_members) as total_family
                FROM members
            ";
            $summary = $pdo->query($summary_query)->fetch();
            ?>
            
            <div class="summary-cards">
                <div class="summary-card">
                    <div class="label">Total Members</div>
                    <div class="value"><?php echo $summary['total_members']; ?></div>
                </div>
                <div class="summary-card" style="background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);">
                    <div class="label">Active Members</div>
                    <div class="value"><?php echo $summary['active_members']; ?></div>
                </div>
                <div class="summary-card" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);">
                    <div class="label">Inactive Members</div>
                    <div class="value"><?php echo $summary['inactive_members']; ?></div>
                </div>
                <div class="summary-card" style="background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);">
                    <div class="label">Family Members</div>
                    <div class="value"><?php echo $summary['total_family']; ?></div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters-section">
                <form method="GET" class="filters-form">
                    <div class="filter-group">
                        <label><i class="fas fa-search"></i> Search</label>
                        <input type="text" name="search" placeholder="Member number, name, phone, email..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label><i class="fas fa-filter"></i> Status</label>
                        <select name="status">
                            <option value="">All Status</option>
                            <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                        <a href="members.php" class="btn btn-outline">
                            <i class="fas fa-times"></i> Clear
                        </a>
                        <a href="register_member.php" class="btn btn-success">
                            <i class="fas fa-user-plus"></i> Add Member
                        </a>
                    </div>
                </form>
            </div>

            <!-- Members Table -->
            <div class="members-table-container">
                <table class="members-table" id="membersTable">
                    <thead>
                        <tr>
                            <th>Member #</th>
                            <th>Member Details</th>
                            <th>Contact</th>
                            <th>Family Members</th>
                            <th>Contribution Status</th>
                            <th>Payment History</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($members as $member): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($member['member_number']); ?></strong>
                                <br>
                                <small>Since: <?php echo date('M Y', strtotime($member['registration_date'])); ?></small>
                            </td>
                            
                            <td>
                                <strong><?php echo htmlspecialchars($member['full_name']); ?></strong>
                                <?php if (!empty($member['occupation'])): ?>
                                <br>
                                <small><i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($member['occupation']); ?></small>
                                <?php endif; ?>
                            </td>
                            
                            <td>
                                <?php if (!empty($member['phone'])): ?>
                                <div><i class="fas fa-phone"></i> <?php echo htmlspecialchars($member['phone']); ?></div>
                                <?php endif; ?>
                                <?php if (!empty($member['email'])): ?>
                                <div><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($member['email']); ?></div>
                                <?php endif; ?>
                            </td>
                            
                            <td>
                                <div class="family-badge">
                                    <i class="fas fa-home"></i> Own: <?php echo $member['own_family_count']; ?>
                                </div>
                                <div class="family-badge">
                                    <i class="fas fa-heart"></i> Wife's: <?php echo $member['wife_family_count']; ?>
                                </div>
                                <div class="family-badge">
                                    <i class="fas fa-users"></i> Total: <?php echo $member['total_family_members']; ?>
                                </div>
                            </td>
                            
                            <td>
                                <?php
                                $status_class = '';
                                $status_text = '';
                                switch ($member['current_month_status']) {
                                    case 'paid':
                                        $status_class = 'status-paid';
                                        $status_text = 'Paid';
                                        break;
                                    case 'pending':
                                        $status_class = 'status-pending';
                                        $status_text = 'Pending';
                                        break;
                                    case 'overdue':
                                        $status_class = 'status-overdue';
                                        $status_text = 'Overdue';
                                        break;
                                }
                                ?>
                                <span class="payment-status <?php echo $status_class; ?>">
                                    <?php echo $status_text; ?>
                                </span>
                                <?php if ($member['total_paid'] > 0): ?>
                                <br>
                                <small>Total: <?php echo formatCurrency($member['total_paid']); ?></small>
                                <?php endif; ?>
                            </td>
                            
                            <td>
                                <?php if ($member['last_payment_date']): ?>
                                <div>Last: <?php echo date('d/m/Y', strtotime($member['last_payment_date'])); ?></div>
                                <?php else: ?>
                                <div>No payments yet</div>
                                <?php endif; ?>
                                <div>Total: <?php echo $member['total_contributions']; ?> payments</div>
                            </td>
                            
                            <td>
                                <span class="member-status status-<?php echo $member['status']; ?>">
                                    <?php echo ucfirst($member['status']); ?>
                                </span>
                            </td>
                            
                            <td>
                                <div class="action-buttons">
                                    <button class="action-btn view" onclick="viewMember(<?php echo $member['id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="action-btn edit" onclick="editMember(<?php echo $member['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="action-btn family" onclick="viewFamily(<?php echo $member['id']; ?>)">
                                        <i class="fas fa-users"></i>
                                    </button>
                                    <?php if (hasRole('finance') || hasRole('admin')): ?>
                                    <button class="action-btn payment" onclick="recordPayment(<?php echo $member['id']; ?>)">
                                        <i class="fas fa-money-bill"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php if (hasRole('admin')): ?>
                                    <button class="action-btn delete" onclick="deleteMember(<?php echo $member['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        
                        <?php if (empty($members)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 50px;">
                                <i class="fas fa-users" style="font-size: 3em; color: #ccc; margin-bottom: 15px;"></i>
                                <h3 style="color: #666;">No members found</h3>
                                <p style="color: #999; margin-bottom: 20px;">Try adjusting your filters or add a new member</p>
                                <a href="register_member.php" class="btn btn-primary">
                                    <i class="fas fa-user-plus"></i> Add New Member
                                </a>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                <a href="?page=1&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>" 
                   class="page-item">&laquo; First</a>
                <a href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>" 
                   class="page-item">Previous</a>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page-2); $i <= min($page+2, $total_pages); $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>" 
                   class="page-item <?php echo $i == $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>" 
                   class="page-item">Next</a>
                <a href="?page=<?php echo $total_pages; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>" 
                   class="page-item">Last &raquo;</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- View Member Modal -->
    <div id="viewMemberModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h2><i class="fas fa-user-circle"></i> Member Details</h2>
            </div>
            <div class="modal-body" id="memberDetailsContent">
                <!-- Content loaded via AJAX -->
                <div style="text-align: center; padding: 50px;">
                    <i class="fas fa-spinner fa-spin fa-3x"></i>
                    <p>Loading member details...</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Family Members Modal -->
    <div id="familyModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h2><i class="fas fa-users"></i> Family Members</h2>
            </div>
            <div class="modal-body" id="familyDetailsContent">
                <!-- Content loaded via AJAX -->
                <div style="text-align: center; padding: 50px;">
                    <i class="fas fa-spinner fa-spin fa-3x"></i>
                    <p>Loading family details...</p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
        // Modal functionality
        const modals = document.querySelectorAll('.modal');
        const closeBtns = document.querySelectorAll('.close-modal');

        closeBtns.forEach(btn => {
            btn.onclick = function() {
                modals.forEach(modal => modal.style.display = 'none');
            };
        });

        window.onclick = function(event) {
            modals.forEach(modal => {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            });
        };

        // View member details
        function viewMember(memberId) {
            const modal = document.getElementById('viewMemberModal');
            const content = document.getElementById('memberDetailsContent');
            
            modal.style.display = 'block';
            
            // Load member details via AJAX
            $.ajax({
                url: 'get_member_details.php',
                method: 'POST',
                data: { member_id: memberId },
                success: function(response) {
                    content.innerHTML = response;
                },
                error: function() {
                    content.innerHTML = '<div style="text-align: center; padding: 50px; color: red;">Error loading member details</div>';
                }
            });
        }

        // View family members
        function viewFamily(memberId) {
            const modal = document.getElementById('familyModal');
            const content = document.getElementById('familyDetailsContent');
            
            modal.style.display = 'block';
            
            // Load family details via AJAX
            $.ajax({
                url: 'get_family_details.php',
                method: 'POST',
                data: { member_id: memberId },
                success: function(response) {
                    content.innerHTML = response;
                },
                error: function() {
                    content.innerHTML = '<div style="text-align: center; padding: 50px; color: red;">Error loading family details</div>';
                }
            });
        }

        // Edit member
        function editMember(memberId) {
            window.location.href = 'edit_member.php?id=' + memberId;
        }

        // Record payment
        function recordPayment(memberId) {
            window.location.href = 'record_payment.php?member_id=' + memberId;
        }

        // Delete member (admin only)
        function deleteMember(memberId) {
            if (confirm('Are you sure you want to delete this member? This action cannot be undone and will also delete all family members and contribution records.')) {
                $.ajax({
                    url: 'delete_member.php',
                    method: 'POST',
                    data: { 
                        member_id: memberId,
                        csrf_token: '<?php echo generateCSRFToken(); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('Member deleted successfully');
                            location.reload();
                        } else {
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('Error deleting member');
                    }
                });
            }
        }

        // Initialize DataTable for advanced features
        $(document).ready(function() {
            $('#membersTable').DataTable({
                paging: false,
                searching: false,
                ordering: true,
                info: false,
                responsive: true
            });
        });
    </script>
</body>
</html>