<?php
/**
 * Role Management Page
 * For welifgiea_social database
 */

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration - THIS IS CRITICAL
require_once __DIR__ . '/config.php';

// Check if $pdo is defined
if (!isset($pdo)) {
    die("Database connection not found. Please check your config.php file.");
}

// Define timeAgo function if not exists
if (!function_exists('timeAgo')) {
    function timeAgo($timestamp) {
        if (!$timestamp) return 'N/A';
        $time_ago = strtotime($timestamp);
        $current_time = time();
        $time_difference = $current_time - $time_ago;
        
        if ($time_difference < 60) return 'Just now';
        if ($time_difference < 3600) return round($time_difference / 60) . 'm ago';
        if ($time_difference < 86400) return round($time_difference / 3600) . 'h ago';
        if ($time_difference < 2592000) return round($time_difference / 86400) . 'd ago';
        return date('M j, Y', $time_ago);
    }
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Update last activity
$_SESSION['last_activity'] = time();

$error = '';
$success = '';
$roles = [];
$permissions = [];
$role_permissions = [];

try {
    // First, check if roles table exists
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS roles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            role_code VARCHAR(50) UNIQUE NOT NULL,
            role_name VARCHAR(100) NOT NULL,
            description TEXT,
            is_system TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_role_code (role_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Check if permissions table exists
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS permissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            permission_code VARCHAR(100) UNIQUE NOT NULL,
            permission_name VARCHAR(100) NOT NULL,
            module VARCHAR(50) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_module (module)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Check if role_permissions table exists
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS role_permissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            role_id INT NOT NULL,
            permission_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
            FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
            UNIQUE KEY unique_role_permission (role_id, permission_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Insert default roles if they don't exist
    $default_roles = [
        ['admin', 'Administrator', 'Full system access', 1],
        ['finance', 'Finance Officer', 'Can manage financial transactions', 1],
        ['registration', 'Registration Officer', 'Can manage member registrations', 1],
        ['member', 'Member', 'Basic member access', 1]
    ];
    
    $insert_role = $pdo->prepare("
        INSERT IGNORE INTO roles (role_code, role_name, description, is_system) 
        VALUES (?, ?, ?, ?)
    ");
    
    foreach ($default_roles as $role) {
        $insert_role->execute($role);
    }
    
    // Insert default permissions
    $default_permissions = [
        // Dashboard permissions
        ['view_dashboard', 'View Dashboard', 'core', 'Access to view dashboard'],
        ['view_admin_dashboard', 'View Admin Dashboard', 'core', 'Access to admin dashboard'],
        ['view_finance_dashboard', 'View Finance Dashboard', 'core', 'Access to finance dashboard'],
        ['view_registration_dashboard', 'View Registration Dashboard', 'core', 'Access to registration dashboard'],
        ['view_member_dashboard', 'View Member Dashboard', 'core', 'Access to member dashboard'],
        
        // User management permissions
        ['view_users', 'View Users', 'users', 'Can view user list'],
        ['create_users', 'Create Users', 'users', 'Can create new users'],
        ['edit_users', 'Edit Users', 'users', 'Can edit existing users'],
        ['delete_users', 'Delete Users', 'users', 'Can delete users'],
        ['manage_roles', 'Manage Roles', 'users', 'Can manage roles and permissions'],
        
        // Member management permissions
        ['view_members', 'View Members', 'members', 'Can view member list'],
        ['create_members', 'Create Members', 'members', 'Can register new members'],
        ['edit_members', 'Edit Members', 'members', 'Can edit member details'],
        ['delete_members', 'Delete Members', 'members', 'Can delete members'],
        ['approve_members', 'Approve Members', 'members', 'Can approve member registrations'],
        
        // Finance permissions
        ['view_finances', 'View Finances', 'finance', 'Can view financial data'],
        ['create_transactions', 'Create Transactions', 'finance', 'Can create transactions'],
        ['edit_transactions', 'Edit Transactions', 'finance', 'Can edit transactions'],
        ['delete_transactions', 'Delete Transactions', 'finance', 'Can delete transactions'],
        ['approve_transactions', 'Approve Transactions', 'finance', 'Can approve transactions'],
        ['view_reports', 'View Reports', 'finance', 'Can view financial reports'],
        ['export_data', 'Export Data', 'finance', 'Can export financial data'],
        
        // System permissions
        ['view_settings', 'View Settings', 'system', 'Can view system settings'],
        ['edit_settings', 'Edit Settings', 'system', 'Can edit system settings'],
        ['view_logs', 'View Logs', 'system', 'Can view activity logs'],
        ['manage_backup', 'Manage Backup', 'system', 'Can manage backups'],
    ];
    
    $insert_permission = $pdo->prepare("
        INSERT IGNORE INTO permissions (permission_code, permission_name, module, description) 
        VALUES (?, ?, ?, ?)
    ");
    
    foreach ($default_permissions as $perm) {
        $insert_permission->execute($perm);
    }
    
    // Assign default permissions to admin role
    $admin_role = $pdo->query("SELECT id FROM roles WHERE role_code = 'admin'")->fetch();
    if ($admin_role) {
        // Get all permission IDs
        $all_perms = $pdo->query("SELECT id FROM permissions")->fetchAll(PDO::FETCH_COLUMN);
        
        // Clear existing permissions
        $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ?")->execute([$admin_role['id']]);
        
        // Assign all permissions to admin
        $insert = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
        foreach ($all_perms as $perm_id) {
            $insert->execute([$admin_role['id'], $perm_id]);
        }
    }
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['add_role'])) {
            $role_code = strtoupper(trim($_POST['role_code'] ?? ''));
            $role_name = trim($_POST['role_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            
            if (empty($role_code) || empty($role_name)) {
                $error = "Role code and name are required.";
            } elseif (!preg_match('/^[A-Z0-9_]+$/', $role_code)) {
                $error = "Role code must contain only uppercase letters, numbers, and underscores.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO roles (role_code, role_name, description) VALUES (?, ?, ?)");
                    $stmt->execute([$role_code, $role_name, $description]);
                    $success = "Role added successfully!";
                } catch (PDOException $e) {
                    if ($e->errorInfo[1] == 1062) {
                        $error = "Role code already exists.";
                    } else {
                        $error = "Database error: " . $e->getMessage();
                    }
                }
            }
        } elseif (isset($_POST['edit_role'])) {
            $role_id = $_POST['role_id'] ?? 0;
            $role_name = trim($_POST['role_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            
            if (empty($role_name)) {
                $error = "Role name is required.";
            } else {
                try {
                    // Check if it's a system role
                    $check = $pdo->prepare("SELECT is_system FROM roles WHERE id = ?");
                    $check->execute([$role_id]);
                    $role = $check->fetch();
                    
                    if ($role && $role['is_system']) {
                        $error = "System roles cannot be edited.";
                    } else {
                        $stmt = $pdo->prepare("UPDATE roles SET role_name = ?, description = ? WHERE id = ?");
                        $stmt->execute([$role_name, $description, $role_id]);
                        $success = "Role updated successfully!";
                    }
                } catch (PDOException $e) {
                    $error = "Database error: " . $e->getMessage();
                }
            }
        } elseif (isset($_POST['delete_role'])) {
            $role_id = $_POST['role_id'] ?? 0;
            
            try {
                // Check if it's a system role
                $check = $pdo->prepare("SELECT is_system, role_code FROM roles WHERE id = ?");
                $check->execute([$role_id]);
                $role = $check->fetch();
                
                if (!$role) {
                    $error = "Role not found.";
                } elseif ($role['is_system']) {
                    $error = "System roles cannot be deleted.";
                } else {
                    // Check if role is assigned to any users
                    $user_check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = ?");
                    $user_check->execute([$role['role_code']]);
                    $user_count = $user_check->fetchColumn();
                    
                    if ($user_count > 0) {
                        $error = "Cannot delete role that is assigned to $user_count user(s).";
                    } else {
                        $stmt = $pdo->prepare("DELETE FROM roles WHERE id = ?");
                        $stmt->execute([$role_id]);
                        $success = "Role deleted successfully!";
                    }
                }
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        } elseif (isset($_POST['update_permissions'])) {
            $role_id = $_POST['role_id'] ?? 0;
            $permissions_selected = $_POST['permissions'] ?? [];
            
            try {
                // Start transaction
                $pdo->beginTransaction();
                
                // Clear existing permissions
                $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ?")->execute([$role_id]);
                
                // Insert new permissions
                if (!empty($permissions_selected)) {
                    $insert = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
                    foreach ($permissions_selected as $perm_id) {
                        $insert->execute([$role_id, $perm_id]);
                    }
                }
                
                $pdo->commit();
                $success = "Permissions updated successfully!";
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
    
    // Get all roles with user counts
    $roles_sql = "
        SELECT r.*, 
               (SELECT COUNT(*) FROM users WHERE role = r.role_code) as user_count
        FROM roles r
        ORDER BY r.is_system DESC, r.role_name ASC
    ";
    $roles = $pdo->query($roles_sql)->fetchAll(PDO::FETCH_ASSOC);
    
    // Get all permissions grouped by module
    $permissions_sql = "SELECT * FROM permissions ORDER BY module, permission_name";
    $all_permissions = $pdo->query($permissions_sql)->fetchAll(PDO::FETCH_ASSOC);
    
    // Group permissions by module
    foreach ($all_permissions as $perm) {
        $permissions[$perm['module']][] = $perm;
    }
    
    // Get permissions for selected role (if any)
    if (isset($_GET['role_id'])) {
        $perm_stmt = $pdo->prepare("
            SELECT permission_id FROM role_permissions WHERE role_id = ?
        ");
        $perm_stmt->execute([$_GET['role_id']]);
        $role_permissions = $perm_stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    error_log("Roles.php error: " . $e->getMessage());
    $roles = [];
    $permissions = [];
}

// Include sidebar - make sure this path is correct
$sidebar_path = __DIR__ . '/includes/sidebar.php';
if (file_exists($sidebar_path)) {
    include $sidebar_path;
} else {
    // Fallback if sidebar doesn't exist
    echo "<!-- Sidebar not found -->";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Role Management - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 20px;
            min-height: 100vh;
        }
        
        .card {
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 20px;
        }
        
        .card-header {
            background: #2c3e50;
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .card-header h3 {
            margin: 0;
            font-size: 1.2rem;
        }
        
        .badge-system {
            background: #6c757d;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
        }
        
        .role-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .role-badge.admin { background: #f44336; color: white; }
        .role-badge.finance { background: #4CAF50; color: white; }
        .role-badge.registration { background: #FF9800; color: white; }
        .role-badge.member { background: #2196F3; color: white; }
        
        .permission-group {
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
        }
        
        .permission-group h5 {
            margin-top: 0;
            margin-bottom: 15px;
            color: #333;
            font-size: 1rem;
            font-weight: 600;
        }
        
        .permission-item {
            margin: 8px 0;
            display: inline-block;
            width: 33%;
        }
        
        .modal-content {
            border-radius: 12px;
        }
        
        .modal-header {
            background: #2c3e50;
            color: white;
            border-radius: 12px 12px 0 0;
        }
        
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            margin-bottom: 20px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
        }
        
        .table th {
            background: #f8f9fa;
            border-top: none;
            font-weight: 600;
            font-size: 13px;
        }
        
        .table td {
            font-size: 13px;
            vertical-align: middle;
        }
        
        .alert {
            border-radius: 8px;
            border: none;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 70px;
            }
            .permission-item {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <!-- Navigation Bar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white rounded-3 mb-4 shadow-sm">
            <div class="container-fluid">
                <span class="navbar-brand">
                    <i class="fas fa-shield-alt me-2"></i>
                    Role Management
                </span>
                <div class="navbar-nav ms-auto">
                    <span class="nav-item nav-link">
                        <i class="fas fa-user me-1"></i>
                        <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?>
                    </span>
                    <a href="admin_dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt me-1"></i>
                        Dashboard
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-number"><?php echo count($roles); ?></div>
                    <div class="stats-label">Total Roles</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-number">
                        <?php 
                        $system_roles = array_filter($roles, function($r) { return $r['is_system'] ?? 0; });
                        echo count($system_roles);
                        ?>
                    </div>
                    <div class="stats-label">System Roles</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-number">
                        <?php 
                        $custom_roles = array_filter($roles, function($r) { return !($r['is_system'] ?? 0); });
                        echo count($custom_roles);
                        ?>
                    </div>
                    <div class="stats-label">Custom Roles</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="stats-number"><?php echo count($all_permissions ?? []); ?></div>
                    <div class="stats-label">Permissions</div>
                </div>
            </div>
        </div>
        
        <!-- Error/Success Messages -->
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- Main Content Row -->
        <div class="row">
            <!-- Add Role Form -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-plus-circle me-2"></i>Add New Role</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Role Code</label>
                                <input type="text" name="role_code" class="form-control" 
                                       placeholder="e.g., MANAGER" pattern="[A-Z0-9_]+" 
                                       title="Uppercase letters, numbers, and underscores only" required>
                                <small class="text-muted">Uppercase letters, numbers, underscores only</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Role Name</label>
                                <input type="text" name="role_name" class="form-control" 
                                       placeholder="e.g., Manager" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea name="description" class="form-control" rows="3"></textarea>
                            </div>
                            <button type="submit" name="add_role" class="btn btn-primary w-100">
                                <i class="fas fa-save me-2"></i>Add Role
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Roles List -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-list me-2"></i>System Roles</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Type</th>
                                        <th>Users</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($roles)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">No roles found</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($roles as $role): ?>
                                        <tr>
                                            <td><strong><?php echo htmlspecialchars($role['role_code']); ?></strong></td>
                                            <td>
                                                <?php echo htmlspecialchars($role['role_name']); ?>
                                                <?php if ($role['is_system']): ?>
                                                    <span class="badge-system ms-2">System</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($role['description'] ?: '-'); ?></td>
                                            <td>
                                                <span class="role-badge <?php echo $role['role_code']; ?>">
                                                    <?php echo ucfirst($role['role_code']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info text-white"><?php echo $role['user_count']; ?></span>
                                            </td>
                                            <td>
                                                <?php if (!$role['is_system']): ?>
                                                    <button class="btn btn-sm btn-warning" 
                                                            onclick="editRole(<?php echo $role['id']; ?>, '<?php echo htmlspecialchars($role['role_name']); ?>', '<?php echo htmlspecialchars($role['description']); ?>')">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-danger" 
                                                            onclick="deleteRole(<?php echo $role['id']; ?>, '<?php echo htmlspecialchars($role['role_name']); ?>')"
                                                            <?php echo $role['user_count'] > 0 ? 'disabled' : ''; ?>>
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <button class="btn btn-sm btn-primary" 
                                                        onclick="managePermissions(<?php echo $role['id']; ?>)">
                                                    <i class="fas fa-key"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Role Modal -->
    <div class="modal fade" id="editRoleModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="role_id" id="edit_role_id">
                        <div class="mb-3">
                            <label class="form-label">Role Name</label>
                            <input type="text" name="role_name" id="edit_role_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" id="edit_role_description" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="edit_role" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete Role Modal -->
    <div class="modal fade" id="deleteRoleModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Delete Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="role_id" id="delete_role_id">
                        <p>Are you sure you want to delete role: <strong id="delete_role_name"></strong>?</p>
                        <p class="text-danger">This action cannot be undone.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="delete_role" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Manage Permissions Modal -->
    <div class="modal fade" id="permissionsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Manage Permissions</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="role_id" id="perm_role_id">
                        <?php if (!empty($permissions)): ?>
                            <?php foreach ($permissions as $module => $module_perms): ?>
                                <div class="permission-group">
                                    <h5><?php echo ucfirst($module); ?></h5>
                                    <?php foreach ($module_perms as $perm): ?>
                                        <div class="permission-item">
                                            <div class="form-check">
                                                <input type="checkbox" 
                                                       class="form-check-input" 
                                                       name="permissions[]" 
                                                       value="<?php echo $perm['id']; ?>" 
                                                       id="perm_<?php echo $perm['id']; ?>">
                                                <label class="form-check-label" for="perm_<?php echo $perm['id']; ?>">
                                                    <?php echo htmlspecialchars($perm['permission_name']); ?>
                                                    <small class="text-muted d-block"><?php echo $perm['permission_code']; ?></small>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted">No permissions found.</p>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_permissions" class="btn btn-primary">Update Permissions</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Edit role
    function editRole(id, name, description) {
        document.getElementById('edit_role_id').value = id;
        document.getElementById('edit_role_name').value = name;
        document.getElementById('edit_role_description').value = description;
        new bootstrap.Modal(document.getElementById('editRoleModal')).show();
    }
    
    // Delete role
    function deleteRole(id, name) {
        document.getElementById('delete_role_id').value = id;
        document.getElementById('delete_role_name').textContent = name;
        new bootstrap.Modal(document.getElementById('deleteRoleModal')).show();
    }
    
    // Manage permissions
    function managePermissions(roleId) {
        document.getElementById('perm_role_id').value = roleId;
        
        // Fetch current permissions via AJAX
        fetch(`get_role_permissions.php?role_id=${roleId}`)
            .then(response => response.json())
            .then(data => {
                // Uncheck all checkboxes
                document.querySelectorAll('input[name="permissions[]"]').forEach(cb => {
                    cb.checked = false;
                });
                
                // Check assigned permissions
                if (data.permissions && data.permissions.length) {
                    data.permissions.forEach(permId => {
                        const checkbox = document.getElementById(`perm_${permId}`);
                        if (checkbox) checkbox.checked = true;
                    });
                }
            })
            .catch(error => console.error('Error:', error));
        
        new bootstrap.Modal(document.getElementById('permissionsModal')).show();
    }
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        document.querySelectorAll('.alert').forEach(alert => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
    </script>
</body>
</html>