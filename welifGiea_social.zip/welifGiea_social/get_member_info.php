<?php
require_once 'config.php';
requireLogin();

if (!isset($_POST['member_id'])) {
    die(json_encode(['error' => 'Member ID not provided']));
}

$member_id = (int)$_POST['member_id'];
$pdo = getDB();

// Get member info
$stmt = $pdo->prepare("
    SELECT m.*, 
           MAX(c.contribution_date) as last_payment_date,
           SUM(c.amount) as total_paid
    FROM members m
    LEFT JOIN contributions c ON m.id = c.member_id
    WHERE m.id = ?
    GROUP BY m.id
");
$stmt->execute([$member_id]);
$member = $stmt->fetch();

if (!$member) {
    die(json_encode(['error' => 'Member not found']));
}

// Get last payment info
$last_payment = 'No payments yet';
if ($member['last_payment_date']) {
    $last_payment = date('d/m/Y', strtotime($member['last_payment_date']));
}

echo json_encode([
    'member_number' => $member['member_number'],
    'phone' => $member['phone'],
    'last_payment' => $last_payment,
    'total_paid' => $member['total_paid'] ?? 0,
    'status' => $member['status']
]);
?>