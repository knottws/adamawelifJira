<?php
// user_edit.php
require_once 'config.php';

if (!isLoggedIn() || $_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$pdo = getDB();
$error = '';

// Get user ID from URL
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$user_id) {
    header('Location: users.php');
    exit();
}

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['flash_message'] = 'User not found.';
    $_SESSION['flash_type'] = 'error';
    header('Location: users.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token.';
    } else {
        $email = sanitizeInput($_POST['email'] ?? '');
        $full_name = sanitizeInput($_POST['full_name'] ?? '');
        $role = sanitizeInput($_POST['role'] ?? 'member');
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        // Validation
        if (empty($email) || empty($full_name)) {
            $error = 'Full name and email are required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format.';
        } else {
            try {
                // Check if email exists for another user
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $stmt->execute([$email, $user_id]);
                if ($stmt->fetch()) {
                    $error = 'Email already exists for another user.';
                } else {
                    // Update user
                    if (!empty($new_password)) {
                        // Validate new password
                        if (strlen($new_password) < 8) {
                            $error = 'Password must be at least 8 characters long.';
                        } elseif (!preg_match('/[A-Z]/', $new_password) || !preg_match('/[a-z]/', $new_password) || !preg_match('/[0-9]/', $new_password)) {
                            $error = 'Password must contain at least one uppercase letter, one lowercase letter, and one number.';
                        } elseif ($new_password !== $confirm_password) {
                            $error = 'Passwords do not match.';
                        } else {
                            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                            $stmt = $pdo->prepare("UPDATE users SET email = ?, full_name = ?, role = ?, is_active = ?, password = ? WHERE id = ?");
                            $stmt->execute([$email, $full_name, $role, $is_active, $hashed_password, $user_id]);
                        }
                    } else {
                        $stmt = $pdo->prepare("UPDATE users SET email = ?, full_name = ?, role = ?, is_active = ? WHERE id = ?");
                        $stmt->execute([$email, $full_name, $role, $is_active, $user_id]);
                    }

                    if (empty($error)) {
                        logActivity('Edit User', "Edited user ID: $user_id");
                        $_SESSION['flash_message'] = 'User updated successfully.';
                        $_SESSION['flash_type'] = 'success';
                        header('Location: users.php');
                        exit();
                    }
                }
            } catch (Exception $e) {
                error_log("User update error: " . $e->getMessage());
                $error = 'An error occurred. Please try again.';
            }
        }
    }
}

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - WelifGiea</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Same styles as user_add.php with some additions */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .form-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #333;
            font-size: 2em;
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 14px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 1em;
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        .form-group.checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group.checkbox input {
            width: auto;
        }

        .btn-primary {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            width: 100%;
            padding: 16px;
            background: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 12px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 15px;
        }

        .btn-secondary:hover {
            background: #d0d0d0;
        }

        .error-message {
            background: #fef2f2;
            color: #991b1b;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            text-align: center;
            border-left: 4px solid #dc2626;
        }

        .info-text {
            font-size: 0.9em;
            color: #666;
            margin-top: 5px;
        }

        .user-info {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid #e2e8f0;
        }

        .user-info-item {
            display: flex;
            margin-bottom: 10px;
        }

        .user-info-item .label {
            width: 120px;
            color: #64748b;
            font-weight: 500;
        }

        .user-info-item .value {
            color: #334155;
            font-weight: 500;
        }

        .toggle-password {
            margin: 15px 0;
            padding: 10px;
            background: #f8fafc;
            border-radius: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #667eea;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-card">
            <div class="header">
                <h1>Edit User</h1>
                <p>Update user information</p>
            </div>

            <div class="user-info">
                <div class="user-info-item">
                    <span class="label">Username:</span>
                    <span class="value"><?php echo htmlspecialchars($user['username']); ?></span>
                </div>
                <div class="user-info-item">
                    <span class="label">Created:</span>
                    <span class="value"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></span>
                </div>
                <div class="user-info-item">
                    <span class="label">Last Login:</span>
                    <span class="value"><?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?></span>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="full_name" required 
                           value="<?php echo htmlspecialchars($user['full_name']); ?>"
                           placeholder="Enter full name">
                </div>

                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required 
                           value="<?php echo htmlspecialchars($user['email']); ?>"
                           placeholder="Enter email address">
                </div>

                <div class="form-group">
                    <label>Role *</label>
                    <select name="required>
                        <option value="member" <?php echo $user['role'] === 'member' ? 'selected' : ''; ?>>Member</option>
                        <option value="registration" <?php echo $user['role'] === 'registration' ? 'selected' : ''; ?>>Registration Officer</option>
                        <option value="finance" <?php echo $user['role'] === 'finance' ? 'selected' : ''; ?>>Finance Officer</option>
                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Administrator</option>
                    </select>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" name="is_active" id="is_active" <?php echo $user['is_active'] ? 'checked' : ''; ?>>
                    <label for="is_active">Account Active</label>
                </div>

                <div class="toggle-password" onclick="togglePasswordFields()">
                    <i class="fas fa-key"></i>
                    <span>Change Password (Click to show/hide)</span>
                </div>

                <div id="passwordFields" style="display: none;">
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" id="new_password" 
                               placeholder="Enter new password" onkeyup="checkPasswordStrength()">
                    </div>

                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" id="confirm_password" 
                               placeholder="Confirm new password" onkeyup="checkPasswordMatch()">
                    </div>

                    <div class="password-requirements" id="passwordRequirements">
                        <ul>
                            <li id="length"><i class="fas fa-times-circle"></i> At least 8 characters</li>
                            <li id="uppercase"><i class="fas fa-times-circle"></i> At least one uppercase letter</li>
                            <li id="lowercase"><i class="fas fa-times-circle"></i> At least one lowercase letter</li>
                            <li id="number"><i class="fas fa-times-circle"></i> At least one number</li>
                            <li id="match"><i class="fas fa-times-circle"></i> Passwords match</li>
                        </ul>
                    </div>
                </div>

                <button type="submit" class="btn-primary">
                    <i class="fas fa-save"></i> Update User
                </button>

                <a href="users.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Users
                </a>
            </form>
        </div>
    </div>

    <script>
        function togglePasswordFields() {
            const passwordFields = document.getElementById('passwordFields');
            if (passwordFields.style.display === 'none') {
                passwordFields.style.display = 'block';
            } else {
                passwordFields.style.display = 'none';
                // Clear password fields
                document.getElementById('new_password').value = '';
                document.getElementById('confirm_password').value = '';
            }
        }

        function checkPasswordStrength() {
            const password = document.getElementById('new_password').value;
            
            // Check length
            document.getElementById('length').className = password.length >= 8 ? 'valid' : 'invalid';
            document.getElementById('length').innerHTML = (password.length >= 8 ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least 8 characters';
            
            // Check uppercase
            document.getElementById('uppercase').className = /[A-Z]/.test(password) ? 'valid' : 'invalid';
            document.getElementById('uppercase').innerHTML = (/[A-Z]/.test(password) ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least one uppercase letter';
            
            // Check lowercase
            document.getElementById('lowercase').className = /[a-z]/.test(password) ? 'valid' : 'invalid';
            document.getElementById('lowercase').innerHTML = (/[a-z]/.test(password) ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least one lowercase letter';
            
            // Check number
            document.getElementById('number').className = /[0-9]/.test(password) ? 'valid' : 'invalid';
            document.getElementById('number').innerHTML = (/[0-9]/.test(password) ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least one number';
        }

        function checkPasswordMatch() {
            const password = document.getElementById('new_password').value;
            const confirm = document.getElementById('confirm_password').value;
            const matchElement = document.getElementById('match');
            
            if (confirm.length > 0) {
                matchElement.className = password === confirm ? 'valid' : 'invalid';
                matchElement.innerHTML = (password === confirm ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' Passwords match';
            }
        }
    </script>
</body>
</html>