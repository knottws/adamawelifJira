<?php
require_once 'config.php';
requireLogin();

if (!isset($_POST['member_id'])) {
    die('Member ID not provided');
}

$member_id = (int)$_POST['member_id'];
$pdo = getDB();

// Get member info
$stmt = $pdo->prepare("SELECT full_name, member_number FROM members WHERE id = ?");
$stmt->execute([$member_id]);
$member = $stmt->fetch();

if (!$member) {
    die('Member not found');
}

// Get all family members
$stmt = $pdo->prepare("
    SELECT * FROM family_members 
    WHERE member_id = ? 
    ORDER BY family_type, FIELD(relationship, 'father', 'mother', 'brother', 'sister', 'son', 'daughter', 'other')
");
$stmt->execute([$member_id]);
$family_members = $stmt->fetchAll();

// Group by family type
$own_family = array_filter($family_members, function($fm) {
    return $fm['family_type'] == 'own_family';
});

$wife_family = array_filter($family_members, function($fm) {
    return $fm['family_type'] == 'wife_family';
});
?>

<div style="padding: 20px;">
    <div style="margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;">
        <h2 style="font-size: 1.5em; color: #333;">
            <?php echo htmlspecialchars($member['full_name']); ?>'s Family Tree
        </h2>
        <p style="color: #667eea;">Member #<?php echo htmlspecialchars($member['member_number']); ?></p>
    </div>

    <div class="family-tree">
        <!-- Own Family Section -->
        <div class="family-section">
            <h3>
                <i class="fas fa-home" style="color: #667eea;"></i>
                Member's Own Family (<?php echo count($own_family); ?> members)
            </h3>
            
            <?php if (!empty($own_family)): ?>
                <?php foreach ($own_family as $family): ?>
                <div class="family-member">
                    <div class="relationship">
                        <i class="fas fa-user-tag"></i> <?php echo ucfirst($family['relationship']); ?>
                    </div>
                    <div class="name"><?php echo htmlspecialchars($family['full_name']); ?></div>
                    <div class="details">
                        <?php if ($family['age']): ?>
                        <span><i class="fas fa-birthday-cake"></i> Age: <?php echo $family['age']; ?></span>
                        <?php endif; ?>
                        <?php if ($family['occupation']): ?>
                        <span><i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($family['occupation']); ?></span>
                        <?php endif; ?>
                        <?php if ($family['phone']): ?>
                        <span><i class="fas fa-phone"></i> <?php echo htmlspecialchars($family['phone']); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if ($family['notes']): ?>
                    <div style="margin-top: 10px; padding: 8px; background: #f0f0f0; border-radius: 5px; font-size: 0.9em;">
                        <i class="fas fa-sticky-note"></i> <?php echo htmlspecialchars($family['notes']); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color: #999; text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i> No own family members registered
                </p>
            <?php endif; ?>
        </div>

        <!-- Wife's Family Section -->
        <div class="family-section">
            <h3>
                <i class="fas fa-heart" style="color: #e74c3c;"></i>
                Wife's Family (<?php echo count($wife_family); ?> members)
            </h3>
            
            <?php if (!empty($wife_family)): ?>
                <?php foreach ($wife_family as $family): ?>
                <div class="family-member">
                    <div class="relationship">
                        <i class="fas fa-user-tag"></i> <?php echo ucfirst($family['relationship']); ?>
                    </div>
                    <div class="name"><?php echo htmlspecialchars($family['full_name']); ?></div>
                    <div class="details">
                        <?php if ($family['age']): ?>
                        <span><i class="fas fa-birthday-cake"></i> Age: <?php echo $family['age']; ?></span>
                        <?php endif; ?>
                        <?php if ($family['occupation']): ?>
                        <span><i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($family['occupation']); ?></span>
                        <?php endif; ?>
                        <?php if ($family['phone']): ?>
                        <span><i class="fas fa-phone"></i> <?php echo htmlspecialchars($family['phone']); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if ($family['notes']): ?>
                    <div style="margin-top: 10px; padding: 8px; background: #f0f0f0; border-radius: 5px; font-size: 0.9em;">
                        <i class="fas fa-sticky-note"></i> <?php echo htmlspecialchars($family['notes']); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color: #999; text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i> No wife's family members registered
                </p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Family Statistics -->
    <div style="margin-top: 30px; padding-top: 20px; border-top: 2px solid #f0f0f0;">
        <h3 style="margin-bottom: 15px;"><i class="fas fa-chart-pie"></i> Family Statistics</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
            <?php
            $relationships = ['father', 'mother', 'brother', 'sister', 'son', 'daughter', 'other'];
            foreach ($relationships as $rel):
                $own_count = count(array_filter($own_family, function($fm) use ($rel) {
                    return $fm['relationship'] == $rel;
                }));
                $wife_count = count(array_filter($wife_family, function($fm) use ($rel) {
                    return $fm['relationship'] == $rel;
                }));
                $total = $own_count + $wife_count;
                
                if ($total > 0):
            ?>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 10px; text-align: center;">
                <div style="font-size: 1.5em; font-weight: 700; color: #667eea;"><?php echo $total; ?></div>
                <div style="font-size: 0.9em; color: #666;"><?php echo ucfirst($rel); ?>s</div>
                <div style="font-size: 0.8em; color: #999;">
                    Own: <?php echo $own_count; ?> | Wife: <?php echo $wife_count; ?>
                </div>
            </div>
            <?php 
                endif;
            endforeach; 
            ?>
        </div>
    </div>

    <!-- Add Family Member Button (for registration role) -->
    <?php if (hasRole('registration') || hasRole('admin')): ?>
    <div style="margin-top: 30px; text-align: center;">
        <button class="btn btn-primary" onclick="addFamilyMember(<?php echo $member_id; ?>)">
            <i class="fas fa-plus"></i> Add Family Member
        </button>
    </div>
    <?php endif; ?>
</div>

<script>
function addFamilyMember(memberId) {
    window.location.href = 'add_family_member.php?member_id=' + memberId;
}
</script>