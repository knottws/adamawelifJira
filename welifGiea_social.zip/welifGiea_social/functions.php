<?php
// functions.php - Add these admin-specific functions

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function requireAdmin() {
    if (!isLoggedIn() || !isAdmin()) {
        header('Location: login.php');
        exit();
    }
}

function getUserCount($pdo, $role = null) {
    if ($role) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = ?");
        $stmt->execute([$role]);
    } else {
        $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    }
    return $stmt->fetchColumn();
}

function getActiveSessions($pdo) {
    $timeout = defined('SESSION_TIMEOUT') ? SESSION_TIMEOUT : 1800;
    $cutoff = date('Y-m-d H:i:s', time() - $timeout);
    
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT user_id) 
        FROM user_sessions 
        WHERE last_activity > ?
    ");
    $stmt->execute([$cutoff]);
    return $stmt->fetchColumn();
}

function logActivity($pdo, $action, $category, $description, $userId = null) {
    if (!$userId) {
        $userId = $_SESSION['user_id'] ?? null;
    }
    
    try {
        // Check if activity_log table exists
        $tableCheck = $pdo->query("SHOW TABLES LIKE 'activity_log'");
        if ($tableCheck->rowCount() == 0) {
            // Create the table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT,
                    action VARCHAR(50) NOT NULL,
                    category VARCHAR(50) NOT NULL,
                    description TEXT,
                    ip_address VARCHAR(45),
                    user_agent TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_action (action),
                    INDEX idx_category (category),
                    INDEX idx_created_at (created_at)
                )
            ");
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO activity_log (user_id, action, category, description, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        return $stmt->execute([
            $userId,
            $action,
            $category,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (PDOException $e) {
        error_log("Failed to log activity: " . $e->getMessage());
        return false;
    }
}