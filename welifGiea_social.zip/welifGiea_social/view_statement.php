<?php
require_once 'config.php';
requireLogin();

$id = $_GET['id'] ?? 0;

// Get bank statement details
$stmt = $pdo->prepare("
    SELECT bs.*, 
           m.full_name as member_name, 
           m.member_number,
           u.username as uploaded_by_name,
           v.username as verified_by_name,
           fa.amount, fa.payment_date, fa.payment_method
    FROM bank_statements bs
    JOIN members m ON bs.member_id = m.id
    JOIN users u ON bs.uploaded_by = u.id
    LEFT JOIN users v ON bs.verified_by = v.id
    JOIN financial_activities fa ON bs.financial_activity_id = fa.id
    WHERE bs.id = ?
");
$stmt->execute([$id]);
$statement = $stmt->fetch();

if (!$statement) {
    header('Location: finances.php');
    exit();
}

// Check if user can verify
$canVerify = in_array($_SESSION['user_role'], ['admin', 'finance']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Statement Details - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .statement-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .statement-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .statement-badge {
            padding: 8px 16px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .badge-pending { background: #fff3e0; color: #f57c00; }
        .badge-matched { background: #e8f5e9; color: #4CAF50; }
        .badge-mismatch { background: #ffebee; color: #f44336; }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .info-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .info-value {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .document-preview {
            margin: 30px 0;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .preview-header {
            background: #f5f5f5;
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .preview-content {
            padding: 20px;
            min-height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fafafa;
        }
        
        .preview-content img {
            max-width: 100%;
            max-height: 500px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .preview-content iframe {
            width: 100%;
            height: 600px;
            border: none;
        }
        
        .verification-section {
            background: #f5f5f5;
            border-radius: 10px;
            padding: 20px;
            margin-top: 30px;
        }
        
        .match-indicator {
            display: inline-flex;
            align-items: center;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .match-high { background: #e8f5e9; color: #2E7D32; }
        .match-medium { background: #fff3e0; color: #F57C00; }
        .match-low { background: #ffebee; color: #C62828; }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Bank Statement Details</h1>
                <div class="action-buttons">
                    <a href="finances.php" class="btn btn-secondary">
                        <span class="material-icons">arrow_back</span> Back
                    </a>
                    <a href="<?php echo $statement['statement_file_path']; ?>" download class="btn btn-primary">
                        <span class="material-icons">download</span> Download
                    </a>
                </div>
            </header>
            
            <div class="statement-container">
                <div class="statement-header">
                    <div>
                        <h2>Statement #<?php echo $statement['statement_number'] ?? $statement['id']; ?></h2>
                        <p>Uploaded on <?php echo date('F j, Y \a\t g:i A', strtotime($statement['upload_date'])); ?></p>
                    </div>
                    <span class="statement-badge badge-<?php echo $statement['match_status']; ?>">
                        <?php echo ucfirst($statement['match_status']); ?>
                    </span>
                </div>
                
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Member</div>
                        <div class="info-value"><?php echo htmlspecialchars($statement['member_name']); ?></div>
                        <div style="font-size: 14px; color: #666;">#<?php echo $statement['member_number']; ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Transaction Amount</div>
                        <div class="info-value">ETB <?php echo number_format($statement['transaction_amount'], 2); ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Transaction Date</div>
                        <div class="info-value"><?php echo date('F j, Y', strtotime($statement['transaction_date'])); ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Bank Name</div>
                        <div class="info-value"><?php echo $statement['bank_name']; ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Account Number</div>
                        <div class="info-value"><?php echo $statement['account_number'] ?? 'N/A'; ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Reference</div>
                        <div class="info-value"><?php echo $statement['transaction_reference'] ?? 'N/A'; ?></div>
                    </div>
                </div>
                
                <!-- Document Preview -->
                <div class="document-preview">
                    <div class="preview-header">
                        <span>
                            <span class="material-icons" style="vertical-align: middle;">description</span>
                            <?php echo $statement['original_filename']; ?>
                        </span>
                        <span class="file-meta">
                            <?php echo round($statement['file_size'] / 1024, 2); ?> KB
                        </span>
                    </div>
                    <div class="preview-content">
                        <?php
                        $ext = pathinfo($statement['original_filename'], PATHINFO_EXTENSION);
                        if (in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif'])): ?>
                            <img src="<?php echo $statement['statement_file_path']; ?>" alt="Bank Statement">
                        <?php elseif (strtolower($ext) == 'pdf'): ?>
                            <iframe src="<?php echo $statement['statement_file_path']; ?>"></iframe>
                        <?php else: ?>
                            <div style="text-align: center;">
                                <span class="material-icons" style="font-size: 64px; color: #999;">insert_drive_file</span>
                                <p>Preview not available. Please download the file.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Matching Information -->
                <?php if ($statement['match_confidence']): ?>
                <div style="margin: 20px 0;">
                    <h3>Matching Analysis</h3>
                    <div style="display: flex; align-items: center; gap: 20px; margin-top: 15px;">
                        <span class="match-indicator match-<?php 
                            echo $statement['match_confidence'] > 80 ? 'high' : 
                                ($statement['match_confidence'] > 50 ? 'medium' : 'low'); 
                        ?>">
                            Confidence: <?php echo $statement['match_confidence']; ?>%
                        </span>
                        <div style="flex: 1;">
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: <?php echo $statement['match_confidence']; ?>%; 
                                    background: <?php echo $statement['match_confidence'] > 80 ? '#4CAF50' : 
                                        ($statement['match_confidence'] > 50 ? '#FF9800' : '#f44336'); ?>;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Verification Section -->
                <?php if ($canVerify && $statement['match_status'] == 'pending'): ?>
                <div class="verification-section">
                    <h3>Verify Bank Statement</h3>
                    <p>Please verify that this bank statement matches the payment record.</p>
                    
                    <form method="POST" action="verify_statement.php" style="margin-top: 20px;">
                        <input type="hidden" name="statement_id" value="<?php echo $statement['id']; ?>">
                        
                        <div class="form-group">
                            <label>Verification Status</label>
                            <select name="verification_status" required>
                                <option value="matched">✅ Matched - Statement confirms payment</option>
                                <option value="mismatch">❌ Mismatch - Statement does not match</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Verification Notes</label>
                            <textarea name="verification_notes" rows="3" placeholder="Add any notes about this verification..."></textarea>
                        </div>
                        
                        <button type="submit" name="verify" class="btn btn-primary">
                            <span class="material-icons">verified</span> Submit Verification
                        </button>
                    </form>
                </div>
                <?php endif; ?>
                
                <!-- Verification History -->
                <?php if ($statement['verified_by']): ?>
                <div style="margin-top: 20px; padding: 20px; background: #f5f5f5; border-radius: 10px;">
                    <h4>Verification Information</h4>
                    <p style="margin-top: 10px;">
                        <strong>Verified by:</strong> <?php echo $statement['verified_by_name']; ?><br>
                        <strong>Verified at:</strong> <?php echo date('F j, Y \a\t g:i A', strtotime($statement['verified_at'])); ?><br>
                        <?php if ($statement['verification_notes']): ?>
                            <strong>Notes:</strong> <?php echo nl2br(htmlspecialchars($statement['verification_notes'])); ?>
                        <?php endif; ?>
                    </p>
                </div>
                <?php endif; ?>
                
                <!-- Upload Information -->
                <div style="margin-top: 20px; font-size: 13px; color: #999; text-align: right;">
                    Uploaded by: <?php echo $statement['uploaded_by_name']; ?> |
                    File: <?php echo $statement['original_filename']; ?> |
                    Size: <?php echo round($statement['file_size'] / 1024, 2); ?> KB
                </div>
            </div>
        </main>
    </div>
</body>
</html>