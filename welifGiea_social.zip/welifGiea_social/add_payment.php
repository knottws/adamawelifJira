<?php
require_once 'config.php';
requireLogin(['finance', 'admin']);

$roleAccess = getRoleAccess($pdo);
$error = '';
$success = '';

// Get active members for dropdown
$members = $pdo->query("
    SELECT id, member_number, full_name, phone 
    FROM members 
    WHERE status = 'active' 
    ORDER BY full_name
")->fetchAll();

// Get bank accounts
$bankAccounts = $pdo->query("SELECT * FROM bank_accounts WHERE is_active = 1 ORDER BY bank_name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        // Handle file upload
        $bankStatementPath = null;
        $bankStatementFilename = null;
        $fileSize = null;
        $fileType = null;
        
        if (isset($_FILES['bank_statement']) && $_FILES['bank_statement']['error'] === UPLOAD_ERR_OK) {
            $uploadResult = handleBankStatementUpload($_FILES['bank_statement']);
            if ($uploadResult['success']) {
                $bankStatementPath = $uploadResult['path'];
                $bankStatementFilename = $uploadResult['filename'];
                $fileSize = $uploadResult['size'];
                $fileType = $uploadResult['type'];
            } else {
                throw new Exception($uploadResult['error']);
            }
        }
        
        // Insert financial activity
        $stmt = $pdo->prepare("
            INSERT INTO financial_activities (
                member_id, payment_date, amount, contribution_type, payment_method,
                transaction_reference, bank_name, account_number, account_holder,
                transaction_date, bank_statement_path, bank_statement_filename,
                bank_statement_size, bank_statement_type, cheque_number,
                cheque_date, payment_status, month_year, contribution_year,
                contribution_month, notes, recorded_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $_POST['member_id'],
            $_POST['payment_date'],
            $_POST['amount'],
            $_POST['contribution_type'],
            $_POST['payment_method'],
            $_POST['transaction_reference'] ?? null,
            $_POST['bank_name'] ?? null,
            $_POST['account_number'] ?? null,
            $_POST['account_holder'] ?? null,
            $_POST['transaction_date'] ?? null,
            $bankStatementPath,
            $bankStatementFilename,
            $fileSize,
            $fileType,
            $_POST['cheque_number'] ?? null,
            $_POST['cheque_date'] ?? null,
            $_POST['payment_status'],
            $_POST['month_year'],
            substr($_POST['month_year'], 0, 4),
            substr($_POST['month_year'], 5, 2),
            $_POST['notes'] ?? null,
            $_SESSION['user_id']
        ]);
        
        $financialId = $pdo->lastInsertId();
        
        // Insert into bank_statements table if statement uploaded
        if ($bankStatementPath) {
            $stmt = $pdo->prepare("
                INSERT INTO bank_statements (
                    financial_activity_id, member_id, bank_name, account_number,
                    transaction_date, transaction_amount, transaction_reference,
                    statement_file_path, original_filename, file_size, file_type,
                    uploaded_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $financialId,
                $_POST['member_id'],
                $_POST['bank_name'] ?? 'Unknown',
                $_POST['account_number'] ?? null,
                $_POST['transaction_date'] ?? $_POST['payment_date'],
                $_POST['amount'],
                $_POST['transaction_reference'] ?? null,
                $bankStatementPath,
                $bankStatementFilename,
                $fileSize,
                $fileType,
                $_SESSION['user_id']
            ]);
            
            // Log file upload
            logFileUpload($pdo, $_SESSION['user_id'], $bankStatementFilename, $bankStatementPath, $fileSize, $fileType, 'financial_activities', $financialId, 'bank_statement');
        }
        
        // Update contribution schedule
        $dueDate = date('Y-m-d', strtotime($_POST['month_year'] . '-10'));
        $graceEnd = date('Y-m-d', strtotime($dueDate . ' +7 days'));
        
        $stmt = $pdo->prepare("
            INSERT INTO contribution_schedule (
                member_id, year, month, expected_amount, due_date,
                grace_period_end, status, payment_id
            ) VALUES (?, ?, ?, 200.00, ?, ?, 'paid', ?)
            ON DUPLICATE KEY UPDATE
            status = 'paid', payment_id = ?
        ");
        
        $stmt->execute([
            $_POST['member_id'],
            substr($_POST['month_year'], 0, 4),
            substr($_POST['month_year'], 5, 2),
            $dueDate,
            $graceEnd,
            $financialId,
            $financialId
        ]);
        
        // Update member's total contributions
        $stmt = $pdo->prepare("
            UPDATE members SET 
            total_contributions = total_contributions + ?,
            last_payment_date = ?
            WHERE id = ?
        ");
        $stmt->execute([$_POST['amount'], $_POST['payment_date'], $_POST['member_id']]);
        
        $pdo->commit();
        $success = "Payment recorded successfully with bank statement!";
        logActivity($pdo, 'record_payment', 'finance', 'Recorded payment with bank statement for member ID: ' . $_POST['member_id']);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}

// Function to handle bank statement upload
function handleBankStatementUpload($file) {
    $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    // Check file type
    if (!in_array($file['type'], $allowedTypes)) {
        return ['success' => false, 'error' => 'Invalid file type. Allowed: PDF, JPEG, PNG, DOC, DOCX'];
    }
    
    // Check file size
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'error' => 'File too large. Maximum size: 5MB'];
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . date('Ymd_His') . '.' . $extension;
    $uploadPath = RECEIPT_PATH . 'bank_statements/' . $filename;
    
    // Create directory if it doesn't exist
    $uploadDir = RECEIPT_PATH . 'bank_statements/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return [
            'success' => true,
            'path' => 'uploads/receipts/bank_statements/' . $filename,
            'filename' => $file['name'],
            'size' => $file['size'],
            'type' => $file['type']
        ];
    } else {
        return ['success' => false, 'error' => 'Failed to upload file'];
    }
}

// Function to log file upload
function logFileUpload($pdo, $userId, $fileName, $filePath, $fileSize, $fileType, $relatedTable, $relatedId, $purpose) {
    $stmt = $pdo->prepare("
        INSERT INTO file_uploads (
            user_id, file_name, file_path, file_size, file_type,
            related_table, related_id, upload_purpose, ip_address
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $userId,
        $fileName,
        $filePath,
        $fileSize,
        $fileType,
        $relatedTable,
        $relatedId,
        $purpose,
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Payment with Bank Statement - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .upload-area {
            border: 2px dashed #ccc;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            background: #f9f9f9;
            cursor: pointer;
            transition: all 0.3s;
            margin: 20px 0;
        }
        
        .upload-area:hover {
            border-color: #667eea;
            background: #f0f4ff;
        }
        
        .upload-area.dragover {
            border-color: #4CAF50;
            background: #e8f5e9;
        }
        
        .upload-icon {
            font-size: 48px;
            color: #999;
            margin-bottom: 10px;
        }
        
        .file-info {
            background: #e3f2fd;
            border-radius: 8px;
            padding: 15px;
            margin: 10px 0;
            display: none;
        }
        
        .file-info.active {
            display: block;
        }
        
        .file-preview {
            max-width: 100%;
            max-height: 200px;
            margin: 10px 0;
            border-radius: 5px;
        }
        
        .bank-fields {
            background: #f5f5f5;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            display: none;
        }
        
        .bank-fields.active {
            display: block;
        }
        
        .progress-bar {
            height: 4px;
            background: #f0f0f0;
            border-radius: 2px;
            margin: 10px 0;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4CAF50, #8BC34A);
            width: 0%;
            transition: width 0.3s;
        }
        
        .statement-preview {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 8px;
            margin: 10px 0;
        }
        
        .statement-icon {
            font-size: 40px;
            color: #667eea;
        }
        
        .statement-details {
            flex: 1;
        }
        
        .statement-name {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .statement-meta {
            font-size: 12px;
            color: #666;
        }
        
        .remove-file {
            color: #f44336;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Record Payment with Bank Statement</h1>
                <a href="finances.php" class="btn btn-secondary">Back to Finances</a>
            </header>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="" enctype="multipart/form-data" id="paymentForm">
                <div class="form-section">
                    <h2>Member Information</h2>
                    
                    <div class="form-group">
                        <label for="member_id">Select Member *</label>
                        <select id="member_id" name="member_id" required onchange="loadMemberInfo(this)">
                            <option value="">Choose a member...</option>
                            <?php foreach ($members as $member): ?>
                            <option value="<?php echo $member['id']; ?>" 
                                    data-number="<?php echo $member['member_number']; ?>"
                                    data-phone="<?php echo $member['phone']; ?>">
                                <?php echo htmlspecialchars($member['full_name']); ?> (<?php echo $member['member_number']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div id="memberInfo" style="display: none; background: #f5f5f5; padding: 15px; border-radius: 8px; margin-top: 10px;">
                        <strong>Member Details:</strong>
                        <div id="memberNumber"></div>
                        <div id="memberPhone"></div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h2>Payment Details</h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="payment_date">Payment Date *</label>
                            <input type="date" id="payment_date" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="month_year">Contribution Month *</label>
                            <input type="month" id="month_year" name="month_year" value="<?php echo date('Y-m'); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="amount">Amount (ETB) *</label>
                            <input type="number" id="amount" name="amount" value="200.00" min="0" step="0.01" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="contribution_type">Contribution Type</label>
                            <select id="contribution_type" name="contribution_type">
                                <option value="monthly">Monthly (200 ETB)</option>
                                <option value="special">Special Contribution</option>
                                <option value="penalty">Penalty</option>
                                <option value="donation">Donation</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="payment_method">Payment Method *</label>
                            <select id="payment_method" name="payment_method" required onchange="togglePaymentMethod(this.value)">
                                <option value="">Select method...</option>
                                <option value="cash">Cash</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="mobile_money">Mobile Money</option>
                                <option value="cheque">Cheque</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="payment_status">Payment Status</label>
                            <select id="payment_status" name="payment_status">
                                <option value="completed">Completed</option>
                                <option value="pending">Pending</option>
                                <option value="partial">Partial</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Bank Transfer Fields -->
                <div id="bankTransferFields" class="bank-fields">
                    <h3>Bank Transfer Details</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="bank_name">Bank Name</label>
                            <select id="bank_name" name="bank_name" onchange="loadBankAccounts(this.value)">
                                <option value="">Select bank...</option>
                                <option value="CBE">Commercial Bank of Ethiopia (CBE)</option>
                                <option value="Dashen">Dashen Bank</option>
                                <option value="Awash">Awash Bank</option>
                                <option value="Abyssinia">Abyssinia Bank</option>
                                <option value="Wegagen">Wegagen Bank</option>
                                <option value="Oromia">Oromia Bank</option>
                                <option value="Coop">Cooperative Bank</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="account_number">Account Number</label>
                            <input type="text" id="account_number" name="account_number">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="account_holder">Account Holder Name</label>
                            <input type="text" id="account_holder" name="account_holder">
                        </div>
                        
                        <div class="form-group">
                            <label for="transaction_reference">Transaction Reference</label>
                            <input type="text" id="transaction_reference" name="transaction_reference">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="transaction_date">Transaction Date</label>
                            <input type="date" id="transaction_date" name="transaction_date">
                        </div>
                    </div>
                </div>
                
                <!-- Cheque Fields -->
                <div id="chequeFields" class="bank-fields">
                    <h3>Cheque Details</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="cheque_number">Cheque Number</label>
                            <input type="text" id="cheque_number" name="cheque_number">
                        </div>
                        
                        <div class="form-group">
                            <label for="cheque_date">Cheque Date</label>
                            <input type="date" id="cheque_date" name="cheque_date">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="bank_name_cheque">Bank Name</label>
                            <input type="text" id="bank_name_cheque" name="bank_name">
                        </div>
                        
                        <div class="form-group">
                            <label for="account_number_cheque">Account Number</label>
                            <input type="text" id="account_number_cheque" name="account_number">
                        </div>
                    </div>
                </div>
                
                <!-- Bank Statement Upload Section -->
                <div class="form-section">
                    <h2>Bank Statement Upload</h2>
                    <p>Upload the bank statement or transaction receipt as proof of payment</p>
                    
                    <div class="upload-area" id="uploadArea" onclick="document.getElementById('bank_statement').click()">
                        <span class="material-icons upload-icon">cloud_upload</span>
                        <h3>Click or drag to upload bank statement</h3>
                        <p>Supported formats: PDF, JPEG, PNG, DOC (Max 5MB)</p>
                        <input type="file" id="bank_statement" name="bank_statement" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" style="display: none;" onchange="handleFileSelect(this)">
                    </div>
                    
                    <div class="file-info" id="fileInfo">
                        <div class="statement-preview">
                            <span class="material-icons statement-icon">description</span>
                            <div class="statement-details">
                                <div class="statement-name" id="fileName"></div>
                                <div class="statement-meta" id="fileMeta"></div>
                            </div>
                            <span class="material-icons remove-file" onclick="removeFile()">close</span>
                        </div>
                        
                        <div class="progress-bar">
                            <div class="progress-fill" id="uploadProgress"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="bank_notes">Additional Notes about Bank Statement</label>
                        <textarea id="bank_notes" name="notes" rows="3" placeholder="Enter any additional information about the bank statement..."></textarea>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <span class="material-icons">save</span> Record Payment
                    </button>
                    <a href="finances.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </main>
    </div>
    
    <script>
        // Load member info
        function loadMemberInfo(select) {
            const option = select.options[select.selectedIndex];
            const memberInfo = document.getElementById('memberInfo');
            
            if (option.value) {
                document.getElementById('memberNumber').textContent = 'Member #: ' + option.dataset.number;
                document.getElementById('memberPhone').textContent = 'Phone: ' + (option.dataset.phone || 'Not provided');
                memberInfo.style.display = 'block';
            } else {
                memberInfo.style.display = 'none';
            }
        }
        
        // Toggle payment method fields
        function togglePaymentMethod(method) {
            const bankFields = document.getElementById('bankTransferFields');
            const chequeFields = document.getElementById('chequeFields');
            
            bankFields.classList.remove('active');
            chequeFields.classList.remove('active');
            
            if (method === 'bank_transfer') {
                bankFields.classList.add('active');
            } else if (method === 'cheque') {
                chequeFields.classList.add('active');
            }
        }
        
        // Handle file selection
        function handleFileSelect(input) {
            const file = input.files[0];
            if (file) {
                displayFileInfo(file);
                simulateUpload();
            }
        }
        
        // Display file information
        function displayFileInfo(file) {
            const fileInfo = document.getElementById('fileInfo');
            const fileName = document.getElementById('fileName');
            const fileMeta = document.getElementById('fileMeta');
            
            fileName.textContent = file.name;
            
            const fileSize = (file.size / 1024).toFixed(2);
            const fileType = file.type || 'Unknown type';
            const lastModified = new Date(file.lastModified).toLocaleDateString();
            
            fileMeta.textContent = `${fileSize} KB • ${fileType} • Modified: ${lastModified}`;
            
            fileInfo.classList.add('active');
        }
        
        // Simulate upload progress
        function simulateUpload() {
            const progressBar = document.getElementById('uploadProgress');
            let progress = 0;
            
            const interval = setInterval(() => {
                progress += 10;
                progressBar.style.width = progress + '%';
                
                if (progress >= 100) {
                    clearInterval(interval);
                }
            }, 200);
        }
        
        // Remove file
        function removeFile() {
            document.getElementById('bank_statement').value = '';
            document.getElementById('fileInfo').classList.remove('active');
            document.getElementById('uploadProgress').style.width = '0%';
        }
        
        // Drag and drop functionality
        const uploadArea = document.getElementById('uploadArea');
        
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            const file = e.dataTransfer.files[0];
            if (file) {
                document.getElementById('bank_statement').files = e.dataTransfer.files;
                displayFileInfo(file);
                simulateUpload();
            }
        });
        
        // Form validation
        document.getElementById('paymentForm').addEventListener('submit', function(e) {
            const paymentMethod = document.getElementById('payment_method').value;
            
            if (!paymentMethod) {
                e.preventDefault();
                alert('Please select a payment method');
                return;
            }
            
            if (paymentMethod === 'bank_transfer') {
                const bankName = document.getElementById('bank_name').value;
                if (!bankName) {
                    e.preventDefault();
                    alert('Please enter bank name for bank transfer');
                }
            }
            
            if (paymentMethod === 'cheque') {
                const chequeNumber = document.getElementById('cheque_number').value;
                if (!chequeNumber) {
                    e.preventDefault();
                    alert('Please enter cheque number');
                }
            }
        });
    </script>
</body>
</html>