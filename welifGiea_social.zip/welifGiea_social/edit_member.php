<?php
// edit_member.php - Complete Edit Member Page

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'welifGiea_social');

// Create connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: members.php");
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

// Initialize variables
$name = $email = $phone = $address = $role = $status = "";
$name_err = $email_err = $phone_err = $role_err = "";

// Fetch member data
$sql = "SELECT * FROM members WHERE id = ?";
if ($stmt = mysqli_prepare($conn, $sql)) {
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
        $address = $row['address'];
        $role = $row['role'];
        $status = $row['status'];
        $profile_image = $row['profile_image'];
    } else {
        header("location: members.php");
        exit;
    }
    mysqli_stmt_close($stmt);
}

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Validate name
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter a name.";
    } else {
        $name = trim($_POST["name"]);
    }
    
    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email.";
    } else {
        // Check if email exists for other members
        $email = trim($_POST["email"]);
        $sql = "SELECT id FROM members WHERE email = ? AND id != ?";
        
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "si", $email, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            
            if (mysqli_stmt_num_rows($stmt) > 0) {
                $email_err = "This email is already taken.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate phone
    if (empty(trim($_POST["phone"]))) {
        $phone_err = "Please enter a phone number.";
    } else {
        $phone = trim($_POST["phone"]);
    }
    
    // Validate role
    if (empty(trim($_POST["role"]))) {
        $role_err = "Please select a role.";
    } else {
        $role = trim($_POST["role"]);
    }
    
    $address = trim($_POST["address"]);
    $status = isset($_POST["status"]) ? trim($_POST["status"]) : 'active';
    
    // Handle file upload
    $profile_image = $_POST['current_image'] ?? '';
    
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($_FILES['profile_image']['type'], $allowed_types)) {
            $upload_err = "Only JPG, PNG, and GIF files are allowed.";
        } elseif ($_FILES['profile_image']['size'] > $max_size) {
            $upload_err = "File size must be less than 5MB.";
        } else {
            $upload_dir = "uploads/members/";
            
            // Create directory if it doesn't exist
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                // Delete old image if exists
                if (!empty($profile_image) && file_exists($profile_image)) {
                    unlink($profile_image);
                }
                $profile_image = $upload_path;
            } else {
                $upload_err = "Failed to upload file.";
            }
        }
    }
    
    // Check input errors before updating in database
    if (empty($name_err) && empty($email_err) && empty($phone_err) && empty($role_err) && empty($upload_err)) {
        
        // Prepare an update statement
        $sql = "UPDATE members SET name = ?, email = ?, phone = ?, address = ?, role = ?, status = ?, profile_image = ?, updated_at = NOW() WHERE id = ?";
        
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "sssssssi", $name, $email, $phone, $address, $role, $status, $profile_image, $id);
            
            if (mysqli_stmt_execute($stmt)) {
                // Redirect to members page with success message
                $_SESSION['success_message'] = "Member updated successfully.";
                header("location: members.php");
                exit();
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
}

// Close connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Member - welifGiea Social</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 20px 30px;
            border-radius: 10px 10px 0 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: #333;
            font-size: 24px;
        }

        .back-btn {
            background: #6c757d;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }

        .back-btn:hover {
            background: #5a6268;
        }

        .form-container {
            background: white;
            padding: 30px;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group input.error,
        .form-group select.error {
            border-color: #dc3545;
        }

        .error-message {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
            display: block;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-error {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        .form-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.3s;
            margin-right: 10px;
        }

        .btn-submit:hover {
            opacity: 0.9;
        }

        .btn-cancel {
            background: #6c757d;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }

        .btn-cancel:hover {
            background: #5a6268;
        }

        .current-image {
            margin: 10px 0;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .current-image img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .status-toggle {
            display: flex;
            align-items: center;
            gap: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
        }

        .status-toggle label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .status-toggle input[type="radio"] {
            width: auto;
            cursor: pointer;
        }

        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
                gap: 20px;
            }
            
            .header {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }

        /* Loading overlay */
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Image preview */
        .image-preview {
            display: none;
            margin-top: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 6px;
        }

        .image-preview img {
            max-width: 200px;
            max-height: 200px;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Edit Member</h1>
            <a href="members.php" class="back-btn">← Back to Members</a>
        </div>

        <div class="form-container">
            <?php if (!empty($upload_err)): ?>
                <div class="alert alert-error"><?php echo $upload_err; ?></div>
            <?php endif; ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" 
                  method="post" 
                  enctype="multipart/form-data"
                  id="editForm">
                
                <input type="hidden" name="current_image" value="<?php echo $profile_image; ?>">

                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Full Name *</label>
                        <input type="text" 
                               name="name" 
                               id="name" 
                               value="<?php echo htmlspecialchars($name); ?>" 
                               class="<?php echo (!empty($name_err)) ? 'error' : ''; ?>"
                               placeholder="Enter full name"
                               required>
                        <span class="error-message"><?php echo $name_err; ?></span>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" 
                               name="email" 
                               id="email" 
                               value="<?php echo htmlspecialchars($email); ?>" 
                               class="<?php echo (!empty($email_err)) ? 'error' : ''; ?>"
                               placeholder="Enter email address"
                               required>
                        <span class="error-message"><?php echo $email_err; ?></span>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <input type="tel" 
                               name="phone" 
                               id="phone" 
                               value="<?php echo htmlspecialchars($phone); ?>" 
                               class="<?php echo (!empty($phone_err)) ? 'error' : ''; ?>"
                               placeholder="Enter phone number"
                               required>
                        <span class="error-message"><?php echo $phone_err; ?></span>
                    </div>

                    <div class="form-group">
                        <label for="role">Role *</label>
                        <select name="role" 
                                id="role" 
                                class="<?php echo (!empty($role_err)) ? 'error' : ''; ?>"
                                required>
                            <option value="">Select Role</option>
                            <option value="admin" <?php echo ($role == 'admin') ? 'selected' : ''; ?>>Admin</option>
                            <option value="member" <?php echo ($role == 'member') ? 'selected' : ''; ?>>Member</option>
                            <option value="moderator" <?php echo ($role == 'moderator') ? 'selected' : ''; ?>>Moderator</option>
                            <option value="editor" <?php echo ($role == 'editor') ? 'selected' : ''; ?>>Editor</option>
                        </select>
                        <span class="error-message"><?php echo $role_err; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea name="address" 
                              id="address" 
                              rows="3" 
                              placeholder="Enter address"><?php echo htmlspecialchars($address); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="profile_image">Profile Image</label>
                    <?php if (!empty($profile_image) && file_exists($profile_image)): ?>
                        <div class="current-image">
                            <img src="<?php echo $profile_image; ?>" alt="Current Profile">
                            <span>Current Image</span>
                        </div>
                    <?php endif; ?>
                    <input type="file" 
                           name="profile_image" 
                           id="profile_image" 
                           accept="image/jpeg,image/png,image/gif">
                    <div class="image-preview" id="imagePreview">
                        <img src="" alt="Preview">
                    </div>
                    <small style="color: #666;">Allowed: JPG, PNG, GIF (Max: 5MB)</small>
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <div class="status-toggle">
                        <label>
                            <input type="radio" 
                                   name="status" 
                                   value="active" 
                                   <?php echo ($status == 'active') ? 'checked' : ''; ?>>
                            Active
                        </label>
                        <label>
                            <input type="radio" 
                                   name="status" 
                                   value="inactive" 
                                   <?php echo ($status == 'inactive') ? 'checked' : ''; ?>>
                            Inactive
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn-submit" id="submitBtn">
                        Update Member
                    </button>
                    <a href="members.php" class="btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner"></div>
    </div>

    <script>
        // Image preview
        document.getElementById('profile_image').addEventListener('change', function(e) {
            const preview = document.getElementById('imagePreview');
            const previewImg = preview.querySelector('img');
            
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    preview.style.display = 'block';
                }
                
                reader.readAsDataURL(this.files[0]);
            } else {
                preview.style.display = 'none';
            }
        });

        // Form validation
        document.getElementById('editForm').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const role = document.getElementById('role').value;
            
            let isValid = true;
            
            // Validate name
            if (!name) {
                showError('name', 'Name is required');
                isValid = false;
            } else if (name.length < 2) {
                showError('name', 'Name must be at least 2 characters');
                isValid = false;
            } else {
                clearError('name');
            }
            
            // Validate email
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email) {
                showError('email', 'Email is required');
                isValid = false;
            } else if (!emailPattern.test(email)) {
                showError('email', 'Please enter a valid email');
                isValid = false;
            } else {
                clearError('email');
            }
            
            // Validate phone
            const phonePattern = /^[\d\s\+\-\(\)]{10,}$/;
            if (!phone) {
                showError('phone', 'Phone is required');
                isValid = false;
            } else if (!phonePattern.test(phone)) {
                showError('phone', 'Please enter a valid phone number');
                isValid = false;
            } else {
                clearError('phone');
            }
            
            // Validate role
            if (!role) {
                showError('role', 'Please select a role');
                isValid = false;
            } else {
                clearError('role');
            }
            
            if (!isValid) {
                e.preventDefault();
                return false;
            }
            
            // Show loading overlay
            document.getElementById('loadingOverlay').style.display = 'flex';
            document.getElementById('submitBtn').disabled = true;
        });

        function showError(fieldId, message) {
            const field = document.getElementById(fieldId);
            field.classList.add('error');
            
            let errorSpan = field.nextElementSibling;
            if (errorSpan && errorSpan.classList.contains('error-message')) {
                errorSpan.textContent = message;
            } else {
                // Create error span if it doesn't exist
                errorSpan = document.createElement('span');
                errorSpan.className = 'error-message';
                errorSpan.textContent = message;
                field.parentNode.appendChild(errorSpan);
            }
        }

        function clearError(fieldId) {
            const field = document.getElementById(fieldId);
            field.classList.remove('error');
            
            const errorSpan = field.nextElementSibling;
            if (errorSpan && errorSpan.classList.contains('error-message')) {
                errorSpan.textContent = '';
            }
        }

        // Real-time validation
        document.getElementById('name').addEventListener('input', function() {
            if (this.value.length >= 2) {
                clearError('name');
            }
        });

        document.getElementById('email').addEventListener('input', function() {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (emailPattern.test(this.value)) {
                clearError('email');
            }
        });

        document.getElementById('phone').addEventListener('input', function() {
            const phonePattern = /^[\d\s\+\-\(\)]{10,}$/;
            if (phonePattern.test(this.value)) {
                clearError('phone');
            }
        });

        document.getElementById('role').addEventListener('change', function() {
            if (this.value) {
                clearError('role');
            }
        });

        // Warn before leaving if form is dirty
        let formChanged = false;
        
        document.getElementById('editForm').addEventListener('input', function() {
            formChanged = true;
        });

        window.addEventListener('beforeunload', function(e) {
            if (formChanged) {
                e.preventDefault();
                e.returnValue = '';
            }
        });

        // Preview image before upload
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const preview = document.getElementById('imagePreview');
                    const previewImg = preview.querySelector('img');
                    previewImg.src = e.target.result;
                    preview.style.display = 'block';
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html>