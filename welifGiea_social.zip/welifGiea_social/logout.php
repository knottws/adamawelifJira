<?php
require_once 'config.php';

// Log activity
if (isset($_SESSION['user_id'])) {
    logActivity($pdo, 'logout', 'auth', 'User logged out', $_SESSION['user_id']);
}

// Clear remember me cookie
if (isset($_COOKIE['remember_me'])) {
    setcookie('remember_me', '', time() - 3600, '/', '', true, true);
    
    // Clear token from database
    if (isset($_SESSION['user_id'])) {
        $pdo->prepare("UPDATE users SET remember_token = NULL, remember_token_expires = NULL WHERE id = ?")
            ->execute([$_SESSION['user_id']]);
    }
}

// Destroy session
$_SESSION = array();
session_destroy();

// Redirect to login
header("Location: login.php?loggedout=1");
exit();
?>