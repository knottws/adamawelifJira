<?php
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'dashboard.php';
    header('Location: login.php');
    exit();
}

// Get user role from session
$user_role = $_SESSION['user_role'] ?? 'member';
$user_id = $_SESSION['user_id'] ?? 0;
$username = $_SESSION['username'] ?? '';
$user_name = $_SESSION['user_name'] ?? $username;

// Get user details from database
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        // User not found in database, but session exists - logout
        session_destroy();
        header('Location: login.php?error=session_expired');
        exit();
    }
} catch (PDOException $e) {
    error_log("Dashboard user fetch error: " . $e->getMessage());
    $user = [];
}

// Redirect based on role if this is a role-specific dashboard
if (isset($_GET['section'])) {
    $section = $_GET['section'];
    // Handle different sections
} else {
    // If this is the main dashboard and user has specific role dashboard, redirect
    $role_dashboards = [
        'admin' => 'admin_dashboard.php',
        'finance' => 'finance_dashboard.php',
        'registration' => 'registration_dashboard.php',
        'member' => 'member_dashboard.php'
    ];
    
    if (isset($role_dashboards[$user_role]) && file_exists($role_dashboards[$user_role])) {
        // Only redirect if not already on that page
        $current_page = basename($_SERVER['PHP_SELF']);
        if ($current_page != $role_dashboards[$user_role]) {
            header('Location: ' . $role_dashboards[$user_role]);
            exit();
        }
    }
}

// Get dashboard data based on role
$recent_activities = [];
$notifications = [];
$stats = [];

try {
    // Get recent activities
    $activity_query = "SELECT * FROM activity_log WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
    $stmt = $pdo->prepare($activity_query);
    $stmt->execute([$user_id]);
    $recent_activities = $stmt->fetchAll();
    
    // Get notifications (you might have a notifications table)
    // This is just a placeholder
    $notifications = [];
    
    // Get role-specific stats
    switch ($user_role) {
        case 'admin':
            // Admin stats - total users, active sessions, etc.
            $stats['total_users'] = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
            $stats['active_today'] = $pdo->query("
                SELECT COUNT(DISTINCT user_id) FROM user_sessions 
                WHERE DATE(last_activity) = CURDATE()
            ")->fetchColumn() ?: 0;
            $stats['new_this_month'] = $pdo->query("
                SELECT COUNT(*) FROM users 
                WHERE MONTH(created_at) = MONTH(CURDATE()) 
                AND YEAR(created_at) = YEAR(CURDATE())
            ")->fetchColumn();
            break;
            
        case 'finance':
            // Finance stats - payments, contributions, etc.
            $stats['total_contributions'] = 0; // Calculate from your finance tables
            $stats['pending_payments'] = 0;
            break;
            
        case 'registration':
            // Registration stats - pending registrations, etc.
            $stats['pending_approvals'] = 0;
            $stats['total_members'] = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'member'")->fetchColumn();
            break;
            
        default:
            // Member stats - personal contributions, etc.
            $stats['member_since'] = $user['created_at'] ?? 'N/A';
            $stats['last_login'] = $user['last_login'] ?? 'Never';
    }
} catch (PDOException $e) {
    error_log("Dashboard data fetch error: " . $e->getMessage());
}

// Handle any POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        // Handle profile update
        // This would be implemented based on your needs
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare System'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #2c3e50 0%, #1e2b38 100%);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s;
        }
        
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        
        .sidebar-header h2 {
            font-size: 20px;
            margin-bottom: 5px;
        }
        
        .sidebar-header p {
            font-size: 13px;
            opacity: 0.7;
        }
        
        .user-info-sidebar {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3498db, #2ecc71);
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 600;
            color: white;
            border: 3px solid rgba(255,255,255,0.2);
        }
        
        .user-name-sidebar {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .user-role-sidebar {
            display: inline-block;
            padding: 4px 12px;
            background: rgba(255,255,255,0.15);
            border-radius: 20px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            padding: 12px 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.8);
            cursor: pointer;
            transition: all 0.3s;
            border-left: 4px solid transparent;
        }
        
        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: white;
            border-left-color: #3498db;
        }
        
        .menu-item .material-icons {
            font-size: 20px;
        }
        
        .menu-divider {
            height: 1px;
            background: rgba(255,255,255,0.1);
            margin: 15px 20px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 15px 25px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .page-title h1 {
            font-size: 24px;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .page-title p {
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .top-bar-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .notification-icon {
            position: relative;
            cursor: pointer;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 10px;
            min-width: 18px;
            text-align: center;
        }
        
        .profile-dropdown {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 5px 10px;
            border-radius: 8px;
            transition: background 0.3s;
        }
        
        .profile-dropdown:hover {
            background: #f8f9fa;
        }
        
        .profile-dropdown .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3498db, #2c3e50);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .profile-info {
            line-height: 1.4;
        }
        
        .profile-name {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .profile-role {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: capitalize;
        }
        
        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            padding: 30px;
            color: white;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .welcome-text h2 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .welcome-text p {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .welcome-stats {
            display: flex;
            gap: 30px;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .stat-info h3 {
            font-size: 14px;
            color: #7f8c8d;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .stat-number {
            font-size: 28px;
            font-weight: 700;
            color: #2c3e50;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        
        .stat-icon.blue { background: #e3f2fd; color: #1976d2; }
        .stat-icon.green { background: #e8f5e9; color: #388e3c; }
        .stat-icon.orange { background: #fff3e0; color: #f57c00; }
        .stat-icon.purple { background: #f3e5f5; color: #7b1fa2; }
        
        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .quick-action {
            background: white;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid transparent;
        }
        
        .quick-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-color: #3498db;
        }
        
        .quick-action .material-icons {
            font-size: 32px;
            color: #3498db;
            margin-bottom: 10px;
        }
        
        .quick-action span:last-child {
            display: block;
            font-weight: 500;
            color: #2c3e50;
        }
        
        /* Content Grid */
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .card-header h3 {
            color: #2c3e50;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .card-header h3 .material-icons {
            color: #3498db;
        }
        
        .view-all {
            color: #3498db;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .view-all:hover {
            text-decoration: underline;
        }
        
        /* Activity List */
        .activity-list {
            list-style: none;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #3498db;
        }
        
        .activity-details {
            flex: 1;
        }
        
        .activity-text {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 3px;
        }
        
        .activity-time {
            font-size: 12px;
            color: #95a5a6;
        }
        
        /* Notifications */
        .notification-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .notification-item:last-child {
            border-bottom: none;
        }
        
        .notification-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #3498db;
        }
        
        .notification-dot.unread {
            background: #e74c3c;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-title {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 3px;
        }
        
        .notification-time {
            font-size: 12px;
            color: #95a5a6;
        }
        
        /* Role-specific content */
        .role-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .role-badge.admin { background: #f44336; color: white; }
        .role-badge.finance { background: #4CAF50; color: white; }
        .role-badge.registration { background: #FF9800; color: white; }
        .role-badge.member { background: #2196F3; color: white; }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header h2,
            .sidebar-header p,
            .user-info-sidebar .user-name-sidebar,
            .user-info-sidebar .user-role-sidebar,
            .menu-item span:not(.material-icons) {
                display: none;
            }
            
            .user-avatar {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }
            
            .menu-item {
                justify-content: center;
                padding: 15px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .content-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .top-bar {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .welcome-banner {
                flex-direction: column;
                text-align: center;
                gap: 20px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        /* Loading states */
        .loading {
            opacity: 0.6;
            pointer-events: none;
            position: relative;
        }
        
        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 30px;
            height: 30px;
            border: 3px solid #f0f0f0;
            border-top-color: #3498db;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Empty states */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #95a5a6;
        }
        
        .empty-state .material-icons {
            font-size: 48px;
            margin-bottom: 10px;
            color: #e0e0e0;
        }
        
        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Dropdown menu */
        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            min-width: 200px;
            display: none;
            z-index: 1000;
        }
        
        .dropdown-menu.show {
            display: block;
        }
        
        .dropdown-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #2c3e50;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .dropdown-item:hover {
            background: #f8f9fa;
        }
        
        .dropdown-item .material-icons {
            font-size: 18px;
            color: #7f8c8d;
        }
        
        .dropdown-divider {
            height: 1px;
            background: #e0e0e0;
            margin: 5px 0;
        }
        
        /* Progress bars */
        .progress {
            height: 8px;
            background: #f0f0f0;
            border-radius: 4px;
            overflow: hidden;
            margin: 10px 0;
        }
        
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #3498db, #2ecc71);
            transition: width 0.3s ease;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare System'; ?></h2>
                <p>Dashboard</p>
            </div>
            
            <div class="user-info-sidebar">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user_name, 0, 1)); ?>
                </div>
                <div class="user-name-sidebar"><?php echo htmlspecialchars($user_name); ?></div>
                <span class="user-role-sidebar role-badge <?php echo $user_role; ?>">
                    <?php echo ucfirst($user_role); ?>
                </span>
            </div>
            
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item active">
                    <span class="material-icons">dashboard</span>
                    <span>Dashboard</span>
                </a>
                
                <?php if ($user_role == 'admin'): ?>
                <a href="admin_dashboard.php" class="menu-item">
                    <span class="material-icons">admin_panel_settings</span>
                    <span>Admin Panel</span>
                </a>
                <?php endif; ?>
                
                <?php if ($user_role == 'finance' || $user_role == 'admin'): ?>
                <a href="finance_dashboard.php" class="menu-item">
                    <span class="material-icons">account_balance</span>
                    <span>Finance</span>
                </a>
                <?php endif; ?>
                
                <?php if ($user_role == 'registration' || $user_role == 'admin'): ?>
                <a href="registration_dashboard.php" class="menu-item">
                    <span class="material-icons">how_to_reg</span>
                    <span>Registration</span>
                </a>
                <?php endif; ?>
                
                <?php if ($user_role == 'member'): ?>
                <a href="member_dashboard.php" class="menu-item">
                    <span class="material-icons">person</span>
                    <span>My Dashboard</span>
                </a>
                <?php endif; ?>
                
                <div class="menu-divider"></div>
                
                <a href="profile.php" class="menu-item">
                    <span class="material-icons">person</span>
                    <span>My Profile</span>
                </a>
                
                <a href="settings.php" class="menu-item">
                    <span class="material-icons">settings</span>
                    <span>Settings</span>
                </a>
                
                <a href="help.php" class="menu-item">
                    <span class="material-icons">help</span>
                    <span>Help</span>
                </a>
                
                <div class="menu-divider"></div>
                
                <a href="logout.php" class="menu-item">
                    <span class="material-icons">logout</span>
                    <span>Logout</span>
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="page-title">
                    <h1>Dashboard</h1>
                    <p>Welcome back, <?php echo htmlspecialchars($user_name); ?>!</p>
                </div>
                
                <div class="top-bar-actions">
                    <div class="notification-icon" onclick="toggleNotifications()">
                        <span class="material-icons">notifications</span>
                        <span class="notification-badge">3</span>
                        
                        <!-- Notifications dropdown -->
                        <div class="dropdown-menu" id="notificationsDropdown">
                            <div class="dropdown-item">
                                <span class="material-icons">info</span>
                                New update available
                            </div>
                            <div class="dropdown-item">
                                <span class="material-icons">message</span>
                                You have 2 new messages
                            </div>
                            <div class="dropdown-divider"></div>
                            <div class="dropdown-item">
                                <span class="material-icons">settings</span>
                                View all notifications
                            </div>
                        </div>
                    </div>
                    
                    <div class="profile-dropdown" onclick="toggleProfileMenu()">
                        <div class="avatar">
                            <?php echo strtoupper(substr($user_name, 0, 1)); ?>
                        </div>
                        <div class="profile-info">
                            <div class="profile-name"><?php echo htmlspecialchars($user_name); ?></div>
                            <div class="profile-role"><?php echo ucfirst($user_role); ?></div>
                        </div>
                        <span class="material-icons">arrow_drop_down</span>
                        
                        <!-- Profile dropdown -->
                        <div class="dropdown-menu" id="profileDropdown">
                            <a href="profile.php" class="dropdown-item">
                                <span class="material-icons">person</span>
                                My Profile
                            </a>
                            <a href="settings.php" class="dropdown-item">
                                <span class="material-icons">settings</span>
                                Settings
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item">
                                <span class="material-icons">logout</span>
                                Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Welcome Banner -->
            <div class="welcome-banner">
                <div class="welcome-text">
                    <h2>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h2>
                    <p><?php echo date('l, F j, Y'); ?></p>
                </div>
                <div class="welcome-stats">
                    <?php if ($user_role == 'admin'): ?>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $stats['total_users'] ?? 0; ?></div>
                        <div class="stat-label">Total Users</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $stats['active_today'] ?? 0; ?></div>
                        <div class="stat-label">Active Today</div>
                    </div>
                    <?php elseif ($user_role == 'member'): ?>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo date('M Y', strtotime($stats['member_since'])); ?></div>
                        <div class="stat-label">Member Since</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo date('M d', strtotime($stats['last_login'])); ?></div>
                        <div class="stat-label">Last Login</div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Stats Grid -->
            <div class="stats-grid">
                <?php if ($user_role == 'admin'): ?>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Total Users</h3>
                        <div class="stat-number"><?php echo $stats['total_users'] ?? 0; ?></div>
                    </div>
                    <div class="stat-icon blue">
                        <span class="material-icons">people</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Active Today</h3>
                        <div class="stat-number"><?php echo $stats['active_today'] ?? 0; ?></div>
                    </div>
                    <div class="stat-icon green">
                        <span class="material-icons">online_prediction</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>New This Month</h3>
                        <div class="stat-number"><?php echo $stats['new_this_month'] ?? 0; ?></div>
                    </div>
                    <div class="stat-icon orange">
                        <span class="material-icons">person_add</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Total Sessions</h3>
                        <div class="stat-number">-</div>
                    </div>
                    <div class="stat-icon purple">
                        <span class="material-icons">timeline</span>
                    </div>
                </div>
                
                <?php elseif ($user_role == 'member'): ?>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Member Since</h3>
                        <div class="stat-number"><?php echo date('M Y', strtotime($stats['member_since'])); ?></div>
                    </div>
                    <div class="stat-icon blue">
                        <span class="material-icons">calendar_today</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Last Login</h3>
                        <div class="stat-number"><?php echo date('M d', strtotime($stats['last_login'])); ?></div>
                    </div>
                    <div class="stat-icon green">
                        <span class="material-icons">login</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Profile Status</h3>
                        <div class="stat-number">Active</div>
                    </div>
                    <div class="stat-icon orange">
                        <span class="material-icons">check_circle</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Notifications</h3>
                        <div class="stat-number">3</div>
                    </div>
                    <div class="stat-icon purple">
                        <span class="material-icons">notifications</span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Quick Actions -->
            <div class="quick-actions">
                <?php if ($user_role == 'admin'): ?>
                <div class="quick-action" onclick="window.location.href='admin_dashboard.php?action=add_user'">
                    <span class="material-icons">person_add</span>
                    <span>Add User</span>
                </div>
                
                <div class="quick-action" onclick="window.location.href='reports.php'">
                    <span class="material-icons">assessment</span>
                    <span>Reports</span>
                </div>
                <?php endif; ?>
                
                <?php if ($user_role == 'finance'): ?>
                <div class="quick-action" onclick="window.location.href='finance_dashboard.php?action=add_payment'">
                    <span class="material-icons">payment</span>
                    <span>Add Payment</span>
                </div>
                
                <div class="quick-action" onclick="window.location.href='reports.php?type=finance'">
                    <span class="material-icons">receipt</span>
                    <span>Financial Report</span>
                </div>
                <?php endif; ?>
                
                <?php if ($user_role == 'registration'): ?>
                <div class="quick-action" onclick="window.location.href='registration_dashboard.php?action=pending'">
                    <span class="material-icons">pending_actions</span>
                    <span>Pending Approvals</span>
                </div>
                
                <div class="quick-action" onclick="window.location.href='registration_dashboard.php?action=new'">
                    <span class="material-icons">app_registration</span>
                    <span>New Registration</span>
                </div>
                <?php endif; ?>
                
                <div class="quick-action" onclick="window.location.href='profile.php'">
                    <span class="material-icons">edit</span>
                    <span>Edit Profile</span>
                </div>
                
                <div class="quick-action" onclick="window.location.href='messages.php'">
                    <span class="material-icons">message</span>
                    <span>Messages</span>
                </div>
                
                <div class="quick-action" onclick="window.location.href='help.php'">
                    <span class="material-icons">help</span>
                    <span>Help Center</span>
                </div>
            </div>
            
            <!-- Content Grid -->
            <div class="content-grid">
                <!-- Left Column -->
                <div>
                    <!-- Recent Activity Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3>
                                <span class="material-icons">history</span>
                                Recent Activity
                            </h3>
                            <a href="activities.php" class="view-all">
                                View All
                                <span class="material-icons">arrow_forward</span>
                            </a>
                        </div>
                        
                        <?php if (!empty($recent_activities)): ?>
                        <ul class="activity-list">
                            <?php foreach ($recent_activities as $activity): ?>
                            <li class="activity-item">
                                <div class="activity-icon">
                                    <span class="material-icons">
                                        <?php
                                        switch($activity['category'] ?? 'general') {
                                            case 'auth': echo 'lock'; break;
                                            case 'profile': echo 'person'; break;
                                            case 'finance': echo 'payments'; break;
                                            default: echo 'info';
                                        }
                                        ?>
                                    </span>
                                </div>
                                <div class="activity-details">
                                    <div class="activity-text">
                                        <?php echo htmlspecialchars($activity['description'] ?? 'Activity recorded'); ?>
                                    </div>
                                    <div class="activity-time">
                                        <?php echo date('M j, Y g:i A', strtotime($activity['created_at'])); ?>
                                    </div>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                        <div class="empty-state">
                            <span class="material-icons">history_toggle_off</span>
                            <p>No recent activity found</p>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Additional content based on role -->
                    <?php if ($user_role == 'admin'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3>
                                <span class="material-icons">security</span>
                                System Health
                            </h3>
                        </div>
                        
                        <div style="padding: 10px 0;">
                            <div style="margin-bottom: 15px;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                    <span>Database</span>
                                    <span style="color: #27ae60;">Operational</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" style="width: 100%;"></div>
                                </div>
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                    <span>Storage</span>
                                    <span>45% Used</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" style="width: 45%;"></div>
                                </div>
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                    <span>Memory Usage</span>
                                    <span>32%</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" style="width: 32%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Right Column -->
                <div>
                    <!-- Notifications Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3>
                                <span class="material-icons">notifications</span>
                                Notifications
                            </h3>
                            <a href="notifications.php" class="view-all">
                                View All
                            </a>
                        </div>
                        
                        <?php if (!empty($notifications)): ?>
                        <!-- List notifications here -->
                        <?php else: ?>
                        <div class="empty-state">
                            <span class="material-icons">notifications_none</span>
                            <p>No new notifications</p>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Sample notification -->
                        <div class="notification-item">
                            <div class="notification-dot unread"></div>
                            <div class="notification-content">
                                <div class="notification-title">System Update</div>
                                <div class="notification-time">5 minutes ago</div>
                            </div>
                        </div>
                        
                        <div class="notification-item">
                            <div class="notification-dot"></div>
                            <div class="notification-content">
                                <div class="notification-title">New user registered</div>
                                <div class="notification-time">1 hour ago</div>
                            </div>
                        </div>
                        
                        <div class="notification-item">
                            <div class="notification-dot"></div>
                            <div class="notification-content">
                                <div class="notification-title">Payment received</div>
                                <div class="notification-time">3 hours ago</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Links Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3>
                                <span class="material-icons">link</span>
                                Quick Links
                            </h3>
                        </div>
                        
                        <div style="display: flex; flex-direction: column; gap: 10px;">
                            <a href="profile.php" style="text-decoration: none; color: #2c3e50; padding: 8px; display: flex; align-items: center; gap: 10px;">
                                <span class="material-icons" style="color: #3498db;">person</span>
                                My Profile
                            </a>
                            
                            <a href="settings.php" style="text-decoration: none; color: #2c3e50; padding: 8px; display: flex; align-items: center; gap: 10px;">
                                <span class="material-icons" style="color: #3498db;">settings</span>
                                Account Settings
                            </a>
                            
                            <a href="help.php" style="text-decoration: none; color: #2c3e50; padding: 8px; display: flex; align-items: center; gap: 10px;">
                                <span class="material-icons" style="color: #3498db;">help</span>
                                Help & Support
                            </a>
                            
                            <?php if ($user_role == 'admin'): ?>
                            <a href="admin_dashboard.php" style="text-decoration: none; color: #2c3e50; padding: 8px; display: flex; align-items: center; gap: 10px;">
                                <span class="material-icons" style="color: #3498db;">admin_panel_settings</span>
                                Admin Panel
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- System Status Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3>
                                <span class="material-icons">info</span>
                                System Status
                            </h3>
                        </div>
                        
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <div style="display: flex; justify-content: space-between;">
                                <span>PHP Version</span>
                                <span style="color: #27ae60;"><?php echo phpversion(); ?></span>
                            </div>
                            
                            <div style="display: flex; justify-content: space-between;">
                                <span>Database</span>
                                <span style="color: #27ae60;">Connected</span>
                            </div>
                            
                            <div style="display: flex; justify-content: space-between;">
                                <span>Server Time</span>
                                <span><?php echo date('H:i:s'); ?></span>
                            </div>
                            
                            <div style="display: flex; justify-content: space-between;">
                                <span>Your IP</span>
                                <span><?php echo $_SERVER['REMOTE_ADDR'] ?? 'Unknown'; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle notifications dropdown
        function toggleNotifications() {
            const dropdown = document.getElementById('notificationsDropdown');
            dropdown.classList.toggle('show');
            
            // Close other dropdowns
            document.getElementById('profileDropdown').classList.remove('show');
        }
        
        // Toggle profile dropdown
        function toggleProfileMenu() {
            const dropdown = document.getElementById('profileDropdown');
            dropdown.classList.toggle('show');
            
            // Close other dropdowns
            document.getElementById('notificationsDropdown').classList.remove('show');
        }
        
        // Close dropdowns when clicking outside
        window.addEventListener('click', function(event) {
            if (!event.target.closest('.notification-icon') && !event.target.closest('.profile-dropdown')) {
                document.getElementById('notificationsDropdown').classList.remove('show');
                document.getElementById('profileDropdown').classList.remove('show');
            }
        });
        
        // Refresh data periodically (every 5 minutes)
        setInterval(function() {
            if (document.visibilityState === 'visible') {
                location.reload();
            }
        }, 300000);
        
        // Handle loading states
        document.addEventListener('DOMContentLoaded', function() {
            // Add loading class to elements that need it
            const cards = document.querySelectorAll('.stat-card, .card');
            cards.forEach(card => {
                card.addEventListener('click', function() {
                    this.classList.add('loading');
                });
            });
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl + D - Go to dashboard
            if (e.ctrlKey && e.key === 'd') {
                e.preventDefault();
                window.location.href = 'dashboard.php';
            }
            
            // Ctrl + P - Go to profile
            if (e.ctrlKey && e.key === 'p') {
                e.preventDefault();
                window.location.href = 'profile.php';
            }
            
            // Ctrl + L - Logout
            if (e.ctrlKey && e.key === 'l') {
                e.preventDefault();
                if (confirm('Are you sure you want to logout?')) {
                    window.location.href = 'logout.php';
                }
            }
        });
        
        // Search functionality (if you add a search bar)
        function searchDashboard(query) {
            // Implement search logic
            console.log('Searching for:', query);
        }
    </script>
</body>
</html>