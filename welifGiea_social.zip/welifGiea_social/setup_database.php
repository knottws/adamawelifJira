<?php
// Run this file once to set up the database
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Database Setup</h2>";

try {
    // Connect without database
    $pdo = new PDO("mysql:host=localhost", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS welfare_system");
    echo "✓ Database 'welfare_system' created or already exists<br>";
    
    // Use the database
    $pdo->exec("USE welfare_system");
    
    // Create users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100),
        role ENUM('admin', 'finance', 'registration', 'member') DEFAULT 'member',
        is_active BOOLEAN DEFAULT TRUE,
        last_login DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $pdo->exec($sql);
    echo "✓ Table 'users' created<br>";
    
    // Clear existing demo users
    $pdo->exec("DELETE FROM users WHERE email LIKE '%@example.com'");
    
    // Insert demo users with proper password hashes
    $demo_users = [
        ['admin', 'admin@example.com', 'Admin@123', 'System Admin', 'admin'],
        ['finance', 'finance@example.com', 'Finance@123', 'Finance Manager', 'finance'],
        ['registration', 'registration@example.com', 'Reg@123', 'Registration Officer', 'registration'],
        ['member', 'member@example.com', 'Member@123', 'Regular Member', 'member']
    ];
    
    $insert = $pdo->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
    
    foreach ($demo_users as $user) {
        $hashed_password = password_hash($user[2], PASSWORD_DEFAULT);
        $insert->execute([$user[0], $user[1], $hashed_password, $user[3], $user[4]]);
        echo "✓ Created user: {$user[0]} ({$user[4]})<br>";
    }
    
    echo "<h3 style='color: green;'>✓ Setup complete! You can now <a href='simple_login.php'>login here</a></h3>";
    
} catch (PDOException $e) {
    echo "<h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
}
?>