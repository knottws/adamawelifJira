<?php
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

// Update last activity
$_SESSION['last_activity'] = time();

// Update session in database if exists
if (isset($_SESSION['session_token'])) {
    try {
        $pdo->prepare("
            UPDATE user_sessions 
            SET last_activity = NOW() 
            WHERE session_token = ?
        ")->execute([$_SESSION['session_token']]);
    } catch (PDOException $e) {
        // Ignore errors
    }
}

echo json_encode(['success' => true]);
?>