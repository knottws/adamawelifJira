<?php
require_once 'config.php';


// Check if user has finance role or is admin
if (!hasRole('finance') && !hasRole('admin')) {
    header('Location: dashboard.php');
    exit();
}

$pdo = getDB();
$message = '';
$error = '';

// Get filter parameters
$month_filter = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$member_filter = isset($_GET['member_id']) ? $_GET['member_id'] : '';

// Check if contributions table exists, if not create it
try {
    $pdo->query("SELECT 1 FROM contributions LIMIT 1");
} catch (PDOException $e) {
    // Table doesn't exist, create it
    $sql = "CREATE TABLE IF NOT EXISTS contributions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        member_id INT NOT NULL,
        contribution_date DATE NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        payment_method ENUM('cash', 'bank_transfer', 'mobile_money') NOT NULL,
        transaction_reference VARCHAR(100),
        bank_statement_path VARCHAR(255),
        received_by INT,
        status ENUM('paid', 'pending', 'overdue') DEFAULT 'pending',
        payment_month DATE NOT NULL,
        notes TEXT,
        attachment_path VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
        INDEX idx_member (member_id),
        INDEX idx_status (status),
        INDEX idx_payment_month (payment_month)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql);
}

// Handle payment recording
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_payment'])) {
    try {
        $pdo->beginTransaction();
        
        $member_id = $_POST['member_id'];
        $amount = $_POST['amount'];
        $payment_method = $_POST['payment_method'];
        $payment_month = $_POST['payment_month'] . '-01';
        $contribution_date = $_POST['contribution_date'] ?? date('Y-m-d');
        $transaction_reference = $_POST['transaction_reference'] ?? null;
        $notes = $_POST['notes'] ?? null;
        
        // Handle file upload using the handler
        $bank_statement_path = null;
        if (isset($_FILES['bank_statement']) && $_FILES['bank_statement']['error'] == 0) {
            try {
                $bank_statement_path = handleFileUpload('bank_statement', 'bank_statements', 'payment_' . $member_id);
            } catch (Exception $e) {
                // Log error but don't stop the payment process
                error_log("File upload warning: " . $e->getMessage());
                // You can still continue with payment recording
            }
        }
        
        // Check if payment already exists
        $check_stmt = $pdo->prepare("SELECT id FROM contributions WHERE member_id = ? AND payment_month = ?");
        $check_stmt->execute([$member_id, $payment_month]);
        $existing = $check_stmt->fetch();
        
        if ($existing) {
            // If updating and there's a new file, delete the old one
            if ($bank_statement_path) {
                $old_stmt = $pdo->prepare("SELECT bank_statement_path FROM contributions WHERE id = ?");
                $old_stmt->execute([$existing['id']]);
                $old_file = $old_stmt->fetchColumn();
                if ($old_file) {
                    deleteUploadedFile($old_file);
                }
            }
            
            // Update existing payment
            $stmt = $pdo->prepare("
                UPDATE contributions 
                SET amount = ?, payment_method = ?, transaction_reference = ?, 
                    status = 'paid', contribution_date = ?, notes = ?, received_by = ?,
                    bank_statement_path = COALESCE(?, bank_statement_path)
                WHERE member_id = ? AND payment_month = ?
            ");
            $stmt->execute([$amount, $payment_method, $transaction_reference, $contribution_date, $notes, $_SESSION['user_id'], $bank_statement_path, $member_id, $payment_month]);
            $action = "updated";
        } else {
            // Insert new payment
            $stmt = $pdo->prepare("
                INSERT INTO contributions 
                (member_id, contribution_date, amount, payment_method, transaction_reference, status, payment_month, notes, received_by, bank_statement_path)
                VALUES (?, ?, ?, ?, ?, 'paid', ?, ?, ?, ?)
            ");
            $stmt->execute([$member_id, $contribution_date, $amount, $payment_method, $transaction_reference, $payment_month, $notes, $_SESSION['user_id'], $bank_statement_path]);
            $action = "recorded";
        }
        
        $pdo->commit();
        $message = "Payment $action successfully!";
        
        // Log activity
        logActivity('Record Payment', "Recorded payment for member ID: $member_id, Amount: $amount");
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error recording payment: " . $e->getMessage();
        error_log("Payment recording error: " . $e->getMessage());
    }
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    try {
        $stmt = $pdo->prepare("UPDATE contributions SET status = ? WHERE id = ?");
        $stmt->execute([$_POST['status'], $_POST['contribution_id']]);
        $message = "Contribution status updated successfully!";
    } catch (Exception $e) {
        $error = "Error updating status: " . $e->getMessage();
    }
}

// Handle deletion (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_contribution']) && hasRole('admin')) {
    try {
        // Get file path to delete
        $stmt = $pdo->prepare("SELECT bank_statement_path FROM contributions WHERE id = ?");
        $stmt->execute([$_POST['contribution_id']]);
        $file_path = $stmt->fetchColumn();
        
        if ($file_path) {
            deleteUploadedFile($file_path);
        }
        
        $stmt = $pdo->prepare("DELETE FROM contributions WHERE id = ?");
        $stmt->execute([$_POST['contribution_id']]);
        $message = "Contribution deleted successfully!";
    } catch (Exception $e) {
        $error = "Error deleting contribution: " . $e->getMessage();
    }
}

// Build query for contributions
$query = "
    SELECT 
        c.*,
        m.member_number,
        m.full_name as member_name,
        m.phone as member_phone,
        u.full_name as recorded_by_name
    FROM contributions c
    JOIN members m ON c.member_id = m.id
    LEFT JOIN users u ON c.received_by = u.id
    WHERE 1=1
";

$params = [];

if ($month_filter) {
    $query .= " AND DATE_FORMAT(c.payment_month, '%Y-%m') = ?";
    $params[] = $month_filter;
}

if ($status_filter && $status_filter != 'all') {
    $query .= " AND c.status = ?";
    $params[] = $status_filter;
}

if ($member_filter) {
    $query .= " AND c.member_id = ?";
    $params[] = $member_filter;
}

$query .= " ORDER BY c.payment_month DESC, c.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$contributions = $stmt->fetchAll();

// Get summary statistics
try {
    // Total collections
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM contributions WHERE status = 'paid'");
    $total_collected = $stmt->fetchColumn();
    
    // Current month collections
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM contributions WHERE status = 'paid' AND DATE_FORMAT(payment_month, '%Y-%m') = ?");
    $stmt->execute([date('Y-m')]);
    $monthly_collected = $stmt->fetchColumn();
    
    // Paid this month count
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT member_id) FROM contributions WHERE status = 'paid' AND DATE_FORMAT(payment_month, '%Y-%m') = ?");
    $stmt->execute([date('Y-m')]);
    $paid_this_month = $stmt->fetchColumn();
    
    // Overdue count
    $stmt = $pdo->query("SELECT COUNT(DISTINCT member_id) FROM contributions WHERE status = 'overdue'");
    $overdue_count = $stmt->fetchColumn();
    
} catch (Exception $e) {
    $total_collected = 0;
    $monthly_collected = 0;
    $paid_this_month = 0;
    $overdue_count = 0;
}

// Get members for dropdown
$members = $pdo->query("SELECT id, member_number, full_name FROM members WHERE status = 'active' ORDER BY full_name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contributions Management - WelifGiea</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f5f5;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5em;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 0.9em;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .menu-item i {
            width: 20px;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h1 {
            font-size: 1.8em;
            color: #333;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .logout-btn {
            padding: 8px 20px;
            background: #ff4444;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .logout-btn:hover {
            background: #cc0000;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .stat-card h3 {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 10px;
        }

        .stat-card .value {
            font-size: 1.8em;
            font-weight: 700;
            color: #333;
        }

        .filters-bar {
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: flex-end;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            font-size: 0.9em;
            font-weight: 500;
        }

        .filter-group select,
        .filter-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 0.95em;
        }

        .add-btn {
            padding: 12px 25px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
            transition: all 0.3s ease;
        }

        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .table-container {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px 12px;
            background: #f8f9fa;
            color: #555;
            font-weight: 600;
            font-size: 0.9em;
        }

        td {
            padding: 15px 12px;
            border-bottom: 1px solid #f0f0f0;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 600;
            display: inline-block;
        }

        .status-paid {
            background: #d4edda;
            color: #155724;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-overdue {
            background: #f8d7da;
            color: #721c24;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.85em;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5a67d8;
        }

        .btn-success {
            background: #2ecc71;
            color: white;
        }

        .btn-success:hover {
            background: #27ae60;
        }

        .btn-warning {
            background: #f39c12;
            color: white;
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-sm {
            padding: 4px 8px;
            font-size: 0.8em;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h2 {
            font-size: 1.5em;
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5em;
            cursor: pointer;
            color: #999;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: 500;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .no-data {
            text-align: center;
            padding: 50px;
            color: #999;
        }

        .no-data i {
            font-size: 4em;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            .sidebar-header h2,
            .sidebar-header p,
            .menu-item span {
                display: none;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>WelifGiea</h2>
                <p>Contributions</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-home"></i> <span>Dashboard</span>
                </a>
                <a href="finance_dashboard.php" class="menu-item">
                    <i class="fas fa-chart-line"></i> <span>Finance</span>
                </a>
                <a href="members.php" class="menu-item">
                    <i class="fas fa-users"></i> <span>Members</span>
                </a>
                <a href="contributions.php" class="menu-item active">
                    <i class="fas fa-hand-holding-usd"></i> <span>Contributions</span>
                </a>
                <a href="expenses.php" class="menu-item">
                    <i class="fas fa-receipt"></i> <span>Expenses</span>
                </a>
                <a href="reports.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> <span>Reports</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-hand-holding-usd"></i> Contributions Management</h1>
                <div class="user-info">
                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Collected</h3>
                    <div class="value"><?php echo number_format($total_collected, 2); ?> Birr</div>
                </div>
                <div class="stat-card">
                    <h3>This Month</h3>
                    <div class="value"><?php echo number_format($monthly_collected, 2); ?> Birr</div>
                </div>
                <div class="stat-card">
                    <h3>Paid This Month</h3>
                    <div class="value"><?php echo $paid_this_month; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Overdue</h3>
                    <div class="value"><?php echo $overdue_count; ?></div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters-bar">
                <div class="filter-group">
                    <label>Month</label>
                    <select onchange="window.location.href='?month='+this.value+'&status=<?php echo $status_filter; ?>&member_id=<?php echo $member_filter; ?>'">
                        <?php
                        for ($i = 0; $i < 12; $i++) {
                            $date = date('Y-m', strtotime("-$i months"));
                            $selected = ($date == $month_filter) ? 'selected' : '';
                            echo "<option value='$date' $selected>" . date('F Y', strtotime($date . '-01')) . "</option>";
                        }
                        ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Status</label>
                    <select onchange="window.location.href='?month=<?php echo $month_filter; ?>&status='+this.value+'&member_id=<?php echo $member_filter; ?>'">
                        <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All</option>
                        <option value="paid" <?php echo $status_filter == 'paid' ? 'selected' : ''; ?>>Paid</option>
                        <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="overdue" <?php echo $status_filter == 'overdue' ? 'selected' : ''; ?>>Overdue</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Member</label>
                    <select onchange="window.location.href='?month=<?php echo $month_filter; ?>&status=<?php echo $status_filter; ?>&member_id='+this.value">
                        <option value="">All Members</option>
                        <?php foreach ($members as $member): ?>
                            <option value="<?php echo $member['id']; ?>" <?php echo $member_filter == $member['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($member['full_name'] . ' (' . $member['member_number'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button class="add-btn" onclick="openPaymentModal()">
                    <i class="fas fa-plus"></i> Record Payment
                </button>
            </div>

            <!-- Contributions Table -->
            <div class="table-container">
                <?php if (empty($contributions)): ?>
                    <div class="no-data">
                        <i class="fas fa-hand-holding-usd"></i>
                        <h3>No Contributions Found</h3>
                        <p>No contributions match your filter criteria.</p>
                        <button class="add-btn" onclick="openPaymentModal()" style="margin-top: 20px;">
                            <i class="fas fa-plus"></i> Record First Payment
                        </button>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Member</th>
                                <th>Month</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Recorded By</th>
                                <th>Receipt</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($contributions as $c): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($c['contribution_date'])); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($c['member_name']); ?></strong><br>
                                    <small><?php echo $c['member_number']; ?></small>
                                </td>
                                <td><?php echo date('F Y', strtotime($c['payment_month'])); ?></td>
                                <td><strong><?php echo number_format($c['amount'], 2); ?> Birr</strong></td>
                                <td>
                                    <?php
                                    $methodIcons = [
                                        'cash' => 'money-bill',
                                        'bank_transfer' => 'university',
                                        'mobile_money' => 'mobile-alt'
                                    ];
                                    ?>
                                    <i class="fas fa-<?php echo $methodIcons[$c['payment_method']] ?? 'credit-card'; ?>"></i>
                                    <?php echo ucfirst(str_replace('_', ' ', $c['payment_method'])); ?>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo $c['status']; ?>">
                                        <?php echo ucfirst($c['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo $c['recorded_by_name'] ?? 'System'; ?>
                                </td>
                                <td>
                                    <?php if ($c['bank_statement_path']): ?>
                                        <a href="<?php echo $c['bank_statement_path']; ?>" class="btn btn-primary btn-sm" target="_blank">
                                            <i class="fas fa-file-pdf"></i> View
                                        </a>
                                    <?php else: ?>
                                        <span style="color: #999;">No file</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-warning btn-sm" onclick="editStatus(<?php echo $c['id']; ?>, '<?php echo $c['status']; ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        
                                        <?php if (hasRole('admin')): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this contribution?');">
                                            <input type="hidden" name="contribution_id" value="<?php echo $c['id']; ?>">
                                            <button type="submit" name="delete_contribution" class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Record Payment</h2>
                <button class="close-btn" onclick="closePaymentModal()">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="record_payment" value="1">
                
                <div class="form-group">
                    <label>Member *</label>
                    <select name="member_id" required>
                        <option value="">Select Member</option>
                        <?php foreach ($members as $member): ?>
                            <option value="<?php echo $member['id']; ?>">
                                <?php echo htmlspecialchars($member['full_name'] . ' (' . $member['member_number'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Amount (Birr) *</label>
                    <input type="number" name="amount" value="200.00" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label>Payment Month *</label>
                    <input type="month" name="payment_month" value="<?php echo date('Y-m'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Contribution Date *</label>
                    <input type="date" name="contribution_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Payment Method *</label>
                    <select name="payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Transaction Reference</label>
                    <input type="text" name="transaction_reference" placeholder="Receipt/Transaction number">
                </div>
                
                <div class="form-group">
                    <label>Bank Statement/Receipt</label>
                    <input type="file" name="bank_statement" accept=".pdf,.jpg,.jpeg,.png">
                    <small style="color: #999;">Max size: 5MB. Allowed: PDF, JPG, PNG</small>
                </div>
                
                <div class="form-group">
                    <label>Notes</label>
                    <textarea name="notes" rows="3" placeholder="Additional notes..."></textarea>
                </div>
                
                <button type="submit" class="add-btn" style="width: 100%;">Record Payment</button>
            </form>
        </div>
    </div>

    <!-- Status Update Modal -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Update Status</h2>
                <button class="close-btn" onclick="closeStatusModal()">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="update_status" value="1">
                <input type="hidden" name="contribution_id" id="status_contribution_id">
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="status_select" required>
                        <option value="paid">Paid</option>
                        <option value="pending">Pending</option>
                        <option value="overdue">Overdue</option>
                    </select>
                </div>
                
                <button type="submit" class="add-btn" style="width: 100%;">Update Status</button>
            </form>
        </div>
    </div>

    <script>
        function openPaymentModal() {
            document.getElementById('paymentModal').style.display = 'flex';
        }

        function closePaymentModal() {
            document.getElementById('paymentModal').style.display = 'none';
        }

        function editStatus(id, currentStatus) {
            document.getElementById('status_contribution_id').value = id;
            document.getElementById('status_select').value = currentStatus;
            document.getElementById('statusModal').style.display = 'flex';
        }

        function closeStatusModal() {
            document.getElementById('statusModal').style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>