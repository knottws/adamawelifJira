<?php
// check_files.php
$search_dir = __DIR__; // Current directory

echo "<h2>Checking for member dashboard files in: " . $search_dir . "</h2>";

$patterns = [
    '*member*.php',
    '*dashboard*.php',
    '*.php'
];

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Filename</th><th>Size</th><th>Modified</th></tr>";

foreach ($patterns as $pattern) {
    $files = glob($pattern);
    foreach ($files as $file) {
        if (is_file($file)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($file) . "</td>";
            echo "<td>" . filesize($file) . " bytes</td>";
            echo "<td>" . date("Y-m-d H:i:s", filemtime($file)) . "</td>";
            echo "</tr>";
        }
    }
}
echo "</table>";
?>