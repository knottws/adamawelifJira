<?php
// setup_uploads.php - Setup upload directories

echo "<h1>🔧 Setting Up Upload Directories</h1>";

$base_dir = __DIR__ . '/uploads/';
$directories = [
    'uploads',
    'uploads/bank_statements',
    'uploads/receipts',
    'uploads/attachments',
    'uploads/temp'
];

$success = true;

foreach ($directories as $dir) {
    $full_path = __DIR__ . '/' . $dir;
    
    echo "<h3>Checking: $dir</h3>";
    
    if (!file_exists($full_path)) {
        echo "Directory does not exist. Creating...<br>";
        if (mkdir($full_path, 0777, true)) {
            echo "✅ Created successfully<br>";
        } else {
            echo "❌ Failed to create<br>";
            $success = false;
            continue;
        }
    } else {
        echo "✅ Directory exists<br>";
    }
    
    // Set permissions
    if (chmod($full_path, 0777)) {
        echo "✅ Permissions set to 0777<br>";
    } else {
        echo "⚠️ Could not set permissions<br>";
    }
    
    // Test write
    $test_file = $full_path . '/test.txt';
    if (file_put_contents($test_file, 'test')) {
        echo "✅ Directory is writable<br>";
        unlink($test_file);
    } else {
        echo "❌ Directory is NOT writable<br>";
        $success = false;
    }
    
    echo "<br>";
}

// Create .htaccess for security
$htaccess_path = $base_dir . '.htaccess';
$htaccess_content = "Options -Indexes\n";
$htaccess_content .= "<FilesMatch \"\\.(php|php3|php4|php5|phtml|pl|cgi)$\">\n";
$htaccess_content .= "    Order Deny,Allow\n";
$htaccess_content .= "    Deny from all\n";
$htaccess_content .= "</FilesMatch>";

if (!file_exists($htaccess_path)) {
    file_put_contents($htaccess_path, $htaccess_content);
    echo "✅ Created .htaccess file for security<br>";
}

if ($success) {
    echo "<h2 style='color: green;'>✅ All directories are set up correctly!</h2>";
} else {
    echo "<h2 style='color: red;'>⚠️ Some directories have issues. You may need to:</h2>";
    echo "<ul>";
    echo "<li>Run XAMPP as Administrator</li>";
    echo "<li>Check if antivirus is blocking file writes</li>";
    echo "<li>Manually create the folders in C:\\xampp\\htdocs\\welifGiea_social\\</li>";
    echo "</ul>";
}

echo "<p><a href='contributions.php'>Go to Contributions Page</a></p>";
?>