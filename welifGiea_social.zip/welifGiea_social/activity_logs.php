<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_admin = ($_SESSION['user_role'] ?? '') === 'admin';

$error = '';
$success = '';
$activities = [];
$filtered_users = [];

// Pagination settings
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filter parameters
$filter_user = isset($_GET['user_id']) ? (int)$_GET['user_id'] : ($is_admin ? 0 : $user_id);
$filter_action = $_GET['action'] ?? '';
$filter_date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
$filter_date_to = $_GET['date_to'] ?? date('Y-m-d');
$filter_section = $_GET['section'] ?? '';

try {
    // Get all users for filter (admin only)
    if ($is_admin) {
        $users_stmt = $pdo->query("
            SELECT id, username, full_name, email 
            FROM users 
            WHERE is_active = 1 
            ORDER BY username
        ");
        $filtered_users = $users_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Build the query based on filters
    $params = [];
    
    // Check which activity tables exist
    $tables_exist = [
        'login_history' => tableExists($pdo, 'login_history'),
        'user_activities' => tableExists($pdo, 'user_activities'),
        'transactions' => tableExists($pdo, 'transactions'),
        'audit_log' => tableExists($pdo, 'audit_log')
    ];
    
    $union_queries = [];
    
    // Login history
    if ($tables_exist['login_history']) {
        $login_sql = "SELECT 
                        'login' as activity_type,
                        id as activity_id,
                        user_id,
                        login_time as activity_time,
                        'User Login' as action,
                        'auth' as section,
                        CONCAT('Login from ', COALESCE(ip_address, 'unknown IP')) as description,
                        ip_address,
                        user_agent as details,
                        status
                      FROM login_history 
                      WHERE 1=1";
        
        if (!$is_admin || ($filter_user > 0 && $filter_user !== $user_id)) {
            $login_sql .= " AND user_id = :user_id_login";
            $params[':user_id_login'] = $filter_user > 0 ? $filter_user : $user_id;
        } elseif ($filter_user > 0) {
            $login_sql .= " AND user_id = :user_id_login";
            $params[':user_id_login'] = $filter_user;
        }
        
        if (!empty($filter_date_from)) {
            $login_sql .= " AND DATE(login_time) >= :date_from_login";
            $params[':date_from_login'] = $filter_date_from;
        }
        
        if (!empty($filter_date_to)) {
            $login_sql .= " AND DATE(login_time) <= :date_to_login";
            $params[':date_to_login'] = $filter_date_to;
        }
        
        $union_queries[] = $login_sql;
    }
    
    // User activities
    if ($tables_exist['user_activities']) {
        $activity_sql = "SELECT 
                            'user_activity' as activity_type,
                            id as activity_id,
                            user_id,
                            created_at as activity_time,
                            action,
                            section,
                            description,
                            NULL as ip_address,
                            NULL as user_agent,
                            details,
                            'completed' as status
                          FROM user_activities 
                          WHERE 1=1";
        
        if (!$is_admin || ($filter_user > 0 && $filter_user !== $user_id)) {
            $activity_sql .= " AND user_id = :user_id_activity";
            $params[':user_id_activity'] = $filter_user > 0 ? $filter_user : $user_id;
        } elseif ($filter_user > 0) {
            $activity_sql .= " AND user_id = :user_id_activity";
            $params[':user_id_activity'] = $filter_user;
        }
        
        if (!empty($filter_action)) {
            $activity_sql .= " AND action LIKE :action_activity";
            $params[':action_activity'] = "%$filter_action%";
        }
        
        if (!empty($filter_section)) {
            $activity_sql .= " AND section = :section_activity";
            $params[':section_activity'] = $filter_section;
        }
        
        if (!empty($filter_date_from)) {
            $activity_sql .= " AND DATE(created_at) >= :date_from_activity";
            $params[':date_from_activity'] = $filter_date_from;
        }
        
        if (!empty($filter_date_to)) {
            $activity_sql .= " AND DATE(created_at) <= :date_to_activity";
            $params[':date_to_activity'] = $filter_date_to;
        }
        
        $union_queries[] = $activity_sql;
    }
    
    // Transactions
    if ($tables_exist['transactions']) {
        $trans_sql = "SELECT 
                        'transaction' as activity_type,
                        id as activity_id,
                        user_id,
                        created_at as activity_time,
                        type as action,
                        'finance' as section,
                        CONCAT(type, ': ', COALESCE(description, 'No description')) as description,
                        NULL as ip_address,
                        NULL as user_agent,
                        CONCAT('Amount: ', amount) as details,
                        status
                      FROM transactions 
                      WHERE 1=1";
        
        if (!$is_admin || ($filter_user > 0 && $filter_user !== $user_id)) {
            $trans_sql .= " AND user_id = :user_id_trans";
            $params[':user_id_trans'] = $filter_user > 0 ? $filter_user : $user_id;
        } elseif ($filter_user > 0) {
            $trans_sql .= " AND user_id = :user_id_trans";
            $params[':user_id_trans'] = $filter_user;
        }
        
        if (!empty($filter_action)) {
            $trans_sql .= " AND type LIKE :action_trans";
            $params[':action_trans'] = "%$filter_action%";
        }
        
        if (!empty($filter_date_from)) {
            $trans_sql .= " AND DATE(created_at) >= :date_from_trans";
            $params[':date_from_trans'] = $filter_date_from;
        }
        
        if (!empty($filter_date_to)) {
            $trans_sql .= " AND DATE(created_at) <= :date_to_trans";
            $params[':date_to_trans'] = $filter_date_to;
        }
        
        $union_queries[] = $trans_sql;
    }
    
    // Audit log
    if ($tables_exist['audit_log'] && $is_admin) {
        $audit_sql = "SELECT 
                        'audit' as activity_type,
                        id as activity_id,
                        user_id,
                        created_at as activity_time,
                        action,
                        section,
                        description,
                        ip_address,
                        user_agent,
                        old_values as details,
                        status
                      FROM audit_log 
                      WHERE 1=1";
        
        if ($filter_user > 0) {
            $audit_sql .= " AND user_id = :user_id_audit";
            $params[':user_id_audit'] = $filter_user;
        }
        
        if (!empty($filter_action)) {
            $audit_sql .= " AND action LIKE :action_audit";
            $params[':action_audit'] = "%$filter_action%";
        }
        
        if (!empty($filter_section)) {
            $audit_sql .= " AND section = :section_audit";
            $params[':section_audit'] = $filter_section;
        }
        
        if (!empty($filter_date_from)) {
            $audit_sql .= " AND DATE(created_at) >= :date_from_audit";
            $params[':date_from_audit'] = $filter_date_from;
        }
        
        if (!empty($filter_date_to)) {
            $audit_sql .= " AND DATE(created_at) <= :date_to_audit";
            $params[':date_to_audit'] = $filter_date_to;
        }
        
        $union_queries[] = $audit_sql;
    }
    
    if (empty($union_queries)) {
        // No activity tables exist, create a simple message
        $activities = [];
        $total_activities = 0;
        $total_pages = 1;
    } else {
        // Combine all queries with UNION
        $final_sql = implode(" UNION ALL ", $union_queries) . " ORDER BY activity_time DESC LIMIT :limit OFFSET :offset";
        
        // Get total count for pagination
        $count_sql = "SELECT COUNT(*) as total FROM (" . implode(" UNION ALL ", $union_queries) . ") as combined";
        $count_stmt = $pdo->prepare($count_sql);
        
        // Bind parameters for count query (excluding limit/offset)
        foreach ($params as $key => $value) {
            if (strpos($key, '_login') !== false || strpos($key, '_activity') !== false || 
                strpos($key, '_trans') !== false || strpos($key, '_audit') !== false) {
                $count_stmt->bindValue($key, $value);
            }
        }
        
        $count_stmt->execute();
        $total_activities = $count_stmt->fetchColumn();
        $total_pages = ceil($total_activities / $limit);
        
        // Get paginated results
        $stmt = $pdo->prepare($final_sql);
        
        // Bind all parameters
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get unique actions and sections for filter dropdowns
    $actions = [];
    $sections = [];
    
    if ($tables_exist['user_activities']) {
        $actions_stmt = $pdo->query("SELECT DISTINCT action FROM user_activities ORDER BY action");
        $actions = $actions_stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $sections_stmt = $pdo->query("SELECT DISTINCT section FROM user_activities ORDER BY section");
        $sections = $sections_stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    error_log("Activity logs error: " . $e->getMessage());
    $activities = [];
    $total_activities = 0;
    $total_pages = 1;
}

// Helper function to check if table exists
function tableExists($pdo, $table) {
    try {
        $result = $pdo->query("SHOW TABLES LIKE '$table'");
        return $result->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}

// Get username by ID
function getUsername($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("SELECT username, full_name FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user ? ($user['full_name'] ?: $user['username']) : 'Unknown User';
    } catch (PDOException $e) {
        return 'Unknown User';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container-fluid {
            padding: 20px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 20px;
        }
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        .card-header h3 {
            margin: 0;
            font-size: 1.3rem;
        }
        .filter-section {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .table th {
            background: #f8f9fa;
            border-top: none;
            font-weight: 600;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: 500;
        }
        .badge-login { background: #e3f2fd; color: #1976d2; }
        .badge-transaction { background: #e8f5e9; color: #388e3c; }
        .badge-user_activity { background: #fff3e0; color: #f57c00; }
        .badge-audit { background: #f3e5f5; color: #7b1fa2; }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
        .activity-time {
            font-size: 0.85rem;
            color: #6c757d;
        }
        .activity-description {
            max-width: 400px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .pagination {
            margin-bottom: 0;
        }
        .page-item.active .page-link {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: #667eea;
        }
        .export-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        .stat-card {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            margin-bottom: 20px;
        }
        .stat-icon {
            font-size: 2rem;
            color: #667eea;
        }
        .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .detail-popover {
            cursor: pointer;
            color: #667eea;
        }
        .detail-popover:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white rounded mb-4 shadow-sm no-print">
            <div class="container-fluid">
                <span class="navbar-brand">
                    <i class="material-icons" style="vertical-align: middle;">history</i>
                    Activity Logs
                </span>
                <div class="navbar-nav ml-auto">
                    <span class="nav-item nav-link">
                        <i class="material-icons" style="vertical-align: middle;">person</i>
                        <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?>
                    </span>
                    <a href="dashboard.php" class="nav-link">
                        <i class="material-icons" style="vertical-align: middle;">dashboard</i>
                        Dashboard
                    </a>
                    <a href="profile.php" class="nav-link">
                        <i class="material-icons" style="vertical-align: middle;">account_circle</i>
                        Profile
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">🔐</div>
                    <div class="stat-value" id="loginCount">0</div>
                    <div class="stat-label">Logins</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-value" id="transactionCount">0</div>
                    <div class="stat-label">Transactions</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">📝</div>
                    <div class="stat-value" id="activityCount">0</div>
                    <div class="stat-label">Activities</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value" id="userCount">0</div>
                    <div class="stat-label">Active Users</div>
                </div>
            </div>
        </div>
        
        <!-- Error/Success Messages -->
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="material-icons" style="vertical-align: middle;">error</i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" action="" id="filterForm">
                <div class="row">
                    <?php if ($is_admin): ?>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>User</label>
                                <select name="user_id" class="form-control">
                                    <option value="0">All Users</option>
                                    <?php foreach ($filtered_users as $u): ?>
                                        <option value="<?php echo $u['id']; ?>" 
                                            <?php echo $filter_user == $u['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($u['username']); ?> 
                                            (<?php echo htmlspecialchars($u['full_name'] ?: $u['email']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Action Type</label>
                            <select name="action" class="form-control">
                                <option value="">All Actions</option>
                                <option value="login" <?php echo $filter_action == 'login' ? 'selected' : ''; ?>>Login</option>
                                <option value="logout" <?php echo $filter_action == 'logout' ? 'selected' : ''; ?>>Logout</option>
                                <option value="transaction" <?php echo $filter_action == 'transaction' ? 'selected' : ''; ?>>Transaction</option>
                                <option value="profile" <?php echo $filter_action == 'profile' ? 'selected' : ''; ?>>Profile Update</option>
                                <option value="create" <?php echo $filter_action == 'create' ? 'selected' : ''; ?>>Create</option>
                                <option value="update" <?php echo $filter_action == 'update' ? 'selected' : ''; ?>>Update</option>
                                <option value="delete" <?php echo $filter_action == 'delete' ? 'selected' : ''; ?>>Delete</option>
                                <?php foreach ($actions as $act): ?>
                                    <?php if (!in_array($act, ['login', 'logout', 'transaction', 'profile', 'create', 'update', 'delete'])): ?>
                                        <option value="<?php echo $act; ?>" <?php echo $filter_action == $act ? 'selected' : ''; ?>>
                                            <?php echo ucfirst($act); ?>
                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Section</label>
                            <select name="section" class="form-control">
                                <option value="">All Sections</option>
                                <option value="auth" <?php echo $filter_section == 'auth' ? 'selected' : ''; ?>>Authentication</option>
                                <option value="finance" <?php echo $filter_section == 'finance' ? 'selected' : ''; ?>>Finance</option>
                                <option value="members" <?php echo $filter_section == 'members' ? 'selected' : ''; ?>>Members</option>
                                <option value="reports" <?php echo $filter_section == 'reports' ? 'selected' : ''; ?>>Reports</option>
                                <option value="settings" <?php echo $filter_section == 'settings' ? 'selected' : ''; ?>>Settings</option>
                                <?php foreach ($sections as $sec): ?>
                                    <?php if (!in_array($sec, ['auth', 'finance', 'members', 'reports', 'settings'])): ?>
                                        <option value="<?php echo $sec; ?>" <?php echo $filter_section == $sec ? 'selected' : ''; ?>>
                                            <?php echo ucfirst($sec); ?>
                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Date From</label>
                            <input type="date" name="date_from" class="form-control" 
                                   value="<?php echo $filter_date_from; ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Date To</label>
                            <input type="date" name="date_to" class="form-control" 
                                   value="<?php echo $filter_date_to; ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="material-icons" style="vertical-align: middle;">filter_list</i> Apply Filters
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-2">
                    <div class="col-md-12">
                        <button type="button" class="btn btn-secondary btn-sm" onclick="resetFilters()">
                            <i class="material-icons" style="vertical-align: middle;">clear</i> Reset Filters
                        </button>
                        <button type="button" class="btn btn-success btn-sm" onclick="exportToCSV()">
                            <i class="material-icons" style="vertical-align: middle;">download</i> Export to CSV
                        </button>
                        <button type="button" class="btn btn-info btn-sm" onclick="window.print()">
                            <i class="material-icons" style="vertical-align: middle;">print</i> Print
                        </button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Activity Logs Table -->
        <div class="card">
            <div class="card-header">
                <h3><i class="material-icons" style="vertical-align: middle;">list</i> Activity Logs</h3>
            </div>
            <div class="card-body">
                <?php if (empty($activities)): ?>
                    <div class="alert alert-info">
                        <i class="material-icons" style="vertical-align: middle;">info</i>
                        No activity logs found for the selected criteria.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="activityTable">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>User</th>
                                    <th>Type</th>
                                    <th>Action</th>
                                    <th>Section</th>
                                    <th>Description</th>
                                    <th>IP Address</th>
                                    <th>Status</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($activities as $activity): ?>
                                <tr>
                                    <td class="activity-time">
                                        <?php echo date('Y-m-d H:i:s', strtotime($activity['activity_time'])); ?>
                                        <br>
                                        <small><?php echo timeAgo($activity['activity_time']); ?></small>
                                    </td>
                                    <td>
                                        <?php 
                                        $username = getUsername($pdo, $activity['user_id']);
                                        if ($activity['user_id'] == $user_id) {
                                            echo '<strong>' . htmlspecialchars($username) . '</strong> <span class="badge badge-info">You</span>';
                                        } else {
                                            echo htmlspecialchars($username);
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $activity['activity_type']; ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $activity['activity_type'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars(ucfirst($activity['action'])); ?></td>
                                    <td><?php echo htmlspecialchars(ucfirst($activity['section'] ?: 'N/A')); ?></td>
                                    <td class="activity-description" title="<?php echo htmlspecialchars($activity['description']); ?>">
                                        <?php echo htmlspecialchars($activity['description']); ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($activity['ip_address'] ?: 'N/A'); ?></td>
                                    <td>
                                        <?php
                                        $status = $activity['status'] ?? 'completed';
                                        $status_class = 'secondary';
                                        if ($status == 'success' || $status == 'completed') $status_class = 'success';
                                        if ($status == 'failed' || $status == 'error') $status_class = 'danger';
                                        if ($status == 'pending') $status_class = 'warning';
                                        ?>
                                        <span class="badge badge-<?php echo $status_class; ?>">
                                            <?php echo ucfirst($status); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!empty($activity['details'])): ?>
                                            <span class="detail-popover" data-toggle="popover" 
                                                  title="Details" data-content="<?php echo htmlspecialchars($activity['details']); ?>">
                                                <i class="material-icons" style="font-size: 18px;">info</i>
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page-1; ?>&user_id=<?php echo $filter_user; ?>&action=<?php echo urlencode($filter_action); ?>&section=<?php echo urlencode($filter_section); ?>&date_from=<?php echo $filter_date_from; ?>&date_to=<?php echo $filter_date_to; ?>">
                                        Previous
                                    </a>
                                </li>
                                
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&user_id=<?php echo $filter_user; ?>&action=<?php echo urlencode($filter_action); ?>&section=<?php echo urlencode($filter_section); ?>&date_from=<?php echo $filter_date_from; ?>&date_to=<?php echo $filter_date_to; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                                
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page+1; ?>&user_id=<?php echo $filter_user; ?>&action=<?php echo urlencode($filter_action); ?>&section=<?php echo urlencode($filter_section); ?>&date_from=<?php echo $filter_date_from; ?>&date_to=<?php echo $filter_date_to; ?>">
                                        Next
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                    
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <p>Showing <?php echo count($activities); ?> of <?php echo $total_activities; ?> activities</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Export Button -->
    <button class="btn btn-primary export-btn no-print" onclick="exportToCSV()">
        <i class="material-icons">download</i>
    </button>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
    // Initialize popovers
    $(function () {
        $('[data-toggle="popover"]').popover({
            trigger: 'hover',
            placement: 'top',
            html: true
        });
    });
    
    // Reset filters function
    function resetFilters() {
        window.location.href = 'activity_logs.php';
    }
    
    // Export to CSV function
    function exportToCSV() {
        let csv = [];
        let rows = document.querySelectorAll("#activityTable tr");
        
        for (let i = 0; i < rows.length; i++) {
            let row = [], cols = rows[i].querySelectorAll("td, th");
            
            for (let j = 0; j < cols.length; j++) {
                let data = cols[j].innerText.replace(/,/g, ' '); // Remove commas
                row.push('"' + data + '"');
            }
            
            csv.push(row.join(','));
        }
        
        // Download CSV
        let csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
        let downloadLink = document.createElement('a');
        downloadLink.download = 'activity_logs_' + new Date().toISOString().slice(0,10) + '.csv';
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = 'none';
        document.body.appendChild(downloadLink);
        downloadLink.click();
    }
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    
    // Update statistics
    function updateStats() {
        let loginCount = <?php echo count(array_filter($activities, function($a) { return $a['activity_type'] == 'login'; })); ?>;
        let transactionCount = <?php echo count(array_filter($activities, function($a) { return $a['activity_type'] == 'transaction'; })); ?>;
        let activityCount = <?php echo count(array_filter($activities, function($a) { return $a['activity_type'] == 'user_activity'; })); ?>;
        
        document.getElementById('loginCount').textContent = loginCount;
        document.getElementById('transactionCount').textContent = transactionCount;
        document.getElementById('activityCount').textContent = activityCount;
    }
    
    updateStats();
    </script>
    
    <?php
    // Helper function for time ago
    function timeAgo($timestamp) {
        $time_ago = strtotime($timestamp);
        $current_time = time();
        $time_difference = $current_time - $time_ago;
        $seconds = $time_difference;
        
        $minutes = round($seconds / 60);
        $hours = round($seconds / 3600);
        $days = round($seconds / 86400);
        $weeks = round($seconds / 604800);
        $months = round($seconds / 2629440);
        $years = round($seconds / 31553280);
        
        if ($seconds <= 60) {
            return "Just Now";
        } else if ($minutes <= 60) {
            return ($minutes == 1) ? "1 minute ago" : "$minutes minutes ago";
        } else if ($hours <= 24) {
            return ($hours == 1) ? "1 hour ago" : "$hours hours ago";
        } else if ($days <= 7) {
            return ($days == 1) ? "yesterday" : "$days days ago";
        } else if ($weeks <= 4.3) {
            return ($weeks == 1) ? "1 week ago" : "$weeks weeks ago";
        } else if ($months <= 12) {
            return ($months == 1) ? "1 month ago" : "$months months ago";
        } else {
            return ($years == 1) ? "1 year ago" : "$years years ago";
        }
    }
    ?>
    
    <style>
    @media print {
        .no-print, .filter-section, .export-btn, .navbar, .btn, .pagination {
            display: none !important;
        }
        .card {
            box-shadow: none !important;
            border: 1px solid #ddd !important;
        }
        .table {
            font-size: 10pt;
        }
        .badge {
            border: 1px solid #000 !important;
            color: #000 !important;
            background: transparent !important;
        }
    }
    </style>
</body>
</html>