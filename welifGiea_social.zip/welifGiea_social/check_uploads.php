<?php
require_once 'config.php';

echo "<h1>Checking Upload Directories</h1>";

$base_dir = __DIR__ . '/uploads/';
$directories = [
    'uploads/',
    'uploads/bank_statements/',
    'uploads/receipts/',
    'uploads/attachments/'
];

foreach ($directories as $dir) {
    $full_path = __DIR__ . '/' . $dir;
    
    echo "<h3>Checking: $dir</h3>";
    
    // Check if directory exists
    if (file_exists($full_path)) {
        echo "✅ Directory exists<br>";
    } else {
        echo "❌ Directory does not exist. Creating...<br>";
        if (mkdir($full_path, 0777, true)) {
            echo "✅ Directory created successfully<br>";
        } else {
            echo "❌ Failed to create directory. Error: " . error_get_last()['message'] . "<br>";
        }
    }
    
    // Check if directory is writable
    if (is_writable($full_path)) {
        echo "✅ Directory is writable<br>";
    } else {
        echo "❌ Directory is NOT writable. Attempting to fix permissions...<br>";
        if (chmod($full_path, 0777)) {
            echo "✅ Permissions fixed<br>";
        } else {
            echo "❌ Failed to set permissions<br>";
        }
    }
    
    // Test write a file
    $test_file = $full_path . 'test.txt';
    if (file_put_contents($test_file, 'test')) {
        echo "✅ Can write files to this directory<br>";
        unlink($test_file); // Delete test file
    } else {
        echo "❌ Cannot write files to this directory<br>";
    }
    
    echo "<br>";
}

// Also check if UPLOAD_PATH constant is defined correctly
echo "<h2>Configuration Check</h2>";
echo "UPLOAD_PATH constant: " . UPLOAD_PATH . "<br>";
echo "Real path: " . realpath(UPLOAD_PATH) . "<br>";
echo "Directory exists: " . (file_exists(UPLOAD_PATH) ? 'Yes' : 'No') . "<br>";
echo "Directory writable: " . (is_writable(UPLOAD_PATH) ? 'Yes' : 'No') . "<br>";
?>