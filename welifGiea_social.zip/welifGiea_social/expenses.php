<?php
require_once 'config.php';

// Check if user has finance role or is admin (correct function name)
if (!hasRole('finance') && !hasRole('admin')) {
    header('Location: dashboard.php');
    exit();
}

$pdo = getDB();
$message = '';
$error = '';

// Get filter parameters
$month_filter = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$category_filter = isset($_GET['category']) ? $_GET['category'] : 'all';

// Check if expenses table exists, if not create it
try {
    $pdo->query("SELECT 1 FROM expenses LIMIT 1");
} catch (PDOException $e) {
    // Table doesn't exist, create it
    $sql = "CREATE TABLE IF NOT EXISTS expenses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        expense_date DATE NOT NULL,
        category VARCHAR(50) NOT NULL,
        description TEXT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        payment_method ENUM('cash', 'bank_transfer', 'mobile_money') NOT NULL,
        receipt_path VARCHAR(255),
        approved_by INT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_date (expense_date),
        INDEX idx_category (category)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql);
}

// Handle adding new expense
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_expense'])) {
    try {
        $pdo->beginTransaction();
        
        $expense_date = $_POST['expense_date'];
        $category = $_POST['category'];
        $description = $_POST['description'];
        $amount = $_POST['amount'];
        $payment_method = $_POST['payment_method'];
        $notes = $_POST['notes'] ?? null;
        
        // Handle file upload
        $receipt_path = null;
        if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] == 0) {
            $upload_dir = UPLOAD_PATH . 'receipts/';
            $filename = time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "", $_FILES['receipt']['name']);
            $receipt_path = 'uploads/receipts/' . $filename;
            
            if (!move_uploaded_file($_FILES['receipt']['tmp_name'], $upload_dir . $filename)) {
                throw new Exception("Failed to upload receipt file");
            }
        }
        
        // Insert expense
        $stmt = $pdo->prepare("
            INSERT INTO expenses (expense_date, category, description, amount, payment_method, receipt_path, approved_by, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $expense_date,
            $category,
            $description,
            $amount,
            $payment_method,
            $receipt_path,
            $_SESSION['user_id'],
            $notes
        ]);
        
        $pdo->commit();
        $message = "Expense added successfully!";
        
        // Log activity
        logActivity('Add Expense', "Added expense: $description, Amount: $amount");
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error adding expense: " . $e->getMessage();
        error_log("Expense addition error: " . $e->getMessage());
    }
}

// Handle expense update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_expense'])) {
    try {
        $stmt = $pdo->prepare("
            UPDATE expenses 
            SET expense_date = ?, category = ?, description = ?, amount = ?, payment_method = ?, notes = ?
            WHERE id = ?
        ");
        
        $stmt->execute([
            $_POST['expense_date'],
            $_POST['category'],
            $_POST['description'],
            $_POST['amount'],
            $_POST['payment_method'],
            $_POST['notes'],
            $_POST['expense_id']
        ]);
        
        $message = "Expense updated successfully!";
        logActivity('Update Expense', "Updated expense ID: " . $_POST['expense_id']);
        
    } catch (Exception $e) {
        $error = "Error updating expense: " . $e->getMessage();
    }
}

// Handle expense deletion (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_expense']) && hasRole('admin')) {
    try {
        // Get receipt path to delete file
        $stmt = $pdo->prepare("SELECT receipt_path FROM expenses WHERE id = ?");
        $stmt->execute([$_POST['expense_id']]);
        $expense = $stmt->fetch();
        
        if ($expense && $expense['receipt_path']) {
            $file_path = __DIR__ . '/' . $expense['receipt_path'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        $stmt = $pdo->prepare("DELETE FROM expenses WHERE id = ?");
        $stmt->execute([$_POST['expense_id']]);
        
        $message = "Expense deleted successfully!";
        logActivity('Delete Expense', "Deleted expense ID: " . $_POST['expense_id']);
        
    } catch (Exception $e) {
        $error = "Error deleting expense: " . $e->getMessage();
    }
}

// Build query for expenses
$query = "
    SELECT 
        e.*,
        u.full_name as approved_by_name
    FROM expenses e
    LEFT JOIN users u ON e.approved_by = u.id
    WHERE 1=1
";

$params = [];

if ($month_filter) {
    $query .= " AND DATE_FORMAT(e.expense_date, '%Y-%m') = ?";
    $params[] = $month_filter;
}

if ($category_filter && $category_filter != 'all') {
    $query .= " AND e.category = ?";
    $params[] = $category_filter;
}

$query .= " ORDER BY e.expense_date DESC, e.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$expenses = $stmt->fetchAll();

// Get summary statistics
try {
    // Total expenses
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM expenses");
    $total_expenses = $stmt->fetchColumn();
    
    // Current month expenses
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE DATE_FORMAT(expense_date, '%Y-%m') = ?");
    $stmt->execute([date('Y-m')]);
    $monthly_expenses = $stmt->fetchColumn();
    
    // Expenses by category
    $stmt = $pdo->query("
        SELECT category, COUNT(*) as count, COALESCE(SUM(amount), 0) as total
        FROM expenses
        GROUP BY category
        ORDER BY total DESC
    ");
    $category_stats = $stmt->fetchAll();
    
} catch (Exception $e) {
    $total_expenses = 0;
    $monthly_expenses = 0;
    $category_stats = [];
}

// Get unique categories for filter
$categories = $pdo->query("SELECT DISTINCT category FROM expenses ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expenses Management - WelifGiea</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f5f5;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5em;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 0.9em;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .menu-item i {
            width: 20px;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h1 {
            font-size: 1.8em;
            color: #333;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .logout-btn {
            padding: 8px 20px;
            background: #ff4444;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .logout-btn:hover {
            background: #cc0000;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .stat-card h3 {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 10px;
        }

        .stat-card .value {
            font-size: 1.8em;
            font-weight: 700;
            color: #333;
        }

        .stat-card .subtitle {
            color: #999;
            font-size: 0.8em;
            margin-top: 5px;
        }

        .filters-bar {
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: flex-end;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            font-size: 0.9em;
            font-weight: 500;
        }

        .filter-group select,
        .filter-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 0.95em;
        }

        .add-btn {
            padding: 12px 25px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
            transition: all 0.3s ease;
        }

        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .table-container {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px 12px;
            background: #f8f9fa;
            color: #555;
            font-weight: 600;
            font-size: 0.9em;
        }

        td {
            padding: 15px 12px;
            border-bottom: 1px solid #f0f0f0;
        }

        .category-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: 600;
            background: #e8f0fe;
            color: #2c3e50;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.85em;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5a67d8;
        }

        .btn-success {
            background: #2ecc71;
            color: white;
        }

        .btn-success:hover {
            background: #27ae60;
        }

        .btn-warning {
            background: #f39c12;
            color: white;
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-sm {
            padding: 4px 8px;
            font-size: 0.8em;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h2 {
            font-size: 1.5em;
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5em;
            cursor: pointer;
            color: #999;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: 500;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .category-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .category-stat-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }

        .category-stat-item .category {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .category-stat-item .amount {
            font-size: 1.2em;
            color: #667eea;
            font-weight: 700;
        }

        .category-stat-item .count {
            font-size: 0.8em;
            color: #999;
        }

        .no-data {
            text-align: center;
            padding: 50px;
            color: #999;
        }

        .no-data i {
            font-size: 4em;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            .sidebar-header h2,
            .sidebar-header p,
            .menu-item span {
                display: none;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>WelifGiea</h2>
                <p>Expenses</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-home"></i> <span>Dashboard</span>
                </a>
                <a href="finance_dashboard.php" class="menu-item">
                    <i class="fas fa-chart-line"></i> <span>Finance</span>
                </a>
                <a href="members.php" class="menu-item">
                    <i class="fas fa-users"></i> <span>Members</span>
                </a>
                <a href="contributions.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i> <span>Contributions</span>
                </a>
                <a href="expenses.php" class="menu-item active">
                    <i class="fas fa-receipt"></i> <span>Expenses</span>
                </a>
                <a href="reports.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> <span>Reports</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-receipt"></i> Expenses Management</h1>
                <div class="user-info">
                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Expenses</h3>
                    <div class="value"><?php echo number_format($total_expenses, 2); ?> Birr</div>
                </div>
                <div class="stat-card">
                    <h3>This Month</h3>
                    <div class="value"><?php echo number_format($monthly_expenses, 2); ?> Birr</div>
                </div>
                <div class="stat-card">
                    <h3>Total Transactions</h3>
                    <div class="value"><?php echo count($expenses); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Categories</h3>
                    <div class="value"><?php echo count($categories); ?></div>
                </div>
            </div>

            <!-- Category Statistics -->
            <?php if (!empty($category_stats)): ?>
            <div class="category-stats">
                <?php foreach ($category_stats as $cat): ?>
                <div class="category-stat-item">
                    <div class="category"><?php echo ucfirst($cat['category']); ?></div>
                    <div class="amount"><?php echo number_format($cat['total'], 2); ?> Birr</div>
                    <div class="count"><?php echo $cat['count']; ?> transaction(s)</div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="filters-bar">
                <div class="filter-group">
                    <label>Month</label>
                    <select onchange="window.location.href='?month='+this.value+'&category=<?php echo $category_filter; ?>'">
                        <option value="">All Months</option>
                        <?php
                        for ($i = 0; $i < 12; $i++) {
                            $date = date('Y-m', strtotime("-$i months"));
                            $selected = ($date == $month_filter) ? 'selected' : '';
                            echo "<option value='$date' $selected>" . date('F Y', strtotime($date . '-01')) . "</option>";
                        }
                        ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Category</label>
                    <select onchange="window.location.href='?month=<?php echo $month_filter; ?>&category='+this.value">
                        <option value="all">All Categories</option>
                        <option value="venue">Venue Rental</option>
                        <option value="food">Food & Refreshments</option>
                        <option value="transport">Transport</option>
                        <option value="communication">Communication</option>
                        <option value="office">Office Supplies</option>
                        <option value="other">Other</option>
                        <?php foreach ($categories as $cat): ?>
                            <?php if (!in_array($cat, ['venue', 'food', 'transport', 'communication', 'office', 'other'])): ?>
                            <option value="<?php echo $cat; ?>" <?php echo $category_filter == $cat ? 'selected' : ''; ?>>
                                <?php echo ucfirst($cat); ?>
                            </option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button class="add-btn" onclick="openAddModal()">
                    <i class="fas fa-plus"></i> Add Expense
                </button>
            </div>

            <!-- Expenses Table -->
            <div class="table-container">
                <?php if (empty($expenses)): ?>
                    <div class="no-data">
                        <i class="fas fa-receipt"></i>
                        <h3>No Expenses Found</h3>
                        <p><?php echo empty($categories) ? 'No expenses have been recorded yet.' : 'No expenses match your filter criteria.'; ?></p>
                        <button class="add-btn" onclick="openAddModal()" style="margin-top: 20px;">
                            <i class="fas fa-plus"></i> Add First Expense
                        </button>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Category</th>
                                <th>Description</th>
                                <th>Amount</th>
                                <th>Payment Method</th>
                                <th>Approved By</th>
                                <th>Receipt</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($expenses as $expense): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($expense['expense_date'])); ?></td>
                                <td>
                                    <span class="category-badge">
                                        <?php echo ucfirst($expense['category']); ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($expense['description']); ?></strong>
                                    <?php if ($expense['notes']): ?>
                                        <br><small><?php echo htmlspecialchars($expense['notes']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?php echo number_format($expense['amount'], 2); ?> Birr</strong></td>
                                <td>
                                    <?php
                                    $methodIcons = [
                                        'cash' => 'money-bill',
                                        'bank_transfer' => 'university',
                                        'mobile_money' => 'mobile-alt'
                                    ];
                                    ?>
                                    <i class="fas fa-<?php echo $methodIcons[$expense['payment_method']] ?? 'credit-card'; ?>"></i>
                                    <?php echo ucfirst(str_replace('_', ' ', $expense['payment_method'])); ?>
                                </td>
                                <td><?php echo $expense['approved_by_name'] ?? 'N/A'; ?></td>
                                <td>
                                    <?php if ($expense['receipt_path']): ?>
                                        <a href="<?php echo $expense['receipt_path']; ?>" class="btn btn-primary btn-sm" target="_blank">
                                            <i class="fas fa-file-pdf"></i> View
                                        </a>
                                    <?php else: ?>
                                        <span style="color: #999;">No receipt</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-warning btn-sm" onclick="editExpense(<?php echo htmlspecialchars(json_encode($expense)); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        
                                        <?php if (hasRole('admin')): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this expense?');">
                                            <input type="hidden" name="expense_id" value="<?php echo $expense['id']; ?>">
                                            <button type="submit" name="delete_expense" class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add Expense Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Expense</h2>
                <button class="close-btn" onclick="closeAddModal()">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="add_expense" value="1">
                
                <div class="form-group">
                    <label>Expense Date *</label>
                    <input type="date" name="expense_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Category *</label>
                    <select name="category" required>
                        <option value="">Select Category</option>
                        <option value="venue">Venue Rental</option>
                        <option value="food">Food & Refreshments</option>
                        <option value="transport">Transport</option>
                        <option value="communication">Communication</option>
                        <option value="office">Office Supplies</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Description *</label>
                    <textarea name="description" rows="3" required placeholder="Describe the expense..."></textarea>
                </div>
                
                <div class="form-group">
                    <label>Amount (Birr) *</label>
                    <input type="number" name="amount" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label>Payment Method *</label>
                    <select name="payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Receipt (Optional)</label>
                    <input type="file" name="receipt" accept=".pdf,.jpg,.jpeg,.png">
                    <small style="color: #999;">Upload receipt or supporting document</small>
                </div>
                
                <div class="form-group">
                    <label>Notes (Optional)</label>
                    <textarea name="notes" rows="2" placeholder="Additional notes..."></textarea>
                </div>
                
                <button type="submit" class="add-btn" style="width: 100%;">Add Expense</button>
            </form>
        </div>
    </div>

    <!-- Edit Expense Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Expense</h2>
                <button class="close-btn" onclick="closeEditModal()">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="update_expense" value="1">
                <input type="hidden" name="expense_id" id="edit_id">
                
                <div class="form-group">
                    <label>Expense Date *</label>
                    <input type="date" name="expense_date" id="edit_date" required>
                </div>
                
                <div class="form-group">
                    <label>Category *</label>
                    <select name="category" id="edit_category" required>
                        <option value="venue">Venue Rental</option>
                        <option value="food">Food & Refreshments</option>
                        <option value="transport">Transport</option>
                        <option value="communication">Communication</option>
                        <option value="office">Office Supplies</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Description *</label>
                    <textarea name="description" id="edit_description" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Amount (Birr) *</label>
                    <input type="number" name="amount" id="edit_amount" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label>Payment Method *</label>
                    <select name="payment_method" id="edit_payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Notes</label>
                    <textarea name="notes" id="edit_notes" rows="2"></textarea>
                </div>
                
                <button type="submit" class="add-btn" style="width: 100%;">Update Expense</button>
            </form>
        </div>
    </div>

    <script>
        function openAddModal() {
            document.getElementById('addModal').style.display = 'flex';
        }

        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
        }

        function editExpense(expense) {
            document.getElementById('edit_id').value = expense.id;
            document.getElementById('edit_date').value = expense.expense_date;
            document.getElementById('edit_category').value = expense.category;
            document.getElementById('edit_description').value = expense.description;
            document.getElementById('edit_amount').value = expense.amount;
            document.getElementById('edit_payment_method').value = expense.payment_method;
            document.getElementById('edit_notes').value = expense.notes || '';
            
            document.getElementById('editModal').style.display = 'flex';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>