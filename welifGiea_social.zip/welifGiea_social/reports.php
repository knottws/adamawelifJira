<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
require_once 'config.php';

// Check permission
if($_SESSION['user_role'] != 'admin' && $_SESSION['user_role'] != 'finance') {
    header("Location: dashboard.php");
    exit();
}

// Get current date for filters
$current_year = date('Y');
$current_month = date('m');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Reports - WelifGiea Social</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f7fc;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(180deg, #2c3e50 0%, #1a2634 100%);
            color: white;
            padding: 20px;
            overflow-y: auto;
            transition: all 0.3s;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 20px 0;
            text-align: center;
            border-bottom: 2px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }

        .sidebar-header h3 {
            font-size: 24px;
            margin: 10px 0 5px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .sidebar-header p {
            color: #a0aec0;
            font-size: 14px;
        }

        .nav-item {
            margin-bottom: 5px;
        }

        .nav-link {
            color: #cbd5e0;
            padding: 12px 15px;
            border-radius: 10px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-link:hover {
            background: rgba(102, 126, 234, 0.1);
            color: white;
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .nav-link i {
            width: 24px;
            font-size: 18px;
        }

        .main-content {
            margin-left: 280px;
            padding: 30px;
            transition: all 0.3s;
        }

        .top-bar {
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title h2 {
            color: #2d3748;
            font-size: 28px;
            font-weight: 600;
            margin: 0;
        }

        .page-title p {
            color: #718096;
            margin: 5px 0 0;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-name {
            color: #4a5568;
            font-weight: 500;
        }

        .user-role {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .logout-btn {
            background: #f56565;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 10px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #e53e3e;
            transform: translateY(-2px);
            color: white;
        }

        .report-filters {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .filter-group {
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }

        .filter-item {
            flex: 1;
            min-width: 200px;
        }

        .filter-item label {
            display: block;
            margin-bottom: 8px;
            color: #4a5568;
            font-weight: 500;
            font-size: 14px;
        }

        .filter-item select, .filter-item input {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            transition: all 0.3s;
        }

        .filter-item select:focus, .filter-item input:focus {
            border-color: #667eea;
            outline: none;
        }

        .btn-apply {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-apply:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-export {
            background: #48bb78;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-export:hover {
            background: #38a169;
            transform: translateY(-2px);
        }

        .summary-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .summary-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .summary-icon {
            width: 50px;
            height: 50px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }

        .summary-icon i {
            font-size: 24px;
            color: #667eea;
        }

        .summary-label {
            color: #718096;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .summary-value {
            font-size: 32px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 5px;
        }

        .summary-trend {
            font-size: 14px;
            color: #48bb78;
        }

        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .chart-header h3 {
            color: #2d3748;
            font-size: 18px;
            font-weight: 600;
            margin: 0;
        }

        .chart-wrapper {
            height: 300px;
            position: relative;
        }

        .data-table {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .table-header h3 {
            color: #2d3748;
            font-size: 18px;
            font-weight: 600;
            margin: 0;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            background: #f7fafc;
            color: #4a5568;
            font-weight: 600;
            font-size: 14px;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #e2e8f0;
            color: #4a5568;
        }

        tr:hover td {
            background: #f7fafc;
        }

        .amount-positive {
            color: #48bb78;
            font-weight: 600;
        }

        .amount-negative {
            color: #f56565;
            font-weight: 600;
        }

        .report-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 10px;
        }

        .tab-btn {
            padding: 10px 25px;
            border: none;
            background: none;
            color: #718096;
            font-weight: 600;
            border-radius: 10px;
            transition: all 0.3s;
            cursor: pointer;
        }

        .tab-btn:hover {
            background: #f7fafc;
            color: #667eea;
        }

        .tab-btn.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .tab-pane {
            display: none;
        }

        .tab-pane.active {
            display: block;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-left: 0;
            }
            .summary-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-users fa-3x" style="color: #667eea;"></i>
            <h3>WelifGiea Social</h3>
            <p>Financial Reports</p>
        </div>
        
        <div class="nav-item">
            <a href="dashboard.php" class="nav-link">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="members.php" class="nav-link">
                <i class="fas fa-user-plus"></i>
                <span>Member Registration</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="family_members.php" class="nav-link">
                <i class="fas fa-users"></i>
                <span>Family Members</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="contributions.php" class="nav-link">
                <i class="fas fa-money-bill-wave"></i>
                <span>Monthly Contributions</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="expenses.php" class="nav-link">
                <i class="fas fa-chart-line"></i>
                <span>Expenses</span>
            </a>
        </div>
        
        <div class="nav-item">
            <a href="reports.php" class="nav-link active">
                <i class="fas fa-file-alt"></i>
                <span>Financial Reports</span>
            </a>
        </div>
        
        <?php if($_SESSION['user_role'] == 'admin'): ?>
        <div class="nav-item">
            <a href="users.php" class="nav-link">
                <i class="fas fa-user-cog"></i>
                <span>User Management</span>
            </a>
        </div>
        <?php endif; ?>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h2>Financial Reports</h2>
                <p>View and analyze membership financial data</p>
            </div>
            <div class="user-info">
                <span class="user-name">Welcome, <?php echo $_SESSION['user_name']; ?></span>
                <span class="user-role"><?php echo $_SESSION['user_role']; ?></span>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>

        <!-- Report Filters -->
        <div class="report-filters">
            <form id="reportFilters" method="GET">
                <div class="filter-group">
                    <div class="filter-item">
                        <label>Report Type</label>
                        <select id="reportType" name="type">
                            <option value="monthly">Monthly Report</option>
                            <option value="quarterly">Quarterly Report</option>
                            <option value="annual">Annual Report</option>
                            <option value="custom">Custom Range</option>
                        </select>
                    </div>
                    <div class="filter-item" id="monthSelector">
                        <label>Month</label>
                        <select name="month">
                            <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo $i == $current_month ? 'selected' : ''; ?>>
                                    <?php echo date('F', mktime(0, 0, 0, $i, 1)); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="filter-item" id="yearSelector">
                        <label>Year</label>
                        <select name="year">
                            <?php for($i = $current_year; $i >= $current_year-5; $i--): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="filter-item" id="dateRange" style="display: none;">
                        <label>From</label>
                        <input type="date" name="from_date" id="fromDate">
                    </div>
                    <div class="filter-item" id="dateRangeTo" style="display: none;">
                        <label>To</label>
                        <input type="date" name="to_date" id="toDate">
                    </div>
                    <div class="filter-item">
                        <button type="submit" class="btn-apply">
                            <i class="fas fa-search"></i> Generate Report
                        </button>
                    </div>
                    <div class="filter-item">
                        <button type="button" class="btn-export" onclick="exportReport()">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Report Tabs -->
        <div class="report-tabs">
            <button class="tab-btn active" onclick="showTab('summary')">Summary</button>
            <button class="tab-btn" onclick="showTab('contributions')">Contributions</button>
            <button class="tab-btn" onclick="showTab('expenses')">Expenses</button>
            <button class="tab-btn" onclick="showTab('members')">Member Analysis</button>
        </div>

        <!-- Summary Tab -->
        <div id="summaryTab" class="tab-pane active">
            <!-- Summary Cards -->
            <div class="summary-cards">
                <?php
                // Get summary data
                $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total FROM contributions WHERE status = 'paid'");
                $total_contributions = $stmt->fetch()['total'];
                
                $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total FROM expenses");
                $total_expenses = $stmt->fetch()['total'];
                
                $stmt = $pdo->query("SELECT COUNT(*) as total FROM members WHERE status = 'active'");
                $active_members = $stmt->fetch()['total'];
                
                $balance = $total_contributions - $total_expenses;
                ?>
                
                <div class="summary-card">
                    <div class="summary-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="summary-label">Active Members</div>
                    <div class="summary-value"><?php echo $active_members; ?></div>
                    <div class="summary-trend">
                        <i class="fas fa-arrow-up"></i> +12 this month
                    </div>
                </div>

                <div class="summary-card">
                    <div class="summary-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="summary-label">Total Contributions</div>
                    <div class="summary-value">Br <?php echo number_format($total_contributions, 2); ?></div>
                    <div class="summary-trend">
                        <i class="fas fa-arrow-up"></i> +8.5% from last month
                    </div>
                </div>

                <div class="summary-card">
                    <div class="summary-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="summary-label">Total Expenses</div>
                    <div class="summary-value">Br <?php echo number_format($total_expenses, 2); ?></div>
                    <div class="summary-trend">
                        <i class="fas fa-arrow-down"></i> -3.2% from last month
                    </div>
                </div>

                <div class="summary-card">
                    <div class="summary-icon">
                        <i class="fas fa-balance-scale"></i>
                    </div>
                    <div class="summary-label">Current Balance</div>
                    <div class="summary-value <?php echo $balance >= 0 ? 'amount-positive' : 'amount-negative'; ?>">
                        Br <?php echo number_format($balance, 2); ?>
                    </div>
                    <div class="summary-trend">
                        <i class="fas fa-check-circle"></i> Healthy financial status
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="row">
                <div class="col-md-6">
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Monthly Contributions vs Expenses</h3>
                            <select id="chartYear" onchange="updateCharts()">
                                <?php for($i = $current_year; $i >= $current_year-3; $i--): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="monthlyChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Expense Categories</h3>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="categoryChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Payment Status Distribution</h3>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="paymentChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Member Growth</h3>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="growthChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contributions Tab -->
        <div id="contributionsTab" class="tab-pane">
            <div class="data-table">
                <div class="table-header">
                    <h3>Contribution Details</h3>
                    <div>
                        <input type="text" id="searchContributions" placeholder="Search members..." class="form-control" style="width: 250px;">
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="contributionsTable">
                        <thead>
                            <tr>
                                <th>Member Name</th>
                                <th>Member Number</th>
                                <th>Payment Month</th>
                                <th>Amount</th>
                                <th>Payment Method</th>
                                <th>Status</th>
                                <th>Payment Date</th>
                                <th>Reference</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $pdo->query("
                                SELECT c.*, m.full_name, m.member_number 
                                FROM contributions c
                                JOIN members m ON c.member_id = m.id
                                ORDER BY c.contribution_date DESC
                                LIMIT 50
                            ");
                            while($row = $stmt->fetch()):
                                $status_class = $row['status'] == 'paid' ? 'status-paid' : ($row['status'] == 'pending' ? 'status-pending' : 'status-overdue');
                            ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($row['full_name']); ?></strong></td>
                                <td><?php echo $row['member_number']; ?></td>
                                <td><?php echo date('F Y', strtotime($row['payment_month'] . '-01')); ?></td>
                                <td class="amount-positive">Br <?php echo number_format($row['amount'], 2); ?></td>
                                <td><?php echo ucfirst($row['payment_method']); ?></td>
                                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $row['status']; ?></span></td>
                                <td><?php echo $row['contribution_date'] ? date('d/m/Y', strtotime($row['contribution_date'])) : '-'; ?></td>
                                <td><?php echo $row['transaction_reference'] ?: '-'; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Expenses Tab -->
        <div id="expensesTab" class="tab-pane">
            <div class="data-table">
                <div class="table-header">
                    <h3>Expense Details</h3>
                    <div>
                        <input type="text" id="searchExpenses" placeholder="Search expenses..." class="form-control" style="width: 250px;">
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="expensesTable">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Description</th>
                                <th>Category</th>
                                <th>Amount</th>
                                <th>Payment Method</th>
                                <th>Reference</th>
                                <th>Approved By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $pdo->query("
                                SELECT e.*, u.full_name as approver_name 
                                FROM expenses e
                                LEFT JOIN users u ON e.approved_by = u.id
                                ORDER BY e.expense_date DESC
                                LIMIT 50
                            ");
                            while($row = $stmt->fetch()):
                            ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($row['expense_date'])); ?></td>
                                <td><?php echo htmlspecialchars($row['description']); ?></td>
                                <td><span class="badge bg-info"><?php echo $row['category'] ?: 'Other'; ?></span></td>
                                <td class="amount-negative">Br <?php echo number_format($row['amount'], 2); ?></td>
                                <td><?php echo ucfirst($row['payment_method']); ?></td>
                                <td><?php echo $row['transaction_reference'] ?: '-'; ?></td>
                                <td><?php echo $row['approver_name'] ?: 'System'; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Member Analysis Tab -->
        <div id="membersTab" class="tab-pane">
            <div class="data-table">
                <div class="table-header">
                    <h3>Member Contribution Analysis</h3>
                </div>
                <div class="table-responsive">
                    <table id="memberAnalysisTable">
                        <thead>
                            <tr>
                                <th>Member Name</th>
                                <th>Member Number</th>
                                <th>Total Paid</th>
                                <th>Months Paid</th>
                                <th>Months Missed</th>
                                <th>Last Payment</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $pdo->query("
                                SELECT 
                                    m.id,
                                    m.full_name,
                                    m.member_number,
                                    m.status,
                                    COUNT(c.id) as months_paid,
                                    COALESCE(SUM(c.amount), 0) as total_paid,
                                    MAX(c.contribution_date) as last_payment,
                                    (SELECT COUNT(DISTINCT payment_month) FROM contributions WHERE member_id = m.id AND status = 'overdue') as months_missed
                                FROM members m
                                LEFT JOIN contributions c ON m.id = c.member_id AND c.status = 'paid'
                                GROUP BY m.id
                                ORDER BY total_paid DESC
                            ");
                            while($row = $stmt->fetch()):
                                $member_status = $row['status'] == 'active' ? 'Active' : 'Inactive';
                                $status_class = $row['status'] == 'active' ? 'status-paid' : 'status-overdue';
                            ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($row['full_name']); ?></strong></td>
                                <td><?php echo $row['member_number']; ?></td>
                                <td class="amount-positive">Br <?php echo number_format($row['total_paid'], 2); ?></td>
                                <td><?php echo $row['months_paid']; ?> months</td>
                                <td class="<?php echo $row['months_missed'] > 0 ? 'amount-negative' : ''; ?>">
                                    <?php echo $row['months_missed']; ?> months
                                </td>
                                <td><?php echo $row['last_payment'] ? date('d/m/Y', strtotime($row['last_payment'])) : 'Never'; ?></td>
                                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $member_status; ?></span></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Chart instances
        let monthlyChart, categoryChart, paymentChart, growthChart;

        $(document).ready(function() {
            initializeCharts();
            
            // Handle report type change
            $('#reportType').change(function() {
                if($(this).val() === 'custom') {
                    $('#monthSelector, #yearSelector').hide();
                    $('#dateRange, #dateRangeTo').show();
                } else {
                    $('#monthSelector, #yearSelector').show();
                    $('#dateRange, #dateRangeTo').hide();
                    
                    if($(this).val() === 'annual') {
                        $('#monthSelector').hide();
                    } else {
                        $('#monthSelector').show();
                    }
                }
            });

            // Search functionality
            $('#searchContributions').on('keyup', function() {
                var value = $(this).val().toLowerCase();
                $('#contributionsTable tbody tr').filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });

            $('#searchExpenses').on('keyup', function() {
                var value = $(this).val().toLowerCase();
                $('#expensesTable tbody tr').filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });

        function initializeCharts() {
            // Monthly Contributions vs Expenses Chart
            const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
            monthlyChart = new Chart(monthlyCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    datasets: [{
                        label: 'Contributions',
                        data: <?php echo getMonthlyData('contributions'); ?>,
                        borderColor: '#48bb78',
                        backgroundColor: 'rgba(72, 187, 120, 0.1)',
                        tension: 0.4,
                        fill: true
                    }, {
                        label: 'Expenses',
                        data: <?php echo getMonthlyData('expenses'); ?>,
                        borderColor: '#f56565',
                        backgroundColor: 'rgba(245, 101, 101, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'bottom'
                        }
                    }
                }
            });

            // Expense Categories Chart
            const categoryCtx = document.getElementById('categoryChart').getContext('2d');
            categoryChart = new Chart(categoryCtx, {
                type: 'doughnut',
                data: {
                    labels: <?php echo getExpenseCategories(); ?>,
                    datasets: [{
                        data: <?php echo getExpenseCategoryData(); ?>,
                        backgroundColor: [
                            '#667eea',
                            '#48bb78',
                            '#fbbf24',
                            '#f56565',
                            '#a0aec0',
                            '#9f7aea'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'bottom'
                        }
                    },
                    cutout: '60%'
                }
            });

            // Payment Status Chart
            const paymentCtx = document.getElementById('paymentChart').getContext('2d');
            paymentChart = new Chart(paymentCtx, {
                type: 'pie',
                data: {
                    labels: ['Paid', 'Pending', 'Overdue'],
                    datasets: [{
                        data: <?php echo getPaymentStatusData(); ?>,
                        backgroundColor: ['#48bb78', '#fbbf24', '#f56565'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'bottom'
                        }
                    }
                }
            });

            // Member Growth Chart
            const growthCtx = document.getElementById('growthChart').getContext('2d');
            growthChart = new Chart(growthCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo getMemberGrowthLabels(); ?>,
                    datasets: [{
                        label: 'New Members',
                        data: <?php echo getMemberGrowthData(); ?>,
                        backgroundColor: '#667eea',
                        borderRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }

        function updateCharts() {
            // Refresh chart data based on selected year
            // This would require AJAX calls to get new data
        }

        function showTab(tabName) {
            // Hide all tabs
            $('.tab-pane').removeClass('active');
            $('.tab-btn').removeClass('active');
            
            // Show selected tab
            $('#' + tabName + 'Tab').addClass('active');
            $(event.target).addClass('active');
        }

        function exportReport() {
            var reportType = $('#reportType').val();
            var month = $('select[name="month"]').val();
            var year = $('select[name="year"]').val();
            
            // Create CSV content
            var csv = [];
            
            // Add header
            csv.push('WelifGiea Social Membership - Financial Report');
            csv.push('Generated on: ' + new Date().toLocaleDateString());
            csv.push('');
            
            // Add summary
            csv.push('SUMMARY');
            csv.push('Total Members,<?php echo $active_members; ?>');
            csv.push('Total Contributions,<?php echo $total_contributions; ?>');
            csv.push('Total Expenses,<?php echo $total_expenses; ?>');
            csv.push('Current Balance,<?php echo $balance; ?>');
            csv.push('');
            
            // Add contributions table header
            csv.push('CONTRIBUTIONS');
            csv.push('Member Name,Member Number,Month,Amount,Status,Payment Date');
            
            // Add contributions data
            <?php
            $stmt = $pdo->query("
                SELECT m.full_name, m.member_number, c.payment_month, c.amount, c.status, c.contribution_date
                FROM contributions c
                JOIN members m ON c.member_id = m.id
                WHERE c.status = 'paid'
                ORDER BY c.contribution_date DESC
                LIMIT 100
            ");
            while($row = $stmt->fetch()):
            ?>
            csv.push('<?php echo $row['full_name'] . ',' . $row['member_number'] . ',' . $row['payment_month'] . ',' . $row['amount'] . ',' . $row['status'] . ',' . $row['contribution_date']; ?>');
            <?php endwhile; ?>
            
            // Download CSV
            var blob = new Blob([csv.join('\n')], { type: 'text/csv' });
            var url = window.URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'financial_report_' + year + '_' + month + '.csv';
            a.click();
        }
    </script>
</body>
</html>