<?php
require_once 'config.php';

echo "<h2>Password Testing Tool</h2>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $testPassword = $_POST['test_password'] ?? '';
    
    // Get user by username or email
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "<h3>User Found:</h3>";
        echo "<pre>";
        echo "ID: " . $user['id'] . "\n";
        echo "Username: " . $user['username'] . "\n";
        echo "Email: " . $user['email'] . "\n";
        echo "Is Active: " . ($user['is_active'] ? 'Yes' : 'No') . "\n";
        echo "Is Locked: " . ($user['is_locked'] ? 'Yes' : 'No') . "\n";
        echo "Login Attempts: " . $user['login_attempts'] . "\n";
        echo "Stored Hash: " . $user['password'] . "\n";
        echo "</pre>";
        
        // Test password
        if (password_verify($testPassword, $user['password'])) {
            echo "<p style='color: green; font-weight: bold;'>✓ Password is CORRECT!</p>";
            
            // Check if rehash is needed
            if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
                echo "<p style='color: orange;'>⚠ Password hash needs to be updated. New hash would be: " . 
                     password_hash($testPassword, PASSWORD_DEFAULT) . "</p>";
            }
        } else {
            echo "<p style='color: red; font-weight: bold;'>✗ Password is INCORRECT!</p>";
            
            // Show what the hash should be for this password
            echo "<p>For debugging, the correct hash for '" . htmlspecialchars($testPassword) . "' would be:</p>";
            echo "<code>" . password_hash($testPassword, PASSWORD_DEFAULT) . "</code>";
        }
    } else {
        echo "<p style='color: red;'>User not found: " . htmlspecialchars($username) . "</p>";
    }
}
?>
<form method="POST">
    <label>Username or Email:</label><br>
    <input type="text" name="username" required><br><br>
    
    <label>Test Password:</label><br>
    <input type="text" name="test_password" required><br><br>
    
    <input type="submit" value="Test Password">
</form>

<h3>Common Issues:</h3>
<ul>
    <li>Check if password contains special characters that might be getting escaped</li>
    <li>Verify that the password wasn't hashed with a different algorithm</li>
    <li>Make sure there's no whitespace in the password</li>
    <li>Check if the account is active (is_active = 1) and not locked (is_locked = 0)</li>
</ul>