<?php
// Turn on error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
session_start();

// Database configuration
$host = 'localhost';
$dbname = 'welifgiea_social';
$username = 'root';
$password = '';

try {
    // Test database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Test if users table exists
    $test = $pdo->query("SELECT 1 FROM users LIMIT 1");
    echo "<!-- Database and users table OK -->\n";
    
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

$error = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter username and password';
    } else {
        try {
            // Simple query
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();
            
            if ($user) {
                // For testing, accept plain text passwords for demo accounts
                $demo_passwords = [
                    'admin@example.com' => 'Admin@123',
                    'finance@example.com' => 'Finance@123',
                    'registration@example.com' => 'Reg@123',
                    'member@example.com' => 'Member@123'
                ];
                
                // Check if it's a demo account
                if (isset($demo_passwords[$username]) && $password === $demo_passwords[$username]) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'] ?? 'member';
                    
                    // Redirect based on role
                    $role = $user['role'] ?? 'member';
                    switch($role) {
                        case 'admin':
                            header('Location: roles.php');
                            break;
                        case 'finance':
                            header('Location: finance/dashboard.php');
                            break;
                        case 'registration':
                            header('Location: registration/dashboard.php');
                            break;
                        default:
                            header('Location: member/dashboard.php');
                    }
                    exit();
                }
                // Check password using password_verify
                elseif (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'] ?? 'member';
                    
                    // Update last login
                    $update = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $update->execute([$user['id']]);
                    
                    // Redirect
                    header('Location: dashboard.php');
                    exit();
                } else {
                    $error = 'Invalid password';
                }
            } else {
                $error = 'User not found';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .error {
            color: #dc3545;
            margin-bottom: 20px;
            padding: 10px;
            background: #f8d7da;
            border-radius: 5px;
        }
        .demo-accounts {
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 5px;
            font-size: 14px;
        }
        .demo-accounts h3 {
            margin-top: 0;
            color: #333;
        }
        .demo-account {
            padding: 8px;
            border-bottom: 1px solid #dee2e6;
        }
        .demo-account:last-child {
            border-bottom: none;
        }
        .role {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
            margin-left: 5px;
        }
        .role.admin { background: #dc3545; color: white; }
        .role.finance { background: #28a745; color: white; }
        .role.registration { background: #fd7e14; color: white; }
        .role.member { background: #007bff; color: white; }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Login</h1>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="username">Username or Email</label>
                <input type="text" id="username" name="username" required 
                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit">Login</button>
        </form>
        
        <div class="demo-accounts">
            <h3>Demo Accounts:</h3>
            <div class="demo-account">
                <strong>admin@example.com</strong> 
                <span class="role admin">Admin</span>
                <br>Password: Admin@123
            </div>
            <div class="demo-account">
                <strong>finance@example.com</strong> 
                <span class="role finance">Finance</span>
                <br>Password: Finance@123
            </div>
            <div class="demo-account">
                <strong>registration@example.com</strong> 
                <span class="role registration">Registration</span>
                <br>Password: Reg@123
            </div>
            <div class="demo-account">
                <strong>member@example.com</strong> 
                <span class="role member">Member</span>
                <br>Password: Member@123
            </div>
        </div>
    </div>
</body>
</html>