<?php
require_once 'config.php';
requireRole('finance');

$pdo = getDB();

// Get filters from URL
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
$status = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$month = isset($_GET['month']) ? sanitizeInput($_GET['month']) : '';
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$payment_method = isset($_GET['payment_method']) ? sanitizeInput($_GET['payment_method']) : '';

// Build query
$where_conditions = ["1=1"];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(m.member_number LIKE ? OR m.full_name LIKE ? OR c.transaction_reference LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param]);
}

if (!empty($status)) {
    $where_conditions[] = "c.status = ?";
    $params[] = $status;
}

if (!empty($month)) {
    $where_conditions[] = "MONTH(c.payment_month) = ?";
    $params[] = $month;
}

if (!empty($year)) {
    $where_conditions[] = "YEAR(c.payment_month) = ?";
    $params[] = $year;
}

if (!empty($payment_method)) {
    $where_conditions[] = "c.payment_method = ?";
    $params[] = $payment_method;
}

$where_clause = implode(" AND ", $where_conditions);

// Get data
$query = "
    SELECT 
        c.contribution_date,
        m.member_number,
        m.full_name as member_name,
        DATE_FORMAT(c.payment_month, '%M %Y') as payment_month,
        c.amount,
        c.payment_method,
        c.status,
        c.transaction_reference,
        u.full_name as received_by,
        c.notes,
        c.created_at
    FROM contributions c
    JOIN members m ON c.member_id = m.id
    LEFT JOIN users u ON c.received_by = u.id
    WHERE $where_clause
    ORDER BY c.contribution_date DESC
";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$contributions = $stmt->fetchAll();

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="contributions_' . date('Y-m-d') . '.xls"');

// Create Excel file
echo "Date\tMember Number\tMember Name\tPayment Month\tAmount\tMethod\tStatus\tReference\tReceived By\tNotes\tRecorded At\n";

foreach ($contributions as $c) {
    echo date('Y-m-d', strtotime($c['contribution_date'])) . "\t";
    echo $c['member_number'] . "\t";
    echo $c['member_name'] . "\t";
    echo $c['payment_month'] . "\t";
    echo $c['amount'] . "\t";
    echo ucfirst(str_replace('_', ' ', $c['payment_method'])) . "\t";
    echo ucfirst($c['status']) . "\t";
    echo ($c['transaction_reference'] ?? '') . "\t";
    echo ($c['received_by'] ?? '') . "\t";
    echo ($c['notes'] ?? '') . "\t";
    echo date('Y-m-d H:i:s', strtotime($c['created_at'])) . "\n";
}
?>