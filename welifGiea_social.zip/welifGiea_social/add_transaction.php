<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$message = '';
$error = '';
$categories = [
    'Registration Fees',
    'Monthly Contributions',
    'Donations',
    'Event Income',
    'Administrative Expenses',
    'Utilities',
    'Maintenance',
    'Project Expenses',
    'Other'
];

$payment_methods = [
    'Cash',
    'M-Pesa',
    'Bank Transfer',
    'Cheque',
    'Credit Card',
    'Other'
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate required fields
        $required_fields = ['transaction_date', 'description', 'type', 'amount'];
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Please fill in all required fields.");
            }
        }

        // Validate amount
        if (!is_numeric($_POST['amount']) || $_POST['amount'] <= 0) {
            throw new Exception("Please enter a valid amount greater than 0.");
        }

        // Prepare SQL statement
        $sql = "INSERT INTO transactions (
                    user_id, 
                    transaction_date, 
                    description, 
                    category, 
                    type, 
                    amount, 
                    payment_method, 
                    reference_number,
                    notes,
                    status,
                    created_at
                ) VALUES (
                    :user_id, 
                    :transaction_date, 
                    :description, 
                    :category, 
                    :type, 
                    :amount, 
                    :payment_method, 
                    :reference_number,
                    :notes,
                    'completed',
                    NOW()
                )";
        
        $stmt = $pdo->prepare($sql);
        
        // Execute with form data
        $result = $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':transaction_date' => $_POST['transaction_date'],
            ':description' => trim($_POST['description']),
            ':category' => $_POST['category'] ?? 'Other',
            ':type' => $_POST['type'],
            ':amount' => floatval($_POST['amount']),
            ':payment_method' => $_POST['payment_method'] ?? 'Cash',
            ':reference_number' => trim($_POST['reference_number'] ?? ''),
            ':notes' => trim($_POST['notes'] ?? '')
        ]);

        if ($result) {
            $message = "Transaction added successfully!";
            // Clear form data on success
            $_POST = [];
        } else {
            throw new Exception("Failed to add transaction. Please try again.");
        }

    } catch (Exception $e) {
        $error = $e->getMessage();
        error_log("Add transaction error: " . $e->getMessage());
    }
}

// Get today's date for default value
$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Transaction - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container-fluid {
            padding: 20px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 20px;
        }
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
            border: none;
        }
        .card-header h3 {
            margin: 0;
            font-size: 1.5rem;
        }
        .form-group label {
            font-weight: 600;
            color: #495057;
        }
        .form-control, .custom-select {
            border-radius: 5px;
            border: 1px solid #ced4da;
            padding: 10px;
            transition: all 0.3s;
        }
        .form-control:focus, .custom-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 10px 30px;
            font-weight: 600;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .btn-secondary {
            background: #6c757d;
            border: none;
            padding: 10px 30px;
            font-weight: 600;
            border-radius: 5px;
        }
        .alert {
            border-radius: 5px;
            border: none;
            padding: 15px 20px;
        }
        .amount-input {
            font-size: 1.2rem;
            font-weight: 600;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: block;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .sidebar a:hover {
            background: rgba(255,255,255,0.1);
            padding-left: 20px;
        }
        .sidebar i {
            margin-right: 10px;
            vertical-align: middle;
        }
        .main-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <h4 class="mb-4">Menu</h4>
                <a href="finances.php"><i class="material-icons">dashboard</i> Dashboard</a>
                <a href="add_transaction.php" class="active"><i class="material-icons">add_circle</i> Add Transaction</a>
                <a href="transactions.php"><i class="material-icons">list</i> All Transactions</a>
                <a href="reports.php"><i class="material-icons">assessment</i> Reports</a>
                <a href="logout.php" class="mt-5"><i class="material-icons">exit_to_app</i> Logout</a>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <!-- Navigation Bar -->
                <nav class="navbar navbar-expand-lg navbar-light bg-white rounded mb-4 shadow-sm">
                    <div class="container-fluid">
                        <span class="navbar-brand">Add New Transaction</span>
                        <div class="navbar-nav ml-auto">
                            <span class="nav-item nav-link">
                                Welcome, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?>
                            </span>
                        </div>
                    </div>
                </nav>
                
                <!-- Add Transaction Form -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="material-icons" style="vertical-align: middle;">add_circle</i> Transaction Details</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($message): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="material-icons" style="vertical-align: middle;">check_circle</i>
                                <?php echo htmlspecialchars($message); ?>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="material-icons" style="vertical-align: middle;">error</i>
                                <?php echo htmlspecialchars($error); ?>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="" id="transactionForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-field">Transaction Date</label>
                                        <input type="date" 
                                               name="transaction_date" 
                                               class="form-control" 
                                               value="<?php echo htmlspecialchars($_POST['transaction_date'] ?? $today); ?>" 
                                               required>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-field">Transaction Type</label>
                                        <select name="type" class="custom-select" required>
                                            <option value="">Select Type</option>
                                            <option value="income" <?php echo (isset($_POST['type']) && $_POST['type'] == 'income') ? 'selected' : ''; ?>>Income (Money In)</option>
                                            <option value="expense" <?php echo (isset($_POST['type']) && $_POST['type'] == 'expense') ? 'selected' : ''; ?>>Expense (Money Out)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label class="required-field">Description</label>
                                        <input type="text" 
                                               name="description" 
                                               class="form-control" 
                                               placeholder="Enter transaction description" 
                                               value="<?php echo htmlspecialchars($_POST['description'] ?? ''); ?>" 
                                               required>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="required-field">Amount (KES)</label>
                                        <input type="number" 
                                               name="amount" 
                                               class="form-control amount-input" 
                                               placeholder="0.00" 
                                               step="0.01" 
                                               min="0.01" 
                                               value="<?php echo htmlspecialchars($_POST['amount'] ?? ''); ?>" 
                                               required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Category</label>
                                        <select name="category" class="custom-select">
                                            <option value="">Select Category</option>
                                            <?php foreach ($categories as $category): ?>
                                                <option value="<?php echo $category; ?>" 
                                                    <?php echo (isset($_POST['category']) && $_POST['category'] == $category) ? 'selected' : ''; ?>>
                                                    <?php echo $category; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Payment Method</label>
                                        <select name="payment_method" class="custom-select">
                                            <option value="">Select Payment Method</option>
                                            <?php foreach ($payment_methods as $method): ?>
                                                <option value="<?php echo $method; ?>" 
                                                    <?php echo (isset($_POST['payment_method']) && $_POST['payment_method'] == $method) ? 'selected' : ''; ?>>
                                                    <?php echo $method; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Reference Number</label>
                                        <input type="text" 
                                               name="reference_number" 
                                               class="form-control" 
                                               placeholder="e.g., Receipt/Invoice No." 
                                               value="<?php echo htmlspecialchars($_POST['reference_number'] ?? ''); ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Notes</label>
                                        <textarea name="notes" 
                                                  class="form-control" 
                                                  rows="1" 
                                                  placeholder="Additional notes"><?php echo htmlspecialchars($_POST['notes'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <hr>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="material-icons" style="vertical-align: middle;">save</i> Save Transaction
                                </button>
                                <button type="reset" class="btn btn-secondary">
                                    <i class="material-icons" style="vertical-align: middle;">clear</i> Clear Form
                                </button>
                                <a href="finances.php" class="btn btn-secondary">
                                    <i class="material-icons" style="vertical-align: middle;">cancel</i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Quick Tips -->
                <div class="card">
                    <div class="card-header" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                        <h3><i class="material-icons" style="vertical-align: middle;">lightbulb</i> Quick Tips</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h5><i class="material-icons text-success">arrow_upward</i> Income Tips:</h5>
                                <ul>
                                    <li>Record all member contributions promptly</li>
                                    <li>Include donation details when applicable</li>
                                    <li>Add receipt numbers for better tracking</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h5><i class="material-icons text-danger">arrow_downward</i> Expense Tips:</h5>
                                <ul>
                                    <li>Always attach expense descriptions</li>
                                    <li>Categorize expenses properly</li>
                                    <li>Include invoice numbers for verification</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Form validation
        $('#transactionForm').on('submit', function(e) {
            let type = $('select[name="type"]').val();
            let amount = $('input[name="amount"]').val();
            let description = $('input[name="description"]').val().trim();
            
            if (!type) {
                alert('Please select transaction type');
                e.preventDefault();
                return false;
            }
            
            if (!description) {
                alert('Please enter a description');
                e.preventDefault();
                return false;
            }
            
            if (!amount || amount <= 0) {
                alert('Please enter a valid amount');
                e.preventDefault();
                return false;
            }
            
            // Confirm before submitting
            return confirm('Are you sure you want to save this transaction?');
        });
        
        // Auto-format amount
        $('input[name="amount"]').on('blur', function() {
            let amount = parseFloat($(this).val());
            if (!isNaN(amount)) {
                $(this).val(amount.toFixed(2));
            }
        });
        
        // Show/hide tips based on transaction type
        $('select[name="type"]').on('change', function() {
            let type = $(this).val();
            if (type === 'income') {
                $('.income-tip').show();
                $('.expense-tip').hide();
            } else if (type === 'expense') {
                $('.income-tip').hide();
                $('.expense-tip').show();
            }
        });
    });
    
    // Function to generate receipt number (optional)
    function generateReceiptNumber() {
        let prefix = 'RCT';
        let timestamp = Date.now().toString().slice(-6);
        let random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return prefix + timestamp + random;
    }
    </script>
</body>
</html>