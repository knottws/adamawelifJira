<?php
// user_add.php
require_once 'config.php';

if (!isLoggedIn() || $_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$pdo = getDB();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token.';
    } else {
        $username = sanitizeInput($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $email = sanitizeInput($_POST['email'] ?? '');
        $full_name = sanitizeInput($_POST['full_name'] ?? '');
        $role = sanitizeInput($_POST['role'] ?? 'member');

        // Validation
        if (empty($username) || empty($password) || empty($email) || empty($full_name)) {
            $error = 'All fields are required.';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters long.';
        } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password)) {
            $error = 'Password must contain at least one uppercase letter, one lowercase letter, and one number.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format.';
        } else {
            try {
                // Check if username exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
                $stmt->execute([$username]);
                if ($stmt->fetch()) {
                    $error = 'Username already exists.';
                } else {
                    // Check if email exists
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                    $stmt->execute([$email]);
                    if ($stmt->fetch()) {
                        $error = 'Email already exists.';
                    } else {
                        // Create user
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, full_name, role, created_by) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$username, $hashed_password, $email, $full_name, $role, $_SESSION['user_id']]);
                        
                        logActivity('Create User', "Created user: $username");
                        
                        $_SESSION['flash_message'] = 'User created successfully.';
                        $_SESSION['flash_type'] = 'success';
                        header('Location: users.php');
                        exit();
                    }
                }
            } catch (Exception $e) {
                error_log("User creation error: " . $e->getMessage());
                $error = 'An error occurred. Please try again.';
            }
        }
    }
}

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User - WelifGiea</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .form-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #333;
            font-size: 2em;
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 14px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 1em;
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        .password-strength {
            margin-top: 8px;
            height: 5px;
            background: #e0e0e0;
            border-radius: 5px;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
        }

        .password-requirements {
            margin-top: 10px;
            font-size: 0.9em;
            color: #666;
        }

        .password-requirements ul {
            list-style: none;
            margin-top: 5px;
        }

        .password-requirements li {
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .password-requirements li.valid {
            color: #10b981;
        }

        .password-requirements li.invalid {
            color: #ef4444;
        }

        .btn-primary {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            width: 100%;
            padding: 16px;
            background: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 12px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 15px;
        }

        .btn-secondary:hover {
            background: #d0d0d0;
        }

        .error-message {
            background: #fef2f2;
            color: #991b1b;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            text-align: center;
            border-left: 4px solid #dc2626;
        }

        .info-text {
            font-size: 0.9em;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-card">
            <div class="header">
                <h1>Add New User</h1>
                <p>Create a new user account</p>
            </div>

            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" onsubmit="return validateForm()">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="full_name" required 
                           value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>"
                           placeholder="Enter full name">
                </div>

                <div class="form-group">
                    <label>Username *</label>
                    <input type="text" name="username" required 
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                           placeholder="Enter username">
                </div>

                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required 
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                           placeholder="Enter email address">
                </div>

                <div class="form-group">
                    <label>Role *</label>
                    <select name="role" required>
                        <option value="member">Member</option>
                        <option value="registration">Registration Officer</option>
                        <option value="finance">Finance Officer</option>
                        <option value="admin">Administrator</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Password *</label>
                    <input type="password" name="password" id="password" required 
                           placeholder="Enter password" onkeyup="checkPasswordStrength()">
                    <div class="password-strength">
                        <div class="password-strength-bar" id="strengthBar"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Confirm Password *</label>
                    <input type="password" name="confirm_password" id="confirm_password" required 
                           placeholder="Confirm password" onkeyup="checkPasswordMatch()">
                </div>

                <div class="password-requirements" id="passwordRequirements">
                    <ul>
                        <li id="length"><i class="fas fa-times-circle"></i> At least 8 characters</li>
                        <li id="uppercase"><i class="fas fa-times-circle"></i> At least one uppercase letter</li>
                        <li id="lowercase"><i class="fas fa-times-circle"></i> At least one lowercase letter</li>
                        <li id="number"><i class="fas fa-times-circle"></i> At least one number</li>
                        <li id="match"><i class="fas fa-times-circle"></i> Passwords match</li>
                    </ul>
                </div>

                <button type="submit" class="btn-primary">
                    <i class="fas fa-user-plus"></i> Create User
                </button>

                <a href="users.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Users
                </a>
            </form>
        </div>
    </div>

    <script>
        function checkPasswordStrength() {
            const password = document.getElementById('password').value;
            const strengthBar = document.getElementById('strengthBar');
            
            let strength = 0;
            
            // Check length
            if (password.length >= 8) strength += 25;
            document.getElementById('length').className = password.length >= 8 ? 'valid' : 'invalid';
            document.getElementById('length').innerHTML = (password.length >= 8 ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least 8 characters';
            
            // Check uppercase
            if (/[A-Z]/.test(password)) strength += 25;
            document.getElementById('uppercase').className = /[A-Z]/.test(password) ? 'valid' : 'invalid';
            document.getElementById('uppercase').innerHTML = (/[A-Z]/.test(password) ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least one uppercase letter';
            
            // Check lowercase
            if (/[a-z]/.test(password)) strength += 25;
            document.getElementById('lowercase').className = /[a-z]/.test(password) ? 'valid' : 'invalid';
            document.getElementById('lowercase').innerHTML = (/[a-z]/.test(password) ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least one lowercase letter';
            
            // Check number
            if (/[0-9]/.test(password)) strength += 25;
            document.getElementById('number').className = /[0-9]/.test(password) ? 'valid' : 'invalid';
            document.getElementById('number').innerHTML = (/[0-9]/.test(password) ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' At least one number';
            
            // Update strength bar
            strengthBar.style.width = strength + '%';
            
            if (strength <= 25) {
                strengthBar.style.background = '#ef4444';
            } else if (strength <= 50) {
                strengthBar.style.background = '#f59e0b';
            } else if (strength <= 75) {
                strengthBar.style.background = '#3b82f6';
            } else {
                strengthBar.style.background = '#10b981';
            }
        }

        function checkPasswordMatch() {
            const password = document.getElementById('password').value;
            const confirm = document.getElementById('confirm_password').value;
            const matchElement = document.getElementById('match');
            
            if (confirm.length > 0) {
                matchElement.className = password === confirm ? 'valid' : 'invalid';
                matchElement.innerHTML = (password === confirm ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>') + ' Passwords match';
            }
        }

        function validateForm() {
            const password = document.getElementById('password').value;
            const confirm = document.getElementById('confirm_password').value;
            
            if (password !== confirm) {
                alert('Passwords do not match!');
                return false;
            }
            
            if (password.length < 8) {
                alert('Password must be at least 8 characters long!');
                return false;
            }
            
            if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password)) {
                alert('Password must contain uppercase, lowercase, and number!');
                return false;
            }
            
            return true;
        }
    </script>
</body>
</html>