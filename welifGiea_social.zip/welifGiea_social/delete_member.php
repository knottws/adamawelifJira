<?php
require_once 'config.php';
requireRole('admin'); // Only admin can delete

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid security token']);
    exit();
}

$member_id = isset($_POST['member_id']) ? (int)$_POST['member_id'] : 0;

if ($member_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid member ID']);
    exit();
}

try {
    $pdo = getDB();
    
    // Begin transaction
    $pdo->beginTransaction();
    
    // Check if member exists
    $stmt = $pdo->prepare("SELECT full_name FROM members WHERE id = ?");
    $stmt->execute([$member_id]);
    $member = $stmt->fetch();
    
    if (!$member) {
        throw new Exception('Member not found');
    }
    
    // Log the deletion
    logActivity('Delete Member', 'Deleted member: ' . $member['full_name'] . ' (ID: ' . $member_id . ')');
    
    // Delete member (cascade will delete family members and contributions)
    $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
    $stmt->execute([$member_id]);
    
    $pdo->commit();
    
    echo json_encode(['success' => true, 'message' => 'Member deleted successfully']);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>