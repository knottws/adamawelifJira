<?php
require_once 'config.php';

// Check if user has finance role or is admin
if (!hasRole('finance') && !hasRole('admin')) {
    header('Location: dashboard.php');
    exit();
}

$pdo = getDB();
$message = '';
$error = '';

// Get current month summary
$currentMonth = date('Y-m-01');
$currentMonthName = date('F Y');
$nextMonth = date('Y-m-01', strtotime('+1 month'));

// Get statistics with error handling
try {
    // Total members
    $stmt = $pdo->query("SELECT COUNT(*) FROM members WHERE status = 'active'");
    $totalMembers = $stmt->fetchColumn();
    
    // Current month contributions
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_count,
            COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
            COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue_count,
            COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) as total_collected
        FROM contributions 
        WHERE payment_month = ?
    ");
    $stmt->execute([$currentMonth]);
    $summary = $stmt->fetch();
    
    // Get total collections all time
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM contributions WHERE status = 'paid'");
    $totalCollections = $stmt->fetchColumn();
    
    // Get total expenses
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM expenses");
    $totalExpenses = $stmt->fetchColumn();
    
    // Get overdue members for current month
    $stmt = $pdo->prepare("
        SELECT m.id, m.member_number, m.full_name, m.phone, m.email
        FROM members m
        WHERE m.status = 'active' 
        AND NOT EXISTS (
            SELECT 1 FROM contributions c 
            WHERE c.member_id = m.id 
            AND c.payment_month = ?
            AND c.status = 'paid'
        )
        ORDER BY m.full_name
    ");
    $stmt->execute([$currentMonth]);
    $overdue_members = $stmt->fetchAll();
    
    // Get recent transactions
    $stmt = $pdo->prepare("
        SELECT c.*, m.full_name, m.member_number 
        FROM contributions c
        JOIN members m ON c.member_id = m.id
        ORDER BY c.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_transactions = $stmt->fetchAll();
    
    // Get monthly trend for last 6 months
    $stmt = $pdo->prepare("
        SELECT 
            DATE_FORMAT(payment_month, '%Y-%m') as month,
            COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_count,
            COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) as total
        FROM contributions
        WHERE payment_month >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(payment_month, '%Y-%m')
        ORDER BY month DESC
    ");
    $stmt->execute();
    $monthly_trend = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Finance dashboard error: " . $e->getMessage());
    $error = "Error loading dashboard data. Please check database tables.";
    // Set default values
    $totalMembers = 0;
    $summary = ['paid_count' => 0, 'pending_count' => 0, 'overdue_count' => 0, 'total_collected' => 0];
    $totalCollections = 0;
    $totalExpenses = 0;
    $overdue_members = [];
    $recent_transactions = [];
    $monthly_trend = [];
}

// Handle payment recording
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_payment'])) {
    try {
        $pdo->beginTransaction();
        
        $member_id = $_POST['member_id'];
        $amount = $_POST['amount'];
        $payment_method = $_POST['payment_method'];
        $payment_month = $_POST['payment_month'];
        $transaction_reference = $_POST['transaction_reference'] ?? null;
        
        // Check if payment already exists for this month
        $stmt = $pdo->prepare("SELECT id FROM contributions WHERE member_id = ? AND payment_month = ?");
        $stmt->execute([$member_id, $payment_month]);
        
        if ($stmt->fetch()) {
            // Update existing payment
            $stmt = $pdo->prepare("
                UPDATE contributions 
                SET amount = ?, payment_method = ?, transaction_reference = ?, 
                    status = 'paid', contribution_date = CURRENT_DATE()
                WHERE member_id = ? AND payment_month = ?
            ");
            $stmt->execute([$amount, $payment_method, $transaction_reference, $member_id, $payment_month]);
        } else {
            // Insert new payment
            $stmt = $pdo->prepare("
                INSERT INTO contributions (member_id, contribution_date, amount, payment_method, 
                                          transaction_reference, status, payment_month, received_by)
                VALUES (?, CURRENT_DATE(), ?, ?, ?, 'paid', ?, ?)
            ");
            $stmt->execute([$member_id, $amount, $payment_method, $transaction_reference, $payment_month, $_SESSION['user_id']]);
        }
        
        // Handle file upload if any
        if (isset($_FILES['bank_statement']) && $_FILES['bank_statement']['error'] == 0) {
            $upload_dir = UPLOAD_PATH . 'bank_statements/';
            $filename = time() . '_' . $_FILES['bank_statement']['name'];
            $filepath = $upload_dir . $filename;
            
            if (move_uploaded_file($_FILES['bank_statement']['tmp_name'], $filepath)) {
                $stmt = $pdo->prepare("UPDATE contributions SET bank_statement_path = ? WHERE member_id = ? AND payment_month = ?");
                $stmt->execute([$filepath, $member_id, $payment_month]);
            }
        }
        
        $pdo->commit();
        $message = "Payment recorded successfully!";
        
        // Log activity
        logActivity('Record Payment', "Recorded payment for member ID: $member_id, Amount: $amount");
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error recording payment: " . $e->getMessage();
        error_log("Payment recording error: " . $e->getMessage());
    }
}

// Handle expense recording
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_expense'])) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO expenses (expense_date, category, description, amount, payment_method, receipt_path, approved_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $receipt_path = null;
        if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] == 0) {
            $upload_dir = UPLOAD_PATH . 'receipts/';
            $filename = time() . '_' . $_FILES['receipt']['name'];
            $receipt_path = $upload_dir . $filename;
            move_uploaded_file($_FILES['receipt']['tmp_name'], $receipt_path);
        }
        
        $stmt->execute([
            $_POST['expense_date'],
            $_POST['category'],
            $_POST['description'],
            $_POST['amount'],
            $_POST['payment_method'],
            $receipt_path,
            $_SESSION['user_id']
        ]);
        
        $message = "Expense added successfully!";
        logActivity('Add Expense', "Added expense: {$_POST['description']}, Amount: {$_POST['amount']}");
        
    } catch (Exception $e) {
        $error = "Error adding expense: " . $e->getMessage();
        error_log("Expense addition error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Dashboard - WelifGiea</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f5f5;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5em;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 0.9em;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .menu-item i {
            width: 20px;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h1 {
            font-size: 1.8em;
            color: #333;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .logout-btn {
            padding: 8px 20px;
            background: #ff4444;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .logout-btn:hover {
            background: #cc0000;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card h3 {
            color: #666;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }

        .stat-card .value {
            font-size: 2.5em;
            font-weight: 700;
            color: #333;
        }

        .stat-card .subtitle {
            color: #999;
            font-size: 0.9em;
            margin-top: 5px;
        }

        .stat-card.paid .value { color: #2ecc71; }
        .stat-card.pending .value { color: #f39c12; }
        .stat-card.overdue .value { color: #e74c3c; }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .section-title {
            font-size: 1.3em;
            margin: 30px 0 20px;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table-container {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px 12px;
            background: #f8f9fa;
            color: #555;
            font-weight: 600;
            font-size: 0.9em;
        }

        td {
            padding: 15px 12px;
            border-bottom: 1px solid #f0f0f0;
        }

        .overdue-row {
            background: #fff5f5;
        }

        .overdue-row td:first-child {
            border-left: 3px solid #e74c3c;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 600;
            display: inline-block;
        }

        .status-paid {
            background: #d4edda;
            color: #155724;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-overdue {
            background: #f8d7da;
            color: #721c24;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9em;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5a67d8;
        }

        .btn-success {
            background: #2ecc71;
            color: white;
        }

        .btn-success:hover {
            background: #27ae60;
        }

        .btn-warning {
            background: #f39c12;
            color: white;
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 0.85em;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 30px;
        }

        .quick-action-btn {
            background: white;
            border: 2px solid #e0e0e0;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #333;
        }

        .quick-action-btn:hover {
            border-color: #667eea;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.2);
        }

        .quick-action-btn i {
            font-size: 2em;
            color: #667eea;
            margin-bottom: 10px;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h2 {
            font-size: 1.5em;
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5em;
            cursor: pointer;
            color: #999;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: 500;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .chart-container {
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
            height: 300px;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            .sidebar-header h2,
            .sidebar-header p,
            .menu-item span {
                display: none;
            }
            .menu-item {
                justify-content: center;
                padding: 15px;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .sidebar {
                display: none;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>WelifGiea</h2>
                <p>Finance Dashboard</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-home"></i> <span>Dashboard</span>
                </a>
                <a href="finance_dashboard.php" class="menu-item active">
                    <i class="fas fa-chart-line"></i> <span>Finance</span>
                </a>
                <a href="members.php" class="menu-item">
                    <i class="fas fa-users"></i> <span>Members</span>
                </a>
                <a href="contributions.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i> <span>Contributions</span>
                </a>
                <a href="expenses.php" class="menu-item">
                    <i class="fas fa-receipt"></i> <span>Expenses</span>
                </a>
                <a href="reports.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> <span>Reports</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-chart-line"></i> Finance Dashboard</h1>
                <div class="user-info">
                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3><i class="fas fa-users"></i> Total Active Members</h3>
                    <div class="value"><?php echo $totalMembers; ?></div>
                    <div class="subtitle">Eligible for contributions</div>
                </div>
                <div class="stat-card paid">
                    <h3><i class="fas fa-check-circle"></i> Paid This Month</h3>
                    <div class="value"><?php echo $summary['paid_count'] ?? 0; ?></div>
                    <div class="subtitle">out of <?php echo $totalMembers; ?> members</div>
                </div>
                <div class="stat-card pending">
                    <h3><i class="fas fa-clock"></i> Pending</h3>
                    <div class="value"><?php echo $summary['pending_count'] ?? 0; ?></div>
                    <div class="subtitle">Awaiting payment</div>
                </div>
                <div class="stat-card overdue">
                    <h3><i class="fas fa-exclamation-triangle"></i> Overdue</h3>
                    <div class="value"><?php echo count($overdue_members); ?></div>
                    <div class="subtitle">Need follow-up</div>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-money-bill-wave"></i> Collected This Month</h3>
                    <div class="value"><?php echo number_format($summary['total_collected'] ?? 0, 2); ?></div>
                    <div class="subtitle">Birr</div>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-wallet"></i> Total Collections</h3>
                    <div class="value"><?php echo number_format($totalCollections, 2); ?></div>
                    <div class="subtitle">All time</div>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-shopping-cart"></i> Total Expenses</h3>
                    <div class="value"><?php echo number_format($totalExpenses, 2); ?></div>
                    <div class="subtitle">All time</div>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-chart-pie"></i> Net Balance</h3>
                    <div class="value"><?php echo number_format($totalCollections - $totalExpenses, 2); ?></div>
                    <div class="subtitle">Available funds</div>
                </div>
            </div>

            <!-- Chart -->
            <?php if (!empty($monthly_trend)): ?>
            <div class="chart-container">
                <canvas id="trendChart"></canvas>
            </div>
            <?php endif; ?>

            <!-- Overdue Members Section -->
            <h2 class="section-title">
                <i class="fas fa-exclamation-circle" style="color: #e74c3c;"></i> 
                Overdue Members (<?php echo count($overdue_members); ?>)
            </h2>

            <div class="table-container">
                <?php if (empty($overdue_members)): ?>
                    <div style="text-align: center; padding: 40px;">
                        <i class="fas fa-check-circle" style="font-size: 3em; color: #2ecc71; margin-bottom: 10px;"></i>
                        <p style="color: #666;">All members are up to date with their contributions!</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Member #</th>
                                <th>Full Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Due Month</th>
                                <th>Amount</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($overdue_members as $member): ?>
                            <tr class="overdue-row">
                                <td><strong><?php echo htmlspecialchars($member['member_number']); ?></strong></td>
                                <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($member['phone'] ?: 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($member['email'] ?: 'N/A'); ?></td>
                                <td><?php echo $currentMonthName; ?></td>
                                <td><strong>200.00 Birr</strong></td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-primary btn-sm" onclick="openPaymentModal(<?php echo $member['id']; ?>, '<?php echo htmlspecialchars($member['full_name']); ?>')">
                                            <i class="fas fa-hand-holding-usd"></i> Record Payment
                                        </button>
                                        <button class="btn btn-warning btn-sm" onclick="sendReminder(<?php echo $member['id']; ?>)">
                                            <i class="fas fa-bell"></i> Remind
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Recent Transactions -->
            <h2 class="section-title">
                <i class="fas fa-history"></i> Recent Transactions
            </h2>

            <div class="table-container">
                <?php if (empty($recent_transactions)): ?>
                    <div style="text-align: center; padding: 40px;">
                        <i class="fas fa-credit-card" style="font-size: 3em; color: #999; margin-bottom: 10px;"></i>
                        <p style="color: #666;">No transactions recorded yet.</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Member</th>
                                <th>Month</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_transactions as $transaction): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($transaction['contribution_date'])); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($transaction['full_name']); ?></strong><br>
                                    <small><?php echo $transaction['member_number']; ?></small>
                                </td>
                                <td><?php echo date('F Y', strtotime($transaction['payment_month'])); ?></td>
                                <td><strong><?php echo number_format($transaction['amount'], 2); ?> Birr</strong></td>
                                <td>
                                    <?php
                                    $methodIcons = [
                                        'cash' => 'money-bill',
                                        'bank_transfer' => 'university',
                                        'mobile_money' => 'mobile-alt'
                                    ];
                                    ?>
                                    <i class="fas fa-<?php echo $methodIcons[$transaction['payment_method']] ?? 'credit-card'; ?>"></i>
                                    <?php echo ucfirst(str_replace('_', ' ', $transaction['payment_method'])); ?>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo $transaction['status']; ?>">
                                        <?php echo ucfirst($transaction['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-primary btn-sm" onclick="viewReceipt(<?php echo $transaction['id']; ?>)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <?php if ($transaction['bank_statement_path']): ?>
                                        <a href="<?php echo $transaction['bank_statement_path']; ?>" class="btn btn-success btn-sm" target="_blank">
                                            <i class="fas fa-file"></i>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Quick Actions -->
            <div class="quick-actions">
                <div class="quick-action-btn" onclick="openPaymentModal()">
                    <i class="fas fa-hand-holding-usd"></i>
                    <h3>Record Payment</h3>
                    <p>Record a member's contribution</p>
                </div>
                <div class="quick-action-btn" onclick="openExpenseModal()">
                    <i class="fas fa-receipt"></i>
                    <h3>Add Expense</h3>
                    <p>Record a new expense</p>
                </div>
                <a href="reports.php?type=monthly&month=<?php echo $currentMonth; ?>" class="quick-action-btn">
                    <i class="fas fa-download"></i>
                    <h3>Download Report</h3>
                    <p>Monthly financial report</p>
                </a>
                <a href="members.php" class="quick-action-btn">
                    <i class="fas fa-users"></i>
                    <h3>View Members</h3>
                    <p>Manage member information</p>
                </a>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Record Payment</h2>
                <button class="close-btn" onclick="closePaymentModal()">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="record_payment" value="1">
                <input type="hidden" name="member_id" id="payment_member_id">
                
                <div class="form-group">
                    <label>Member</label>
                    <select name="member_id" id="member_select" required>
                        <option value="">Select Member</option>
                        <?php
                        $members = $pdo->query("SELECT id, member_number, full_name FROM members WHERE status = 'active' ORDER BY full_name")->fetchAll();
                        foreach ($members as $member) {
                            echo "<option value='{$member['id']}'>{$member['full_name']} ({$member['member_number']})</option>";
                        }
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Amount (Birr)</label>
                    <input type="number" name="amount" value="200.00" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label>Payment Month</label>
                    <input type="month" name="payment_month" value="<?php echo date('Y-m'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Payment Method</label>
                    <select name="payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Transaction Reference (Optional)</label>
                    <input type="text" name="transaction_reference" placeholder="Receipt/Transaction number">
                </div>
                
                <div class="form-group">
                    <label>Bank Statement/Receipt (Optional)</label>
                    <input type="file" name="bank_statement" accept=".pdf,.jpg,.jpeg,.png">
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">Record Payment</button>
            </form>
        </div>
    </div>

    <!-- Expense Modal -->
    <div id="expenseModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add Expense</h2>
                <button class="close-btn" onclick="closeExpenseModal()">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="add_expense" value="1">
                
                <div class="form-group">
                    <label>Expense Date</label>
                    <input type="date" name="expense_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Category</label>
                    <select name="category" required>
                        <option value="venue">Venue Rental</option>
                        <option value="food">Food & Refreshments</option>
                        <option value="transport">Transport</option>
                        <option value="communication">Communication</option>
                        <option value="office">Office Supplies</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" required placeholder="Describe the expense"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Amount (Birr)</label>
                    <input type="number" name="amount" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label>Payment Method</label>
                    <select name="payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Receipt (Optional)</label>
                    <input type="file" name="receipt" accept=".pdf,.jpg,.jpeg,.png">
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">Add Expense</button>
            </form>
        </div>
    </div>

    <script>
        // Payment Modal Functions
        function openPaymentModal(memberId = null, memberName = null) {
            document.getElementById('paymentModal').style.display = 'flex';
            if (memberId) {
                document.getElementById('member_select').value = memberId;
            }
        }

        function closePaymentModal() {
            document.getElementById('paymentModal').style.display = 'none';
        }

        // Expense Modal Functions
        function openExpenseModal() {
            document.getElementById('expenseModal').style.display = 'flex';
        }

        function closeExpenseModal() {
            document.getElementById('expenseModal').style.display = 'none';
        }

        // Send reminder function
        function sendReminder(memberId) {
            if (confirm('Send payment reminder to this member?')) {
                fetch('send_reminder.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({member_id: memberId})
                })
                .then(response => response.json())
                .then(data => {
                    alert('Reminder sent successfully!');
                })
                .catch(error => {
                    alert('Error sending reminder. Please try again.');
                });
            }
        }

        // View receipt function
        function viewReceipt(contributionId) {
            window.location.href = 'view_receipt.php?id=' + contributionId;
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }

        // Initialize chart if data exists
        <?php if (!empty($monthly_trend)): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('trendChart').getContext('2d');
            
            const months = <?php echo json_encode(array_column($monthly_trend, 'month')); ?>;
            const paidCounts = <?php echo json_encode(array_column($monthly_trend, 'paid_count')); ?>;
            const totals = <?php echo json_encode(array_column($monthly_trend, 'total')); ?>;
            
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: months.map(m => {
                        const [year, month] = m.split('-');
                        return new Date(year, month-1).toLocaleString('default', { month: 'short', year: 'numeric' });
                    }),
                    datasets: [{
                        label: 'Number of Payments',
                        data: paidCounts,
                        borderColor: '#667eea',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y'
                    }, {
                        label: 'Amount Collected (Birr)',
                        data: totals,
                        borderColor: '#2ecc71',
                        backgroundColor: 'rgba(46, 204, 113, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y1'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: '6-Month Contribution Trend'
                        }
                    },
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: 'Number of Members'
                            }
                        },
                        y1: {
                            type: 'linear',
                            display: true,
                            position: 'right',
                            title: {
                                display: true,
                                text: 'Amount (Birr)'
                            },
                            grid: {
                                drawOnChartArea: false,
                            },
                        },
                    }
                }
            });
        });
        <?php endif; ?>
    </script>
</body>
</html>