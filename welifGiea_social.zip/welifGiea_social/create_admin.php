<?php
// create_admin.php - Run this once to create the initial admin user
require_once 'config.php';

$pdo = getDB();

// Check if admin already exists
$stmt = $pdo->query("SELECT id FROM users WHERE role = 'admin'");
if ($stmt->rowCount() > 0) {
    die("Admin user already exists.\n");
}

// Create admin user
$username = 'admin';
$password = password_hash('Admin@123', PASSWORD_DEFAULT);
$email = 'admin@welifgiea.com';
$full_name = 'System Administrator';
$role = 'admin';

try {
    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, full_name, role, is_active) VALUES (?, ?, ?, ?, ?, 1)");
    $stmt->execute([$username, $password, $email, $full_name, $role]);
    
    echo "Admin user created successfully!\n";
    echo "Username: admin\n";
    echo "Password: Admin@123\n";
    echo "Please change the password after first login.\n";
} catch (Exception $e) {
    echo "Error creating admin user: " . $e->getMessage() . "\n";
}