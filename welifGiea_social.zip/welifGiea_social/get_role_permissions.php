<?php
/**
 * Get Role Permissions AJAX Handler
 * For welifgiea_social database
 */

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/config.php';

// Check if $pdo exists
if (!isset($pdo)) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection not found']);
    exit();
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$role_id = isset($_GET['role_id']) ? (int)$_GET['role_id'] : 0;

if (!$role_id) {
    echo json_encode(['permissions' => []]);
    exit();
}

try {
    // Get permission IDs for this role
    $stmt = $pdo->prepare("SELECT permission_id FROM role_permissions WHERE role_id = ?");
    $stmt->execute([$role_id]);
    $permissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo json_encode(['permissions' => $permissions]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>