<?php
require_once 'config.php';
requireLogin('finance');
$roleAccess = getRoleAccess($pdo);
$currentUser = getCurrentUser($pdo);

// Get financial stats
$today = date('Y-m-d');
$firstDay = date('Y-m-01');
$lastDay = date('Y-m-t');

$stats = [
    'collected_today' => $pdo->prepare("SELECT SUM(amount) FROM financial_activities WHERE DATE(payment_date) = ? AND payment_status = 'completed'")->execute([$today])->fetchColumn(),
    'collected_month' => $pdo->prepare("SELECT SUM(amount) FROM financial_activities WHERE payment_date BETWEEN ? AND ? AND payment_status = 'completed'")->execute([$firstDay, $lastDay])->fetchColumn(),
    'pending_payments' => $pdo->prepare("SELECT COUNT(*) FROM contribution_schedule WHERE status = 'pending' AND month = ?")->execute([date('m')])->fetchColumn(),
    'overdue_payments' => $pdo->prepare("SELECT COUNT(*) FROM contribution_schedule WHERE status = 'overdue'")->fetchColumn(),
    'total_members' => $pdo->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn(),
    'paid_members' => $pdo->prepare("SELECT COUNT(DISTINCT member_id) FROM contribution_schedule WHERE status = 'paid' AND month = ?")->execute([date('m')])->fetchColumn()
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Finance Dashboard</h1>
                <div class="user-info">
                    <span class="material-icons">account_balance</span>
                    <span>Welcome, <?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    <span class="role-badge finance">Finance Officer</span>
                </div>
            </header>
            
            <!-- Quick Actions -->
            <div style="display: flex; gap: 15px; margin-bottom: 30px;">
                <a href="record_payment.php" class="btn btn-primary">
                    <span class="material-icons">payment</span> Record Payment
                </a>
                <a href="reports.php?type=monthly" class="btn btn-secondary">
                    <span class="material-icons">assessment</span> Monthly Report
                </a>
                <a href="overdue.php" class="btn btn-warning">
                    <span class="material-icons">warning</span> Overdue Payments
                </a>
            </div>
            
            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon green">
                        <span class="material-icons">today</span>
                    </div>
                    <div class="stat-details">
                        <h3>ETB <?php echo number_format($stats['collected_today'] ?? 0, 2); ?></h3>
                        <p>Collected Today</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <span class="material-icons">date_range</span>
                    </div>
                    <div class="stat-details">
                        <h3>ETB <?php echo number_format($stats['collected_month'] ?? 0, 2); ?></h3>
                        <p>Monthly Collection</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon gold">
                        <span class="material-icons">pending_actions</span>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $stats['pending_payments']; ?></h3>
                        <p>Pending Payments</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon red">
                        <span class="material-icons">warning</span>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $stats['overdue_payments']; ?></h3>
                        <p>Overdue Payments</p>
                    </div>
                </div>
            </div>
            
            <!-- Collection Progress -->
            <div style="background: white; border-radius: 15px; padding: 20px; margin-bottom: 30px;">
                <h3 style="margin-bottom: 20px;">Monthly Collection Progress</h3>
                <div style="display: flex; align-items: center; gap: 20px;">
                    <div style="flex: 1;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Collection Rate</span>
                            <span><?php echo round(($stats['paid_members'] / max($stats['total_members'], 1)) * 100, 2); ?>%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: <?php echo ($stats['paid_members'] / max($stats['total_members'], 1)) * 100; ?>%"></div>
                        </div>
                    </div>
                    <div>
                        <span style="font-size: 24px; font-weight: 700;"><?php echo $stats['paid_members']; ?>/<?php echo $stats['total_members']; ?></span>
                        <span style="color: #666;">members paid</span>
                    </div>
                </div>
            </div>
            
            <!-- Recent Transactions -->
            <div style="background: white; border-radius: 15px; padding: 20px;">
                <h3 style="margin-bottom: 20px;">Recent Transactions</h3>
                <?php
                $recentTransactions = $pdo->query("
                    SELECT fa.*, m.full_name, m.member_number
                    FROM financial_activities fa
                    JOIN members m ON fa.member_id = m.id
                    ORDER BY fa.created_at DESC
                    LIMIT 10
                ")->fetchAll();
                ?>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Member</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Reference</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentTransactions as $transaction): ?>
                        <tr>
                            <td><?php echo date('M j, Y', strtotime($transaction['payment_date'])); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($transaction['full_name']); ?></strong>
                                <br><small><?php echo $transaction['member_number']; ?></small>
                            </td>
                            <td>ETB <?php echo number_format($transaction['amount'], 2); ?></td>
                            <td><?php echo ucfirst($transaction['payment_method']); ?></td>
                            <td><?php echo $transaction['transaction_reference'] ?: '-'; ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $transaction['payment_status']; ?>">
                                    <?php echo $transaction['payment_status']; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>