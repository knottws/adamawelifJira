<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/config.php';

// Initialize variables
$error = '';
$success = '';
$step = isset($_GET['step']) ? $_GET['step'] : 'request'; // request, verify, reset
$email = '';
$reset_token = '';

// Handle password reset request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['request_reset'])) {
        // Step 1: Request password reset
        $email = trim($_POST['email'] ?? '');
        
        if (empty($email)) {
            $error = "Please enter your email address.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        } else {
            try {
                // Check if user exists
                $stmt = $pdo->prepare("SELECT id, username, full_name FROM users WHERE email = ?");
                $stmt->execute([$email]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user) {
                    // Generate reset token
                    $token = bin2hex(random_bytes(32));
                    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                    
                    // Save token to database
                    $update = $pdo->prepare("
                        UPDATE users 
                        SET reset_token = ?, reset_expires = ? 
                        WHERE id = ?
                    ");
                    $update->execute([$token, $expires, $user['id']]);
                    
                    // Send reset email
                    $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/welifGiea_social/forgot_password.php?step=reset&token=" . $token;
                    
                    $to = $email;
                    $subject = "Password Reset Request - " . SITE_NAME;
                    $message = "
                        <html>
                        <head>
                            <title>Password Reset</title>
                        </head>
                        <body>
                            <h2>Password Reset Request</h2>
                            <p>Hello " . htmlspecialchars($user['full_name'] ?: $user['username']) . ",</p>
                            <p>We received a request to reset your password. Click the link below to reset it:</p>
                            <p><a href='$reset_link'>$reset_link</a></p>
                            <p>This link will expire in 1 hour.</p>
                            <p>If you didn't request this, please ignore this email.</p>
                            <br>
                            <p>Regards,<br>" . SITE_NAME . " Team</p>
                        </body>
                        </html>
                    ";
                    
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $headers .= "From: noreply@" . $_SERVER['HTTP_HOST'] . "\r\n";
                    
                    if (mail($to, $subject, $message, $headers)) {
                        $success = "Password reset instructions have been sent to your email.";
                    } else {
                        // For development/testing, show the link
                        $success = "Password reset link: <a href='$reset_link'>$reset_link</a> (Email sending failed - showing link for testing)";
                    }
                } else {
                    // Don't reveal that email doesn't exist (security)
                    $success = "If your email is registered, you will receive reset instructions.";
                }
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
                error_log("Password reset error: " . $e->getMessage());
            }
        }
    } elseif (isset($_POST['reset_password'])) {
        // Step 3: Reset password
        $token = $_POST['token'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($token)) {
            $error = "Invalid reset token.";
        } elseif (empty($password)) {
            $error = "Password is required.";
        } elseif (strlen($password) < 8) {
            $error = "Password must be at least 8 characters long.";
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $error = "Password must contain at least one uppercase letter.";
        } elseif (!preg_match('/[a-z]/', $password)) {
            $error = "Password must contain at least one lowercase letter.";
        } elseif (!preg_match('/[0-9]/', $password)) {
            $error = "Password must contain at least one number.";
        } elseif (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
            $error = "Password must contain at least one special character.";
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match.";
        } else {
            try {
                // Verify token
                $stmt = $pdo->prepare("
                    SELECT id FROM users 
                    WHERE reset_token = ? AND reset_expires > NOW()
                ");
                $stmt->execute([$token]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user) {
                    // Update password
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $update = $pdo->prepare("
                        UPDATE users 
                        SET password = ?, reset_token = NULL, reset_expires = NULL 
                        WHERE id = ?
                    ");
                    $update->execute([$hashed_password, $user['id']]);
                    
                    $success = "Password has been reset successfully. You can now login with your new password.";
                    
                    // Redirect to login after 3 seconds
                    header("refresh:3;url=login.php");
                } else {
                    $error = "Invalid or expired reset token. Please request a new one.";
                }
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Handle token from URL for reset step
if (isset($_GET['token']) && $step === 'reset') {
    $reset_token = $_GET['token'];
    
    // Verify token exists and is valid
    try {
        $stmt = $pdo->prepare("
            SELECT id FROM users 
            WHERE reset_token = ? AND reset_expires > NOW()
        ");
        $stmt->execute([$reset_token]);
        
        if (!$stmt->fetch()) {
            $error = "Invalid or expired reset token. Please request a new one.";
            $step = 'request';
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
        $step = 'request';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            max-width: 450px;
            width: 100%;
        }
        
        .card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            border: none;
            overflow: hidden;
        }
        
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
            border: none;
        }
        
        .card-header h2 {
            margin: 0 0 10px;
            font-size: 24px;
            font-weight: 600;
        }
        
        .card-header p {
            margin: 0;
            opacity: 0.9;
            font-size: 14px;
        }
        
        .card-body {
            padding: 40px;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #495057;
            font-size: 14px;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group .material-icons {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 10;
            font-size: 20px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #667eea;
            outline: none;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .btn {
            display: inline-block;
            padding: 14px 24px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            text-align: center;
            text-decoration: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .btn-outline-secondary {
            background: transparent;
            border: 2px solid #6c757d;
            color: #6c757d;
        }
        
        .btn-outline-secondary:hover {
            background: #6c757d;
            color: white;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            border: none;
            font-size: 14px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
        }
        
        .password-requirements {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            font-size: 13px;
        }
        
        .requirement {
            margin: 5px 0;
            color: #6c757d;
            display: flex;
            align-items: center;
        }
        
        .requirement i {
            font-size: 16px;
            margin-right: 8px;
        }
        
        .requirement.met {
            color: #28a745;
        }
        
        .password-strength {
            margin-top: 10px;
        }
        
        .progress {
            height: 8px;
            border-radius: 4px;
            background: #e0e0e0;
        }
        
        .progress-bar {
            border-radius: 4px;
            transition: width 0.3s;
        }
        
        .strength-text {
            font-size: 12px;
            margin-top: 5px;
            display: block;
        }
        
        .back-to-login {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-to-login a {
            color: #6c757d;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }
        
        .back-to-login a:hover {
            color: #667eea;
        }
        
        .back-to-login i {
            vertical-align: middle;
            margin-right: 5px;
        }
        
        .info-text {
            text-align: center;
            color: #6c757d;
            font-size: 14px;
            margin-bottom: 25px;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        .shake {
            animation: shake 0.5s;
        }
        
        .footer {
            text-align: center;
            margin-top: 20px;
            color: rgba(255,255,255,0.8);
            font-size: 13px;
        }
        
        .footer a {
            color: white;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2><?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></h2>
                <p>
                    <?php 
                    if ($step === 'request') {
                        echo "Reset your password";
                    } elseif ($step === 'reset') {
                        echo "Create new password";
                    }
                    ?>
                </p>
            </div>
            
            <div class="card-body">
                <!-- Error/Success Messages -->
                <?php if ($error): ?>
                    <div class="alert alert-danger shake">
                        <i class="material-icons" style="vertical-align: middle; font-size: 18px;">error</i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="material-icons" style="vertical-align: middle; font-size: 18px;">check_circle</i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Step 1: Request Reset -->
                <?php if ($step === 'request'): ?>
                    <div class="info-text">
                        Enter your email address and we'll send you instructions to reset your password.
                    </div>
                    
                    <form method="POST" action="" id="requestForm">
                        <div class="form-group">
                            <label>Email Address</label>
                            <div class="input-group">
                                <i class="material-icons">email</i>
                                <input type="email" 
                                       name="email" 
                                       class="form-control" 
                                       placeholder="Enter your email"
                                       value="<?php echo htmlspecialchars($email); ?>"
                                       required>
                            </div>
                        </div>
                        
                        <button type="submit" name="request_reset" class="btn btn-primary">
                            <i class="material-icons" style="vertical-align: middle; font-size: 18px;">send</i>
                            Send Reset Instructions
                        </button>
                    </form>
                    
                    <div class="back-to-login">
                        <a href="login.php">
                            <i class="material-icons" style="font-size: 16px;">arrow_back</i>
                            Back to Login
                        </a>
                    </div>
                <?php endif; ?>
                
                <!-- Step 2: Reset Password -->
                <?php if ($step === 'reset'): ?>
                    <form method="POST" action="" id="resetForm">
                        <input type="hidden" name="token" value="<?php echo htmlspecialchars($reset_token); ?>">
                        
                        <div class="form-group">
                            <label>New Password</label>
                            <div class="input-group">
                                <i class="material-icons">lock</i>
                                <input type="password" 
                                       name="password" 
                                       id="password" 
                                       class="form-control" 
                                       placeholder="Enter new password"
                                       onkeyup="checkPasswordStrength()"
                                       required>
                            </div>
                            
                            <!-- Password Strength Meter -->
                            <div class="password-strength">
                                <div class="progress">
                                    <div class="progress-bar" id="strengthBar" style="width: 0%"></div>
                                </div>
                                <span class="strength-text" id="strengthText">Enter a password</span>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <div class="input-group">
                                <i class="material-icons">lock_outline</i>
                                <input type="password" 
                                       name="confirm_password" 
                                       id="confirm_password" 
                                       class="form-control" 
                                       placeholder="Confirm new password"
                                       onkeyup="checkPasswordMatch()"
                                       required>
                            </div>
                            <small id="passwordMatchMsg" class="form-text"></small>
                        </div>
                        
                        <!-- Password Requirements -->
                        <div class="password-requirements">
                            <h6>Password Requirements:</h6>
                            <div class="requirement" id="req-length">
                                <i class="material-icons">check_circle_outline</i> At least 8 characters
                            </div>
                            <div class="requirement" id="req-uppercase">
                                <i class="material-icons">check_circle_outline</i> At least one uppercase letter
                            </div>
                            <div class="requirement" id="req-lowercase">
                                <i class="material-icons">check_circle_outline</i> At least one lowercase letter
                            </div>
                            <div class="requirement" id="req-number">
                                <i class="material-icons">check_circle_outline</i> At least one number
                            </div>
                            <div class="requirement" id="req-special">
                                <i class="material-icons">check_circle_outline</i> At least one special character
                            </div>
                        </div>
                        
                        <button type="submit" name="reset_password" class="btn btn-primary" id="submitBtn">
                            <i class="material-icons" style="vertical-align: middle;">vpn_key</i>
                            Reset Password
                        </button>
                    </form>
                    
                    <div class="back-to-login">
                        <a href="login.php">
                            <i class="material-icons" style="font-size: 16px;">arrow_back</i>
                            Back to Login
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="footer">
            &copy; <?php echo date('Y'); ?> <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?>. All rights reserved.
        </div>
    </div>
    
    <script>
    // Check password strength
    function checkPasswordStrength() {
        const password = document.getElementById('password').value;
        let strength = 0;
        
        // Length check
        if (password.length >= 8) {
            strength += 20;
            document.getElementById('req-length').classList.add('met');
        } else {
            document.getElementById('req-length').classList.remove('met');
        }
        
        // Uppercase check
        if (/[A-Z]/.test(password)) {
            strength += 20;
            document.getElementById('req-uppercase').classList.add('met');
        } else {
            document.getElementById('req-uppercase').classList.remove('met');
        }
        
        // Lowercase check
        if (/[a-z]/.test(password)) {
            strength += 20;
            document.getElementById('req-lowercase').classList.add('met');
        } else {
            document.getElementById('req-lowercase').classList.remove('met');
        }
        
        // Number check
        if (/[0-9]/.test(password)) {
            strength += 20;
            document.getElementById('req-number').classList.add('met');
        } else {
            document.getElementById('req-number').classList.remove('met');
        }
        
        // Special character check
        if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
            strength += 20;
            document.getElementById('req-special').classList.add('met');
        } else {
            document.getElementById('req-special').classList.remove('met');
        }
        
        // Update strength bar
        const bar = document.getElementById('strengthBar');
        const text = document.getElementById('strengthText');
        
        bar.style.width = strength + '%';
        
        if (strength <= 20) {
            bar.className = 'progress-bar bg-danger';
            text.textContent = 'Very Weak';
        } else if (strength <= 40) {
            bar.className = 'progress-bar bg-danger';
            text.textContent = 'Weak';
        } else if (strength <= 60) {
            bar.className = 'progress-bar bg-warning';
            text.textContent = 'Fair';
        } else if (strength <= 80) {
            bar.className = 'progress-bar bg-info';
            text.textContent = 'Good';
        } else {
            bar.className = 'progress-bar bg-success';
            text.textContent = 'Strong';
        }
        
        checkPasswordMatch();
    }
    
    // Check if passwords match
    function checkPasswordMatch() {
        const password = document.getElementById('password').value;
        const confirm = document.getElementById('confirm_password').value;
        const msg = document.getElementById('passwordMatchMsg');
        
        if (confirm.length > 0) {
            if (password === confirm) {
                msg.innerHTML = '<span style="color: #28a745;">✓ Passwords match</span>';
            } else {
                msg.innerHTML = '<span style="color: #dc3545;">✗ Passwords do not match</span>';
            }
        } else {
            msg.innerHTML = '';
        }
    }
    
    // Form validation
    document.getElementById('resetForm')?.addEventListener('submit', function(e) {
        const password = document.getElementById('password').value;
        const confirm = document.getElementById('confirm_password').value;
        const strength = parseInt(document.getElementById('strengthBar').style.width);
        
        if (password !== confirm) {
            e.preventDefault();
            alert('Passwords do not match!');
            return false;
        }
        
        if (strength < 60) {
            if (!confirm('Password strength is weak. Are you sure you want to continue?')) {
                e.preventDefault();
                return false;
            }
        }
        
        return true;
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        document.querySelectorAll('.alert').forEach(alert => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
    </script>
</body>
</html>