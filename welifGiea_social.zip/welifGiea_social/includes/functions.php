<?php
/**
 * Central functions file for the application
 */

if (!function_exists('timeAgo')) {
    function timeAgo($timestamp) {
        if (!$timestamp) return 'N/A';
        
        $time_ago = $timestamp;
        $current_time = time();
        $time_difference = $current_time - $time_ago;
        
        if ($time_difference < 60) {
            return 'Just now';
        } elseif ($time_difference < 3600) {
            $minutes = round($time_difference / 60);
            return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
        } elseif ($time_difference < 86400) {
            $hours = round($time_difference / 3600);
            return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
        } else {
            $days = round($time_difference / 86400);
            return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
        }
    }
}

if (!function_exists('logActivity')) {
    function logActivity($pdo, $action, $section, $description) {
        try {
            // Check if activity_log table exists
            $table_check = $pdo->query("SHOW TABLES LIKE 'activity_log'");
            if ($table_check->rowCount() > 0) {
                $stmt = $pdo->prepare("
                    INSERT INTO activity_log (user_id, action, section, description, ip_address, created_at)
                    VALUES (?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $_SESSION['user_id'] ?? 0,
                    $action,
                    $section,
                    $description,
                    $_SERVER['REMOTE_ADDR'] ?? null
                ]);
            }
        } catch (PDOException $e) {
            error_log("Log activity error: " . $e->getMessage());
        }
    }
}

if (!function_exists('formatMoney')) {
    function formatMoney($amount, $currency = 'KES') {
        return $currency . ' ' . number_format($amount, 2);
    }
}

if (!function_exists('generateRandomPassword')) {
    function generateRandomPassword($length = 10) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+';
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $password .= $chars[random_int(0, strlen($chars) - 1)];
        }
        return $password;
    }
}
?>