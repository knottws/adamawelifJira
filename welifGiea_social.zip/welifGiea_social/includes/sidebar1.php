<?php
// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login if not logged in
    header("Location: login.php");
    exit();
}

// Define timeAgo function if not exists
if (!function_exists('timeAgo')) {
    function timeAgo($timestamp) {
        if (!$timestamp) return 'N/A';
        $time_ago = $timestamp;
        $current_time = time();
        $time_difference = $current_time - $time_ago;
        
        if ($time_difference < 60) return 'Just now';
        if ($time_difference < 3600) return round($time_difference / 60) . 'm ago';
        if ($time_difference < 86400) return round($time_difference / 3600) . 'h ago';
        return round($time_difference / 86400) . 'd ago';
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
$user_role = $_SESSION['user_role'] ?? 'member';
$user_name = $_SESSION['user_name'] ?? $_SESSION['username'] ?? 'User';

// In sidebar.php, update the dashboard mapping
$dashboard_map = [
    'admin' => 'admin_dashboard.php',
    'finance' => 'finance_dashboard.php',
    'registration' => 'registration_dashboard.php',
    'member' => 'member.php' // Changed to member.php
];

// Get the correct dashboard URL based on role
$dashboard_url = $dashboard_map[$user_role] ?? 'member_dashboard.php'; // Default to member dashboard

// Navigation items based on role
$nav_items = [
    'admin' => [
        ['url' => 'user_management.php', 'icon' => 'users', 'label' => 'Users'],
        ['url' => 'roles.php', 'icon' => 'shield', 'label' => 'Roles'],
        ['url' => 'members.php', 'icon' => 'user-plus', 'label' => 'Members'],
        ['url' => 'finances.php', 'icon' => 'dollar-sign', 'label' => 'Finance'],
        ['url' => 'reports.php', 'icon' => 'bar-chart-2', 'label' => 'Reports'],
        ['url' => 'activity_logs.php', 'icon' => 'clock', 'label' => 'Logs'],
        ['url' => 'settings.php', 'icon' => 'settings', 'label' => 'Settings']
    ],
    'finance' => [
        ['url' => 'transactions.php', 'icon' => 'repeat', 'label' => 'Transactions'],
        ['url' => 'add_transaction.php', 'icon' => 'plus-circle', 'label' => 'Add'],
        ['url' => 'reports.php', 'icon' => 'bar-chart-2', 'label' => 'Reports'],
        ['url' => 'budget.php', 'icon' => 'trending-up', 'label' => 'Budget']
    ],
    'registration' => [
        ['url' => 'register_member.php', 'icon' => 'user-plus', 'label' => 'Register'],
        ['url' => 'members.php', 'icon' => 'users', 'label' => 'Members'],
        ['url' => 'applications.php', 'icon' => 'file-text', 'label' => 'Applications'],
        ['url' => 'verification.php', 'icon' => 'check-circle', 'label' => 'Verify']
    ],
    'member' => [
        ['url' => 'profile.php', 'icon' => 'user', 'label' => 'Profile'],
        ['url' => 'my_contributions.php', 'icon' => 'trending-up', 'label' => 'Contributions'],
        ['url' => 'my_loans.php', 'icon' => 'credit-card', 'label' => 'Loans'],
        ['url' => 'statements.php', 'icon' => 'file-text', 'label' => 'Statements']
    ]
];

// Optional: Force redirect if trying to access wrong dashboard
$restricted_pages = [
    'admin' => ['user_management.php', 'roles.php', 'finances.php', 'settings.php'],
    'finance' => ['transactions.php', 'budget.php'],
    'registration' => ['register_member.php', 'applications.php', 'verification.php'],
    'member' => ['profile.php', 'my_contributions.php', 'my_loans.php', 'statements.php']
];

// Check if current page is restricted for this role
if (isset($restricted_pages[$user_role])) {
    $allowed_pages = $restricted_pages[$user_role];
    $allowed_pages[] = $dashboard_url; // Add dashboard to allowed pages
    $allowed_pages[] = 'profile.php'; // Always allow profile
    $allowed_pages[] = 'change_password.php'; // Always allow password change
    $allowed_pages[] = 'notifications.php'; // Always allow notifications
    $allowed_pages[] = 'logout.php'; // Always allow logout
    
    if (!in_array($current_page, $allowed_pages) && $current_page != 'logout.php') {
        // Redirect to appropriate dashboard if trying to access restricted page
        header("Location: " . $dashboard_url);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="sidebar">
        <!-- Logo Area -->
        <div class="logo-area">
            <div class="logo">
                <span class="logo-icon">WS</span>
                <span class="logo-text">Welfare</span>
            </div>
        </div>
        
        <!-- User Info -->
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($user_name, 0, 1)); ?>
            </div>
            <div class="user-details">
                <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                <div class="user-role <?php echo $user_role; ?>"><?php echo ucfirst($user_role); ?></div>
            </div>
        </div>
        
        <!-- Navigation Menu -->
        <div class="nav-menu">
            <div class="nav-section">
                <div class="nav-item">
                    <a href="<?php echo $dashboard_url; ?>" class="<?php echo $current_page == basename($dashboard_url) ? 'active' : ''; ?>">
                        <i class="fas fa-home"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
            </div>
            
            <?php if (isset($nav_items[$user_role])): ?>
                <div class="nav-divider"></div>
                <div class="nav-section">
                    <div class="nav-section-title">Menu</div>
                    <?php foreach ($nav_items[$user_role] as $item): ?>
                        <div class="nav-item">
                            <a href="<?php echo $item['url']; ?>" 
                               class="<?php echo $current_page == $item['url'] ? 'active' : ''; ?>">
                                <i class="fas fa-<?php echo $item['icon']; ?>"></i>
                                <span><?php echo $item['label']; ?></span>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <div class="nav-divider"></div>
            <div class="nav-section">
                <div class="nav-section-title">Account</div>
                <div class="nav-item">
                    <a href="profile.php" class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                        <i class="fas fa-user-circle"></i>
                        <span>Profile</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="change_password.php" class="<?php echo $current_page == 'change_password.php' ? 'active' : ''; ?>">
                        <i class="fas fa-lock"></i>
                        <span>Password</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="notifications.php" class="<?php echo $current_page == 'notifications.php' ? 'active' : ''; ?>">
                        <i class="fas fa-bell"></i>
                        <span>Alerts</span>
                        <?php
                        // You can make this dynamic
                        $notification_count = 3; // Get from database
                        if ($notification_count > 0): ?>
                            <span class="badge"><?php echo $notification_count; ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Bottom Section -->
        <div class="sidebar-bottom">
            <div class="nav-item">
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
            <div class="session-info">
                <i class="fas fa-circle"></i>
                <span>Online</span>
            </div>
        </div>
    </div>
    
    <style>
        /* Add these new styles */
        .nav-section-title {
            padding: 8px 14px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #94a3b8;
            font-weight: 600;
        }
        
        /* Rest of your existing styles remain the same */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8fafc;
        }
        
        .sidebar {
            width: 260px;
            height: 100vh;
            background: #ffffff;
            border-right: 1px solid #f0f0f0;
            position: fixed;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
            box-shadow: 2px 0 20px rgba(0,0,0,0.02);
            z-index: 1000;
        }
        
        /* Add main content margin to account for fixed sidebar */
        .main-content {
            margin-left: 260px;
            padding: 20px;
        }
        
        /* Logo Area */
        .logo-area {
            padding: 24px 20px;
            border-bottom: 1px solid #f8f9fa;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .logo-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, #4361ee, #3a0ca3);
            color: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
        }
        
        .logo-text {
            font-weight: 600;
            font-size: 16px;
            color: #1e293b;
            letter-spacing: 0.5px;
        }
        
        /* User Info */
        .user-info {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 1px solid #f8f9fa;
        }
        
        .user-avatar {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, #4361ee, #3a0ca3);
            color: white;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 18px;
        }
        
        .user-details {
            flex: 1;
        }
        
        .user-name {
            font-weight: 600;
            font-size: 14px;
            color: #1e293b;
            margin-bottom: 4px;
        }
        
        .user-role {
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 20px;
            display: inline-block;
            font-weight: 500;
        }
        
        .user-role.admin { background: #fee2e2; color: #dc2626; }
        .user-role.finance { background: #dcfce7; color: #16a34a; }
        .user-role.registration { background: #fff3cd; color: #d97706; }
        .user-role.member { background: #dbeafe; color: #2563eb; }
        
        /* Navigation Menu */
        .nav-menu {
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .nav-menu::-webkit-scrollbar {
            width: 4px;
        }
        
        .nav-menu::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .nav-menu::-webkit-scrollbar-thumb {
            background: #e2e8f0;
            border-radius: 4px;
        }
        
        .nav-section {
            padding: 0 12px;
        }
        
        .nav-item {
            list-style: none;
            margin: 2px 0;
        }
        
        .nav-item a {
            display: flex;
            align-items: center;
            padding: 10px 14px;
            color: #64748b;
            text-decoration: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            position: relative;
        }
        
        .nav-item a i {
            width: 20px;
            font-size: 16px;
            margin-right: 12px;
            color: #94a3b8;
            transition: all 0.2s ease;
        }
        
        .nav-item a:hover {
            background: #f8fafc;
            color: #4361ee;
        }
        
        .nav-item a:hover i {
            color: #4361ee;
        }
        
        .nav-item a.active {
            background: #f0f4ff;
            color: #4361ee;
        }
        
        .nav-item a.active i {
            color: #4361ee;
        }
        
        .badge {
            background: #ef4444;
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 12px;
            margin-left: auto;
        }
        
        .nav-divider {
            height: 1px;
            background: #f1f5f9;
            margin: 16px 20px;
        }
        
        /* Bottom Section */
        .sidebar-bottom {
            padding: 16px 12px;
            border-top: 1px solid #f1f5f9;
            background: #ffffff;
        }
        
        .session-info {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            font-size: 12px;
            color: #64748b;
        }
        
        .session-info i {
            font-size: 8px;
            color: #10b981;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 72px;
            }
            
            .main-content {
                margin-left: 72px;
            }
            
            .logo-text,
            .user-details,
            .nav-item a span,
            .session-info span,
            .badge,
            .nav-section-title {
                display: none;
            }
            
            .logo-icon {
                margin: 0 auto;
            }
            
            .user-avatar {
                margin: 0 auto;
            }
            
            .nav-item a {
                justify-content: center;
                padding: 12px;
            }
            
            .nav-item a i {
                margin-right: 0;
                font-size: 18px;
            }
            
            .session-info {
                justify-content: center;
            }
            
            .session-info i {
                margin: 0;
            }
        }
        
        /* Dark mode support */
        @media (prefers-color-scheme: dark) {
            .sidebar {
                background: #1e293b;
                border-right-color: #334155;
            }
            
            .logo-text {
                color: #f1f5f9;
            }
            
            .user-name {
                color: #f1f5f9;
            }
            
            .nav-item a {
                color: #94a3b8;
            }
            
            .nav-item a:hover {
                background: #334155;
            }
            
            .nav-divider {
                background: #334155;
            }
            
            .sidebar-bottom {
                background: #1e293b;
                border-top-color: #334155;
            }
            
            .nav-item a.active {
                background: #2d3a4f;
            }
            
            .nav-section-title {
                color: #64748b;
            }
        }
    </style>
    
    <script>
    // Optional: Add active class based on current URL
    document.addEventListener('DOMContentLoaded', function() {
        const currentPath = window.location.pathname.split('/').pop();
        document.querySelectorAll('.nav-item a').forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentPath) {
                link.classList.add('active');
            }
        });
    });
    </script>
</body>
</html>