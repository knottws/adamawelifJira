<?php
// Simple sidebar without RoleAccess dependency
$current_page = basename($_SERVER['PHP_SELF']);
$user_role = $_SESSION['user_role'] ?? '';
?>
<aside class="sidebar" style="width: 280px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; position: fixed; top: 0; left: 0; bottom: 0; overflow-y: auto;">
    <div style="text-align: center; margin-bottom: 40px;">
        <h2 style="color: white; font-size: 20px;"><?php echo SITE_NAME; ?></h2>
        <p style="color: rgba(255,255,255,0.8); font-size: 14px;">Welcome, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?></p>
        <?php if ($user_role): ?>
        <span style="display: inline-block; padding: 4px 12px; border-radius: 20px; background: rgba(255,255,255,0.2); color: white; font-size: 12px; margin-top: 10px;">
            <?php echo ucfirst($user_role); ?>
        </span>
        <?php endif; ?>
    </div>
    
    <ul style="list-style: none; padding: 0;">
        <!-- Dashboard -->
        <li style="margin-bottom: 5px;">
            <a href="dashboard.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'dashboard.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">dashboard</span>
                Dashboard
            </a>
        </li>
        
        <!-- Admin specific -->
        <?php if ($user_role == 'admin'): ?>
        <li style="margin-bottom: 5px;">
            <a href="admin_dashboard.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'admin_dashboard.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">admin_panel_settings</span>
                Admin Dashboard
            </a>
        </li>
        <li style="margin-bottom: 5px;">
            <a href="users.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'users.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">people</span>
                User Management
            </a>
        </li>
        <?php endif; ?>
        
        <!-- Common for admin, registration, finance -->
        <?php if (in_array($user_role, ['admin', 'registration', 'finance'])): ?>
        <li style="margin-bottom: 5px;">
            <a href="members.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'members.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">people</span>
                Members
            </a>
        </li>
        <?php endif; ?>
        
        <!-- Finance and admin -->
        <?php if (in_array($user_role, ['admin', 'finance'])): ?>
        <li style="margin-bottom: 5px;">
            <a href="finances.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'finances.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">account_balance</span>
                Finances
            </a>
        </li>
        <li style="margin-bottom: 5px;">
            <a href="reports.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'reports.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">assessment</span>
                Reports
            </a>
        </li>
        <?php endif; ?>
        
        <!-- Member specific -->
        <?php if ($user_role == 'member'): ?>
        <li style="margin-bottom: 5px;">
            <a href="profile.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'profile.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">person</span>
                My Profile
            </a>
        </li>
        <li style="margin-bottom: 5px;">
            <a href="my_payments.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'my_payments.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">payment</span>
                My Payments
            </a>
        </li>
        <?php endif; ?>
        
        <!-- Common for all -->
        <li style="margin-top: 20px; margin-bottom: 5px;">
            <a href="profile.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px; <?php echo $current_page == 'profile.php' ? 'background: rgba(255,255,255,0.2); color: white;' : ''; ?>">
                <span class="material-icons" style="font-size: 20px;">account_circle</span>
                Profile
            </a>
        </li>
        <li style="margin-bottom: 5px;">
            <a href="logout.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: rgba(255,255,255,0.8); text-decoration: none; border-radius: 10px;">
                <span class="material-icons" style="font-size: 20px;">logout</span>
                Logout
            </a>
        </li>
    </ul>
</aside>

<style>
    .main-content {
        margin-left: 280px;
        padding: 30px;
        min-height: 100vh;
    }
    
    @media (max-width: 768px) {
        .sidebar {
            transform: translateX(-100%);
            transition: transform 0.3s;
        }
        
        .sidebar.active {
            transform: translateX(0);
        }
        
        .main-content {
            margin-left: 0;
        }
    }
</style>