<?php
require_once 'config.php';

echo "<h1>🔧 Updating Database Schema</h1>";

try {
    $pdo = getDB();
    
    // Check if family_members table exists
    $result = $pdo->query("SHOW TABLES LIKE 'family_members'");
    if ($result->rowCount() == 0) {
        echo "<p style='color:orange'>⚠️ family_members table doesn't exist. Creating...</p>";
        
        // Create family_members table with correct schema
        $sql = "CREATE TABLE family_members (
            id INT AUTO_INCREMENT PRIMARY KEY,
            member_id INT NOT NULL,
            family_type ENUM('own_family', 'wife_family') NOT NULL,
            relationship VARCHAR(50) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            age INT,
            occupation VARCHAR(100),
            phone VARCHAR(20),
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
            INDEX idx_member (member_id),
            INDEX idx_family_type (family_type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $pdo->exec($sql);
        echo "<p style='color:green'>✅ family_members table created successfully</p>";
    } else {
        echo "<p>✅ family_members table exists</p>";
        
        // Check if phone column exists
        $result = $pdo->query("SHOW COLUMNS FROM family_members LIKE 'phone'");
        if ($result->rowCount() == 0) {
            echo "<p style='color:orange'>⚠️ 'phone' column missing. Adding it...</p>";
            $pdo->exec("ALTER TABLE family_members ADD COLUMN phone VARCHAR(20) AFTER occupation");
            echo "<p style='color:green'>✅ 'phone' column added successfully</p>";
        } else {
            echo "<p>✅ 'phone' column exists</p>";
        }
        
        // Check other columns
        $columns = [
            'family_type' => "ENUM('own_family', 'wife_family') NOT NULL",
            'relationship' => "VARCHAR(50) NOT NULL",
            'full_name' => "VARCHAR(100) NOT NULL",
            'age' => "INT",
            'occupation' => "VARCHAR(100)",
            'notes' => "TEXT"
        ];
        
        foreach ($columns as $column => $definition) {
            $result = $pdo->query("SHOW COLUMNS FROM family_members LIKE '$column'");
            if ($result->rowCount() == 0) {
                echo "<p style='color:orange'>⚠️ '$column' column missing. Adding it...</p>";
                $pdo->exec("ALTER TABLE family_members ADD COLUMN $column $definition");
                echo "<p style='color:green'>✅ '$column' column added successfully</p>";
            }
        }
    }
    
    // Check members table
    $result = $pdo->query("SHOW TABLES LIKE 'members'");
    if ($result->rowCount() > 0) {
        echo "<p>✅ members table exists</p>";
        
        // Check members table columns
        $columns = [
            'member_number' => "VARCHAR(20) UNIQUE NOT NULL",
            'full_name' => "VARCHAR(100) NOT NULL",
            'phone' => "VARCHAR(20)",
            'email' => "VARCHAR(100)",
            'occupation' => "VARCHAR(100)",
            'address' => "TEXT",
            'registration_date' => "DATE NOT NULL",
            'status' => "ENUM('active', 'inactive') DEFAULT 'active'"
        ];
        
        foreach ($columns as $column => $definition) {
            $result = $pdo->query("SHOW COLUMNS FROM members LIKE '$column'");
            if ($result->rowCount() == 0) {
                echo "<p style='color:orange'>⚠️ '$column' column missing in members table. Adding it...</p>";
                $pdo->exec("ALTER TABLE members ADD COLUMN $column $definition");
                echo "<p style='color:green'>✅ '$column' column added successfully</p>";
            }
        }
    }
    
    echo "<h2 style='color:green'>✅ Database schema update completed!</h2>";
    echo "<p><a href='register_member.php'>Go to Register Member</a></p>";
    
} catch (PDOException $e) {
    echo "<h2 style='color:red'>❌ Error updating schema</h2>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
}
?>