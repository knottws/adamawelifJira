// Smooth scroll to top
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Create back to top button
const backToTop = document.createElement('button');
backToTop.className = 'btn btn-primary btn-icon';
backToTop.innerHTML = '<span class="material-icons">arrow_upward</span>';
backToTop.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    display: none;
    z-index: 999;
    opacity: 0;
    transition: opacity 0.3s;
`;

document.body.appendChild(backToTop);

// Show/hide back to top button
window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
        backToTop.style.display = 'flex';
        setTimeout(() => {
            backToTop.style.opacity = '1';
        }, 10);
    } else {
        backToTop.style.opacity = '0';
        setTimeout(() => {
            backToTop.style.display = 'none';
        }, 300);
    }
});

backToTop.addEventListener('click', scrollToTop);

// Add animation on scroll
const animateOnScroll = function() {
    const elements = document.querySelectorAll('.stat-card, .card, .form-section');
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementBottom = element.getBoundingClientRect().bottom;
        const windowHeight = window.innerHeight;
        
        if (elementTop < windowHeight - 100 && elementBottom > 0) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
};

// Set initial state
document.querySelectorAll('.stat-card, .card, .form-section').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease-out';
});

window.addEventListener('scroll', animateOnScroll);
window.addEventListener('load', animateOnScroll);

// Add loading animations
document.addEventListener('DOMContentLoaded', function() {
    // Add loading spinner to buttons when clicked
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (this.classList.contains('btn-loading')) return;
            
            const originalHtml = this.innerHTML;
            this.classList.add('btn-loading');
            this.innerHTML = '<span class="spinner spinner-sm"></span> Loading...';
            this.disabled = true;
            
            // Revert after action (you'll need to handle this properly)
            setTimeout(() => {
                this.classList.remove('btn-loading');
                this.innerHTML = originalHtml;
                this.disabled = false;
            }, 2000);
        });
    });
});