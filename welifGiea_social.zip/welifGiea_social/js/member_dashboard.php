<?php
// member_dashboard.php
session_start();

// Check if user is logged in and is a member
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'member') {
    header("Location: login.php");
    exit();
}

// Include the sidebar
include 'sidebar.php';

// Page title
$page_title = "Member Dashboard";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Dashboard - Welfare System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8fafc;
        }

        .main-content {
            margin-left: 260px;
            padding: 30px;
        }

        .welcome-section {
            background: linear-gradient(135deg, #4361ee, #3a0ca3);
            color: white;
            padding: 30px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(67, 97, 238, 0.3);
        }

        .welcome-section h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .welcome-section p {
            opacity: 0.9;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid #f0f0f0;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #4361ee, #3a0ca3);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }

        .stat-icon i {
            font-size: 24px;
            color: white;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #64748b;
            font-size: 14px;
        }

        .section-title {
            font-size: 20px;
            color: #1e293b;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: #4361ee;
        }

        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .info-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid #f0f0f0;
        }

        .info-card h3 {
            color: #1e293b;
            margin-bottom: 15px;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-card h3 i {
            color: #4361ee;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #64748b;
            font-size: 14px;
        }

        .info-value {
            color: #1e293b;
            font-weight: 500;
            font-size: 14px;
        }

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .action-btn {
            background: white;
            border: 1px solid #f0f0f0;
            padding: 15px;
            border-radius: 12px;
            text-align: center;
            text-decoration: none;
            color: #1e293b;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        .action-btn:hover {
            background: #f8fafc;
            border-color: #4361ee;
            transform: translateY(-2px);
        }

        .action-btn i {
            font-size: 24px;
            color: #4361ee;
        }

        .action-btn span {
            font-size: 14px;
            font-weight: 500;
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 72px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Include sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h1>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name'] ?? $_SESSION['username'] ?? 'Member'); ?>! 👋</h1>
            <p>Here's what's happening with your account today</p>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-wallet"></i>
                </div>
                <div class="stat-value">KSh 25,000</div>
                <div class="stat-label">Total Contributions</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <div class="stat-value">KSh 10,000</div>
                <div class="stat-label">Available Loan</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="stat-value">95%</div>
                <div class="stat-label">Attendance Rate</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-gift"></i>
                </div>
                <div class="stat-value">3</div>
                <div class="stat-label">Welfare Benefits</div>
            </div>
        </div>

        <!-- Account Information -->
        <h2 class="section-title">
            <i class="fas fa-user-circle"></i>
            Account Information
        </h2>

        <div class="cards-grid">
            <!-- Member Details -->
            <div class="info-card">
                <h3><i class="fas fa-id-card"></i> Member Details</h3>
                <div class="info-item">
                    <span class="info-label">Member ID</span>
                    <span class="info-value">MEM-2024-001</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Full Name</span>
                    <span class="info-value"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'John Doe'); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Member Since</span>
                    <span class="info-value">Jan 2024</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Status</span>
                    <span class="info-value" style="color: #10b981;">Active</span>
                </div>
            </div>

            <!-- Contribution Summary -->
            <div class="info-card">
                <h3><i class="fas fa-chart-line"></i> Contribution Summary</h3>
                <div class="info-item">
                    <span class="info-label">Monthly Contribution</span>
                    <span class="info-value">KSh 500</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Last Payment</span>
                    <span class="info-value">Mar 15, 2024</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Next Due</span>
                    <span class="info-value">Apr 5, 2024</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Payment Method</span>
                    <span class="info-value">M-PESA</span>
                </div>
            </div>

            <!-- Loan Information -->
            <div class="info-card">
                <h3><i class="fas fa-credit-card"></i> Loan Information</h3>
                <div class="info-item">
                    <span class="info-label">Active Loans</span>
                    <span class="info-value">1</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Loan Balance</span>
                    <span class="info-value">KSh 5,000</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Monthly Installment</span>
                    <span class="info-value">KSh 500</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Next Payment</span>
                    <span class="info-value">Apr 10, 2024</span>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <h2 class="section-title">
            <i class="fas fa-bolt"></i>
            Quick Actions
        </h2>

        <div class="quick-actions">
            <a href="make_contribution.php" class="action-btn">
                <i class="fas fa-plus-circle"></i>
                <span>Make Contribution</span>
            </a>
            <a href="apply_loan.php" class="action-btn">
                <i class="fas fa-hand-holding-usd"></i>
                <span>Apply for Loan</span>
            </a>
            <a href="view_statements.php" class="action-btn">
                <i class="fas fa-file-invoice"></i>
                <span>View Statements</span>
            </a>
            <a href="update_profile.php" class="action-btn">
                <i class="fas fa-user-edit"></i>
                <span>Update Profile</span>
            </a>
        </div>

        <!-- Recent Activity -->
        <h2 class="section-title" style="margin-top: 30px;">
            <i class="fas fa-history"></i>
            Recent Activity
        </h2>

        <div class="info-card">
            <div class="info-item">
                <span class="info-label">Mar 15, 2024</span>
                <span class="info-value">Contribution of KSh 500 received</span>
            </div>
            <div class="info-item">
                <span class="info-label">Mar 10, 2024</span>
                <span class="info-value">Loan installment of KSh 500 paid</span>
            </div>
            <div class="info-item">
                <span class="info-label">Mar 5, 2024</span>
                <span class="info-value">Welfare meeting attended</span>
            </div>
            <div class="info-item">
                <span class="info-label">Feb 28, 2024</span>
                <span class="info-value">Profile updated successfully</span>
            </div>
        </div>
    </div>
</body>
</html>