<?php
$current_page = basename($_SERVER['PHP_SELF']);
$role = $_SESSION['user_role'];
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <h2><?php echo SITE_NAME; ?></h2>
        <p>Welcome, <?php echo $_SESSION['user_name']; ?></p>
    </div>
    
    <ul class="sidebar-nav">
        <li>
            <a href="dashboard.php" class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <span class="material-icons">dashboard</span>
                Dashboard
            </a>
        </li>
        
        <?php if (in_array($role, ['admin', 'registration', 'finance'])): ?>
        <li>
            <a href="members.php" class="<?php echo $current_page == 'members.php' ? 'active' : ''; ?>">
                <span class="material-icons">people</span>
                Members
            </a>
        </li>
        <?php endif; ?>
        
        <?php if (in_array($role, ['admin', 'finance'])): ?>
        <li>
            <a href="finances.php" class="<?php echo $current_page == 'finances.php' ? 'active' : ''; ?>">
                <span class="material-icons">account_balance</span>
                Finances
            </a>
        </li>
        <li>
            <a href="reports.php" class="<?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                <span class="material-icons">assessment</span>
                Reports
            </a>
        </li>
        <?php endif; ?>
        
        <?php if ($role == 'admin'): ?>
        <li>
            <a href="users.php" class="<?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
                <span class="material-icons">admin_panel_settings</span>
                User Management
            </a>
        </li>
        <?php endif; ?>
        
        <?php if ($role == 'member'): ?>
        <li>
            <a href="profile.php" class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                <span class="material-icons">person</span>
                My Profile
            </a>
        </li>
        <li>
            <a href="my_payments.php" class="<?php echo $current_page == 'my_payments.php' ? 'active' : ''; ?>">
                <span class="material-icons">payment</span>
                My Payments
            </a>
        </li>
        <?php endif; ?>
        
        <li>
            <a href="logout.php">
                <span class="material-icons">logout</span>
                Logout
            </a>
        </li>
    </ul>
</aside>