// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function() {
    // Create mobile menu toggle button
    const menuToggle = document.createElement('div');
    menuToggle.className = 'menu-toggle';
    menuToggle.innerHTML = '<span class="material-icons">menu</span>';
    menuToggle.style.display = 'none';
    document.body.appendChild(menuToggle);
    
    // Toggle sidebar on mobile
    menuToggle.addEventListener('click', function() {
        document.querySelector('.sidebar').classList.toggle('active');
        menuToggle.innerHTML = document.querySelector('.sidebar').classList.contains('active') 
            ? '<span class="material-icons">close</span>' 
            : '<span class="material-icons">menu</span>';
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        const sidebar = document.querySelector('.sidebar');
        const isMobile = window.innerWidth <= 1024;
        
        if (isMobile && sidebar.classList.contains('active') && 
            !sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
            sidebar.classList.remove('active');
            menuToggle.innerHTML = '<span class="material-icons">menu</span>';
        }
    });
    
    // Handle window resize
    window.addEventListener('resize', function() {
        const sidebar = document.querySelector('.sidebar');
        const isMobile = window.innerWidth <= 1024;
        
        if (!isMobile) {
            sidebar.classList.remove('active');
            menuToggle.style.display = 'none';
        } else {
            menuToggle.style.display = 'flex';
        }
    });
    
    // Trigger resize on load
    window.dispatchEvent(new Event('resize'));
});