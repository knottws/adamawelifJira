// Make tables responsive on mobile
function makeTablesResponsive() {
    const tables = document.querySelectorAll('.data-table');
    
    tables.forEach(table => {
        // Get headers
        const headers = [];
        table.querySelectorAll('thead th').forEach(th => {
            headers.push(th.textContent.trim());
        });
        
        // Add data-label attributes to cells
        table.querySelectorAll('tbody tr').forEach(row => {
            row.querySelectorAll('td').forEach((td, index) => {
                if (headers[index]) {
                    td.setAttribute('data-label', headers[index]);
                }
            });
        });
    });
}

// Run on load
document.addEventListener('DOMContentLoaded', makeTablesResponsive);

// Run after AJAX content loads
document.addEventListener('contentLoaded', makeTablesResponsive);