<?php
require_once 'config.php';
requireLogin(['admin', 'finance']);

$year = $_GET['year'] ?? date('Y');

// Get budget summary
$budgetSummary = $pdo->prepare("
    SELECT 
        COUNT(*) as total_categories,
        SUM(allocated_amount) as total_budget,
        SUM(spent_amount) as total_spent,
        SUM(remaining_amount) as total_remaining
    FROM budgets
    WHERE budget_year = ?
");
$budgetSummary->execute([$year]);
$summary = $budgetSummary->fetch();

// Get category budgets
$categoryBudgets = $pdo->prepare("
    SELECT 
        ec.*,
        b.allocated_amount,
        b.spent_amount,
        b.remaining_amount,
        b.budget_month
    FROM expense_categories ec
    LEFT JOIN budgets b ON ec.id = b.category_id AND b.budget_year = ? AND b.budget_month IS NULL
    WHERE ec.is_active = 1
    ORDER BY ec.category_name
");
$categoryBudgets->execute([$year]);
$budgets = $categoryBudgets->fetchAll();

// Handle budget update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_budget'])) {
    foreach ($_POST['budget'] as $categoryId => $amount) {
        // Check if budget exists
        $stmt = $pdo->prepare("SELECT id FROM budgets WHERE category_id = ? AND budget_year = ? AND budget_month IS NULL");
        $stmt->execute([$categoryId, $year]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            $stmt = $pdo->prepare("UPDATE budgets SET allocated_amount = ? WHERE id = ?");
            $stmt->execute([$amount, $existing['id']]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO budgets (category_id, budget_year, allocated_amount, created_by)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$categoryId, $year, $amount, $_SESSION['user_id']]);
        }
    }
    
    $success = "Budget updated successfully!";
    header("Refresh:0");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Planning - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="expense-header">
                <h1>Budget Planning - <?php echo $year; ?></h1>
                <div style="display: flex; gap: 10px;">
                    <button class="btn btn-secondary" onclick="changeYear(-1)">← Previous Year</button>
                    <button class="btn btn-secondary" onclick="changeYear(1)">Next Year →</button>
                </div>
            </div>
            
            <!-- Budget Summary -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 25px;">
                <div style="background: white; border-radius: 15px; padding: 20px;">
                    <div style="color: #666;">Total Budget</div>
                    <div style="font-size: 36px; font-weight: 700;">ETB <?php echo number_format($summary['total_budget'] ?? 0, 2); ?></div>
                </div>
                
                <div style="background: white; border-radius: 15px; padding: 20px;">
                    <div style="color: #666;">Spent to Date</div>
                    <div style="font-size: 36px; font-weight: 700; color: #f57c00;">
                        ETB <?php echo number_format($summary['total_spent'] ?? 0, 2); ?>
                    </div>
                </div>
                
                <div style="background: white; border-radius: 15px; padding: 20px;">
                    <div style="color: #666;">Remaining</div>
                    <div style="font-size: 36px; font-weight: 700; color: #4CAF50;">
                        ETB <?php echo number_format($summary['total_remaining'] ?? 0, 2); ?>
                    </div>
                </div>
            </div>
            
            <!-- Budget Form -->
            <form method="POST" action="" style="background: white; border-radius: 15px; padding: 25px;">
                <h3 style="margin-bottom: 20px;">Category Budgets</h3>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Code</th>
                            <th>Annual Budget (ETB)</th>
                            <th>Spent to Date</th>
                            <th>Remaining</th>
                            <th>Utilization</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($budgets as $budget): 
                            $spent = $budget['spent_amount'] ?? 0;
                            $allocated = $budget['allocated_amount'] ?? 0;
                            $remaining = $allocated - $spent;
                            $utilization = $allocated > 0 ? ($spent / $allocated) * 100 : 0;
                        ?>
                        <tr>
                            <td><strong><?php echo $budget['category_name']; ?></strong></td>
                            <td><?php echo $budget['category_code']; ?></td>
                            <td>
                                <input type="number" name="budget[<?php echo $budget['id']; ?>]" 
                                       value="<?php echo $allocated; ?>" step="0.01" min="0"
                                       style="width: 150px; padding: 8px; border: 1px solid #e0e0e0; border-radius: 5px;">
                            </td>
                            <td>ETB <?php echo number_format($spent, 2); ?></td>
                            <td style="color: <?php echo $remaining >= 0 ? '#4CAF50' : '#f44336'; ?>;">
                                ETB <?php echo number_format($remaining, 2); ?>
                            </td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <span><?php echo number_format($utilization, 1); ?>%</span>
                                    <div class="progress-bar" style="width: 100px;">
                                        <div class="progress-fill" style="width: <?php echo $utilization; ?>%; 
                                            background: <?php echo $utilization > 90 ? '#f44336' : ($utilization > 70 ? '#FF9800' : '#4CAF50'); ?>;">
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="form-actions" style="margin-top: 20px;">
                    <button type="submit" name="update_budget" class="btn btn-primary">
                        <span class="material-icons">save</span> Save Budget
                    </button>
                </div>
            </form>
        </main>
    </div>
    
    <script>
        function changeYear(delta) {
            let year = <?php echo $year; ?>;
            year += delta;
            window.location.href = `budget_planning.php?year=${year}`;
        }
    </script>
</body>
</html>