<?php
require_once 'login.php';

// Handle email verification
if (isset($_GET['token'])) {
    $userManager = new UserManagement();
    $result = $userManager->verifyEmail($_GET['token']);
    
    // Redirect to login page with message
    if ($result['success']) {
        header('Location: login.php?verified=1');
    } else {
        header('Location: login.php?verification_failed=1');
    }
    exit;
}
?>