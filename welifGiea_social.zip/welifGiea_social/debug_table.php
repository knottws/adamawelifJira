<?php
// debug_table.php

try {
    // Your database connection
    $pdo = new PDO("mysql:host=localhost;dbname=your_database", "username", "password");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $table_name = 'users'; // Change to your actual table name
    
    echo "<h2>Debugging Table: " . htmlspecialchars($table_name) . "</h2>";
    
    // Check if table exists
    $table_check = $pdo->query("SHOW TABLES LIKE '$table_name'");
    if ($table_check->rowCount() == 0) {
        die("Table '$table_name' does not exist in the database!");
    }
    
    // Get table structure
    $query = "DESCRIBE " . $table_name;
    $stmt = $pdo->query($query);
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Table Structure:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($column['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($column['Extra']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check specifically for address column
    $address_exists = false;
    foreach ($columns as $column) {
        if ($column['Field'] == 'address') {
            $address_exists = true;
            break;
        }
    }
    
    echo "<h3>Address Column Check:</h3>";
    if ($address_exists) {
        echo "<p style='color: green;'>✓ The 'address' column EXISTS in the table.</p>";
    } else {
        echo "<p style='color: red;'>✗ The 'address' column DOES NOT EXIST in the table.</p>";
        echo "<p>To add it, run this SQL:</p>";
        echo "<pre>ALTER TABLE " . $table_name . " ADD COLUMN address VARCHAR(255) NULL AFTER email;</pre>";
    }
    
} catch (PDOException $e) {
    echo "<h3>Error:</h3>";
    echo "<p style='color: red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    
    // Additional debug info
    echo "<h4>Debug Information:</h4>";
    echo "<ul>";
    echo "<li>Error Code: " . $e->getCode() . "</li>";
    echo "<li>File: " . $e->getFile() . "</li>";
    echo "<li>Line: " . $e->getLine() . "</li>";
    echo "</ul>";
}
?>