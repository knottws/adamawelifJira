<?php
require_once 'config.php';
requireLogin(['admin', 'finance']);

$year = $_GET['year'] ?? date('Y');
$quarter = $_GET['quarter'] ?? null;

// Get monthly expense summary
$monthlyExpenses = $pdo->prepare("
    SELECT 
        MONTH(expense_date) as month,
        COUNT(*) as expense_count,
        SUM(amount) as total_amount,
        AVG(amount) as average_amount,
        MIN(amount) as min_amount,
        MAX(amount) as max_amount
    FROM expenses
    WHERE YEAR(expense_date) = ? AND status IN ('approved', 'paid')
    GROUP BY MONTH(expense_date)
    ORDER BY month
");
$monthlyExpenses->execute([$year]);
$monthly = $monthlyExpenses->fetchAll();

// Get top expense categories
$topCategories = $pdo->prepare("
    SELECT 
        ec.category_name,
        COUNT(e.id) as expense_count,
        SUM(e.amount) as total_amount,
        AVG(e.amount) as avg_amount
    FROM expenses e
    JOIN expense_categories ec ON e.category_id = ec.id
    WHERE YEAR(e.expense_date) = ? AND e.status IN ('approved', 'paid')
    GROUP BY ec.id
    ORDER BY total_amount DESC
    LIMIT 10
");
$topCategories->execute([$year]);
$topCats = $topCategories->fetchAll();

// Get largest expenses
$largestExpenses = $pdo->prepare("
    SELECT 
        e.*,
        ec.category_name
    FROM expenses e
    JOIN expense_categories ec ON e.category_id = ec.id
    WHERE YEAR(e.expense_date) = ? AND e.status IN ('approved', 'paid')
    ORDER BY e.amount DESC
    LIMIT 10
");
$largestExpenses->execute([$year]);
$largest = $largestExpenses->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Report - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="expense-header">
                <h1>Expense Report - <?php echo $year; ?></h1>
                <div>
                    <button class="btn btn-primary" onclick="exportReport()">
                        <span class="material-icons">download</span> Export PDF
                    </button>
                </div>
            </div>
            
            <!-- Monthly Chart -->
            <div style="background: white; border-radius: 15px; padding: 20px; margin-bottom: 25px; height: 300px;">
                <canvas id="monthlyChart"></canvas>
            </div>
            
            <!-- Top Categories -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
                <div style="background: white; border-radius: 15px; padding: 20px;">
                    <h3 style="margin-bottom: 15px;">Top Expense Categories</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Count</th>
                                <th>Total</th>
                                <th>Average</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topCats as $cat): ?>
                            <tr>
                                <td><?php echo $cat['category_name']; ?></td>
                                <td><?php echo $cat['expense_count']; ?></td>
                                <td>ETB <?php echo number_format($cat['total_amount'], 2); ?></td>
                                <td>ETB <?php echo number_format($cat['avg_amount'], 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Largest Expenses -->
                <div style="background: white; border-radius: 15px; padding: 20px;">
                    <h3 style="margin-bottom: 15px;">Largest Expenses</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Category</th>
                                <th>Description</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($largest as $expense): ?>
                            <tr>
                                <td><?php echo date('M j', strtotime($expense['expense_date'])); ?></td>
                                <td><?php echo $expense['category_name']; ?></td>
                                <td><?php echo substr($expense['description'], 0, 30); ?>...</td>
                                <td><strong>ETB <?php echo number_format($expense['amount'], 2); ?></strong></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        const ctx = document.getElementById('monthlyChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($monthly, 'month')); ?>,
                datasets: [{
                    label: 'Monthly Expenses',
                    data: <?php echo json_encode(array_column($monthly, 'total_amount')); ?>,
                    backgroundColor: 'rgba(102, 126, 234, 0.5)',
                    borderColor: '#667eea',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'ETB ' + value;
                            }
                        }
                    }
                }
            }
        });
        
        function exportReport() {
            window.location.href = 'export_expense_report.php?year=<?php echo $year; ?>';
        }
    </script>
</body>
</html>