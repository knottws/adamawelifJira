<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/config.php';

// Check if user is logged in and has admin access
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Initialize variables
$message = '';
$error = '';
$users = [];
$roles = [];
$search_term = $_GET['search'] ?? '';
$role_filter = $_GET['role'] ?? '';
$status_filter = $_GET['status'] ?? '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

try {
    // Get all roles for filter
    $roles_stmt = $pdo->query("SELECT * FROM roles ORDER BY role_name");
    $roles = $roles_stmt->fetchAll();
    
    // Build query with filters
    $sql = "SELECT u.*, r.role_name, r.role_description 
            FROM users u 
            LEFT JOIN roles r ON u.role = r.role_code 
            WHERE 1=1";
    $count_sql = "SELECT COUNT(*) FROM users u WHERE 1=1";
    $params = [];
    
    if (!empty($search_term)) {
        $sql .= " AND (u.username LIKE :search OR u.email LIKE :search OR u.full_name LIKE :search OR u.phone LIKE :search)";
        $count_sql .= " AND (username LIKE :search OR email LIKE :search OR full_name LIKE :search OR phone LIKE :search)";
        $params[':search'] = "%$search_term%";
    }
    
    if (!empty($role_filter)) {
        $sql .= " AND u.role = :role";
        $count_sql .= " AND role = :role";
        $params[':role'] = $role_filter;
    }
    
    if (!empty($status_filter)) {
        if ($status_filter === 'active') {
            $sql .= " AND u.is_active = 1 AND u.is_locked = 0";
            $count_sql .= " AND is_active = 1 AND is_locked = 0";
        } elseif ($status_filter === 'inactive') {
            $sql .= " AND u.is_active = 0";
            $count_sql .= " AND is_active = 0";
        } elseif ($status_filter === 'locked') {
            $sql .= " AND u.is_locked = 1";
            $count_sql .= " AND is_locked = 1";
        }
    }
    
    // Get total count for pagination
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_users = $count_stmt->fetchColumn();
    $total_pages = ceil($total_users / $limit);
    
    // Add pagination
    $sql .= " ORDER BY u.created_at DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $pdo->prepare($sql);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $users = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    error_log("User management error: " . $e->getMessage());
}

// Handle actions (activate, deactivate, lock, unlock, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        $user_id = $_POST['user_id'] ?? 0;
        $action = $_POST['action'];
        
        switch ($action) {
            case 'activate':
                $stmt = $pdo->prepare("UPDATE users SET is_active = 1, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$user_id]);
                $message = "User activated successfully.";
                break;
                
            case 'deactivate':
                $stmt = $pdo->prepare("UPDATE users SET is_active = 0, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$user_id]);
                $message = "User deactivated successfully.";
                break;
                
            case 'lock':
                $stmt = $pdo->prepare("UPDATE users SET is_locked = 1, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$user_id]);
                $message = "User locked successfully.";
                break;
                
            case 'unlock':
                $stmt = $pdo->prepare("UPDATE users SET is_locked = 0, login_attempts = 0, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$user_id]);
                $message = "User unlocked successfully.";
                break;
                
            case 'reset_password':
                $temp_password = bin2hex(random_bytes(4)); // 8 character temporary password
                $hashed_password = password_hash($temp_password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$hashed_password, $user_id]);
                
                // Get user email
                $user_stmt = $pdo->prepare("SELECT email, username FROM users WHERE id = ?");
                $user_stmt->execute([$user_id]);
                $user = $user_stmt->fetch();
                
                // Here you would send email with temporary password
                $message = "Password reset successfully. Temporary password: " . $temp_password . " (In production, email this)";
                break;
                
            case 'delete':
                // Check if user has transactions before deleting
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE user_id = ?");
                $check_stmt->execute([$user_id]);
                $count = $check_stmt->fetchColumn();
                
                if ($count > 0) {
                    // Soft delete - just deactivate
                    $stmt = $pdo->prepare("UPDATE users SET is_active = 0, deleted_at = NOW() WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $message = "User has transactions and was deactivated instead of deleted.";
                } else {
                    // Hard delete
                    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $message = "User deleted successfully.";
                }
                break;
        }
        
        // Refresh the page to show updated data
        header("Location: user_management.php?" . $_SERVER['QUERY_STRING'] . "&message=" . urlencode($message));
        exit();
        
    } catch (PDOException $e) {
        $error = "Error performing action: " . $e->getMessage();
    }
}

// Get message from redirect
if (isset($_GET['message'])) {
    $message = $_GET['message'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - <?php echo SITE_NAME; ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container-fluid {
            padding: 20px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 20px;
        }
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        .card-header h3 {
            margin: 0;
            font-size: 1.5rem;
        }
        .table th {
            border-top: none;
            background: #f8f9fa;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: 500;
        }
        .badge-admin { background: #f44336; color: white; }
        .badge-finance { background: #4CAF50; color: white; }
        .badge-registration { background: #FF9800; color: white; }
        .badge-member { background: #2196F3; color: white; }
        .badge-active { background: #28a745; color: white; }
        .badge-inactive { background: #6c757d; color: white; }
        .badge-locked { background: #dc3545; color: white; }
        .action-btn {
            padding: 5px 10px;
            margin: 2px;
            border-radius: 5px;
            color: white;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .btn-edit { background: #007bff; }
        .btn-activate { background: #28a745; }
        .btn-deactivate { background: #ffc107; color: #212529; }
        .btn-lock { background: #dc3545; }
        .btn-unlock { background: #17a2b8; }
        .btn-reset { background: #6c757d; }
        .btn-delete { background: #dc3545; }
        .filter-section {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .search-box {
            position: relative;
        }
        .search-box i {
            position: absolute;
            right: 15px;
            top: 10px;
            color: #6c757d;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card .stat-icon {
            font-size: 2.5rem;
            color: #667eea;
        }
        .stat-card .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: #333;
        }
        .stat-card .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .modal-content {
            border-radius: 10px;
        }
        .modal-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px 10px 0 0;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white rounded mb-4 shadow-sm">
            <div class="container-fluid">
                <span class="navbar-brand">
                    <i class="material-icons" style="vertical-align: middle;">people</i>
                    User Management
                </span>
                <div class="navbar-nav ml-auto">
                    <span class="nav-item nav-link">
                        <i class="material-icons" style="vertical-align: middle;">person</i>
                        <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?>
                    </span>
                    <a href="admin_dashboard.php" class="nav-link">
                        <i class="material-icons" style="vertical-align: middle;">dashboard</i>
                        Dashboard
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Statistics Cards -->
        <div class="row">
            <?php
            try {
                // Get user statistics
                $stats_sql = "SELECT 
                                COUNT(*) as total_users,
                                SUM(CASE WHEN is_active = 1 AND is_locked = 0 THEN 1 ELSE 0 END) as active_users,
                                SUM(CASE WHEN is_active = 0 THEN 1 ELSE 0 END) as inactive_users,
                                SUM(CASE WHEN is_locked = 1 THEN 1 ELSE 0 END) as locked_users,
                                SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as new_today
                              FROM users";
                $stats = $pdo->query($stats_sql)->fetch();
            } catch (PDOException $e) {
                $stats = ['total_users' => 0, 'active_users' => 0, 'inactive_users' => 0, 'locked_users' => 0, 'new_today' => 0];
            }
            ?>
            <div class="col-md-2">
                <div class="stat-card text-center">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value"><?php echo number_format($stats['total_users']); ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card text-center">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value"><?php echo number_format($stats['active_users']); ?></div>
                    <div class="stat-label">Active</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card text-center">
                    <div class="stat-icon">❌</div>
                    <div class="stat-value"><?php echo number_format($stats['inactive_users']); ?></div>
                    <div class="stat-label">Inactive</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card text-center">
                    <div class="stat-icon">🔒</div>
                    <div class="stat-value"><?php echo number_format($stats['locked_users']); ?></div>
                    <div class="stat-label">Locked</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card text-center">
                    <div class="stat-icon">🆕</div>
                    <div class="stat-value"><?php echo number_format($stats['new_today']); ?></div>
                    <div class="stat-label">New Today</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card text-center">
                    <div class="stat-icon">📊</div>
                    <div class="stat-value"><?php echo $stats['total_users'] > 0 ? round(($stats['active_users'] / $stats['total_users']) * 100) : 0; ?>%</div>
                    <div class="stat-label">Active Rate</div>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <?php if ($message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="material-icons" style="vertical-align: middle;">check_circle</i>
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="material-icons" style="vertical-align: middle;">error</i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" action="" class="form-row align-items-end">
                <div class="form-group col-md-4">
                    <label>Search</label>
                    <div class="search-box">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by name, email, username..." 
                               value="<?php echo htmlspecialchars($search_term); ?>">
                        <i class="material-icons">search</i>
                    </div>
                </div>
                
                <div class="form-group col-md-2">
                    <label>Role</label>
                    <select name="role" class="form-control">
                        <option value="">All Roles</option>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role['role_code']; ?>" 
                                <?php echo $role_filter == $role['role_code'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($role['role_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group col-md-2">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="">All Status</option>
                        <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        <option value="locked" <?php echo $status_filter == 'locked' ? 'selected' : ''; ?>>Locked</option>
                    </select>
                </div>
                
                <div class="form-group col-md-2">
                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="material-icons" style="vertical-align: middle;">filter_list</i> Apply Filters
                    </button>
                </div>
                
                <div class="form-group col-md-2">
                    <a href="add_user.php" class="btn btn-success btn-block">
                        <i class="material-icons" style="vertical-align: middle;">person_add</i> Add New User
                    </a>
                </div>
            </form>
        </div>
        
        <!-- Users Table -->
        <div class="card">
            <div class="card-header">
                <h3><i class="material-icons" style="vertical-align: middle;">list</i> System Users</h3>
            </div>
            <div class="card-body">
                <?php if (empty($users)): ?>
                    <div class="alert alert-info">
                        <i class="material-icons" style="vertical-align: middle;">info</i>
                        No users found matching your criteria.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="usersTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Last Login</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['full_name'] ?? 'N/A'); ?></td>
                                    <td>
                                        <a href="mailto:<?php echo htmlspecialchars($user['email']); ?>">
                                            <?php echo htmlspecialchars($user['email']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo strtolower($user['role']); ?>">
                                            <?php echo htmlspecialchars($user['role_name'] ?? $user['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user['is_locked']): ?>
                                            <span class="badge badge-locked">Locked</span>
                                        <?php elseif (!$user['is_active']): ?>
                                            <span class="badge badge-inactive">Inactive</span>
                                        <?php else: ?>
                                            <span class="badge badge-active">Active</span>
                                        <?php endif; ?>
                                        
                                        <?php if ($user['login_attempts'] >= MAX_LOGIN_ATTEMPTS): ?>
                                            <br><small class="text-danger">Max attempts reached</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        if ($user['last_login']) {
                                            echo date('d/m/Y H:i', strtotime($user['last_login']));
                                        } else {
                                            echo 'Never';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-info dropdown-toggle" 
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Actions
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="edit_user.php?id=<?php echo $user['id']; ?>">
                                                    <i class="material-icons" style="font-size: 18px; vertical-align: middle;">edit</i> Edit
                                                </a>
                                                
                                                <?php if (!$user['is_active']): ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                        <input type="hidden" name="action" value="activate">
                                                        <button type="submit" class="dropdown-item" 
                                                                onclick="return confirm('Activate this user?')">
                                                            <i class="material-icons" style="font-size: 18px; vertical-align: middle;">check_circle</i> Activate
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                        <input type="hidden" name="action" value="deactivate">
                                                        <button type="submit" class="dropdown-item" 
                                                                onclick="return confirm('Deactivate this user?')">
                                                            <i class="material-icons" style="font-size: 18px; vertical-align: middle;">block</i> Deactivate
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                
                                                <?php if ($user['is_locked']): ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                        <input type="hidden" name="action" value="unlock">
                                                        <button type="submit" class="dropdown-item" 
                                                                onclick="return confirm('Unlock this user?')">
                                                            <i class="material-icons" style="font-size: 18px; vertical-align: middle;">lock_open</i> Unlock
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                        <input type="hidden" name="action" value="lock">
                                                        <button type="submit" class="dropdown-item" 
                                                                onclick="return confirm('Lock this user?')">
                                                            <i class="material-icons" style="font-size: 18px; vertical-align: middle;">lock</i> Lock
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <input type="hidden" name="action" value="reset_password">
                                                    <button type="submit" class="dropdown-item" 
                                                            onclick="return confirm('Reset password for this user?')">
                                                        <i class="material-icons" style="font-size: 18px; vertical-align: middle;">vpn_key</i> Reset Password
                                                    </button>
                                                </form>
                                                
                                                <div class="dropdown-divider"></div>
                                                
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <button type="submit" class="dropdown-item text-danger" 
                                                            onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.')">
                                                        <i class="material-icons" style="font-size: 18px; vertical-align: middle;">delete</i> Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search_term); ?>&role=<?php echo $role_filter; ?>&status=<?php echo $status_filter; ?>">
                                        Previous
                                    </a>
                                </li>
                                
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search_term); ?>&role=<?php echo $role_filter; ?>&status=<?php echo $status_filter; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                                
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search_term); ?>&role=<?php echo $role_filter; ?>&status=<?php echo $status_filter; ?>">
                                        Next
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                    
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <p>Showing <?php echo count($users); ?> of <?php echo $total_users; ?> users</p>
                        </div>
                        <div class="col-md-6 text-right">
                            <button class="btn btn-secondary" onclick="exportTableToCSV()">
                                <i class="material-icons" style="vertical-align: middle;">download</i> Export to CSV
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUserModalLabel">
                        <i class="material-icons" style="vertical-align: middle;">person_add</i> Add New User
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="process_user.php" method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Username *</label>
                                    <input type="text" name="username" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Full Name *</label>
                                    <input type="text" name="full_name" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email *</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input type="text" name="phone" class="form-control">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Password *</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Confirm Password *</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Role *</label>
                                    <select name="role" class="form-control" required>
                                        <option value="">Select Role</option>
                                        <?php foreach ($roles as $role): ?>
                                            <option value="<?php echo $role['role_code']; ?>">
                                                <?php echo htmlspecialchars($role['role_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status" class="form-control">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_user" class="btn btn-primary">Add User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Initialize DataTable
        $('#usersTable').DataTable({
            "paging": false,
            "searching": false,
            "info": false,
            "ordering": true
        });
    });
    
    // Export to CSV function
    function exportTableToCSV() {
        var csv = [];
        var rows = document.querySelectorAll("#usersTable tr");
        
        for (var i = 0; i < rows.length; i++) {
            var row = [], cols = rows[i].querySelectorAll("td, th");
            
            for (var j = 0; j < cols.length - 1; j++) { // Exclude last column (actions)
                var data = cols[j].innerText.replace(/,/g, ' '); // Remove commas
                row.push('"' + data + '"');
            }
            
            csv.push(row.join(','));
        }
        
        // Download CSV
        var csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
        var downloadLink = document.createElement('a');
        downloadLink.download = 'users_export.csv';
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = 'none';
        document.body.appendChild(downloadLink);
        downloadLink.click();
    }
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    </script>
</body>
</html>