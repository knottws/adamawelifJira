<?php
require_once 'config.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Installation</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        .success { color: green; padding: 10px; background: #e8f5e8; border-radius: 5px; margin: 5px 0; }
        .error { color: red; padding: 10px; background: #ffe8e8; border-radius: 5px; margin: 5px 0; }
        .info { color: blue; padding: 10px; background: #e8e8ff; border-radius: 5px; margin: 5px 0; }
        h1 { color: #333; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🔧 WelifGiea Database Installation</h1>";

try {
    $pdo = getDB();
    
    // Get current database name
    $stmt = $pdo->query("SELECT DATABASE()");
    $dbname = $stmt->fetchColumn();
    echo "<div class='info'>📊 Connected to database: <strong>" . $dbname . "</strong></div>";
    
    // Array of SQL statements to create tables
    $tables = [
        "members" => "
            CREATE TABLE IF NOT EXISTS members (
                id INT AUTO_INCREMENT PRIMARY KEY,
                member_number VARCHAR(20) UNIQUE NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                phone VARCHAR(20),
                email VARCHAR(100),
                occupation VARCHAR(100),
                address TEXT,
                registration_date DATE NOT NULL,
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_member_number (member_number),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        "family_members" => "
            CREATE TABLE IF NOT EXISTS family_members (
                id INT AUTO_INCREMENT PRIMARY KEY,
                member_id INT NOT NULL,
                family_type ENUM('own_family', 'wife_family') NOT NULL,
                relationship ENUM('father', 'mother', 'brother', 'sister', 'son', 'daughter', 'other') NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                age INT,
                occupation VARCHAR(100),
                phone VARCHAR(20),
                notes TEXT,
                FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
                INDEX idx_member (member_id),
                INDEX idx_family_type (family_type)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        "contributions" => "
            CREATE TABLE IF NOT EXISTS contributions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                member_id INT NOT NULL,
                contribution_date DATE NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                payment_method ENUM('cash', 'bank_transfer', 'mobile_money') NOT NULL,
                transaction_reference VARCHAR(100),
                bank_statement_path VARCHAR(255),
                received_by INT,
                status ENUM('paid', 'pending', 'overdue') DEFAULT 'pending',
                payment_month DATE NOT NULL,
                notes TEXT,
                attachment_path VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
                INDEX idx_member (member_id),
                INDEX idx_status (status),
                INDEX idx_payment_month (payment_month)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        "expenses" => "
            CREATE TABLE IF NOT EXISTS expenses (
                id INT AUTO_INCREMENT PRIMARY KEY,
                expense_date DATE NOT NULL,
                category VARCHAR(50) NOT NULL,
                description TEXT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                payment_method ENUM('cash', 'bank_transfer', 'mobile_money') NOT NULL,
                receipt_path VARCHAR(255),
                approved_by INT,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_date (expense_date),
                INDEX idx_category (category)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        "users" => "
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                role ENUM('admin', 'finance', 'registration', 'member') NOT NULL,
                member_id INT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                last_login TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL,
                INDEX idx_role (role),
                INDEX idx_username (username)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        "activity_logs" => "
            CREATE TABLE IF NOT EXISTS activity_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                action VARCHAR(100),
                details TEXT,
                ip_address VARCHAR(45),
                user_agent TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user (user_id),
                INDEX idx_action (action),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    ];
    
    // Create each table
    foreach ($tables as $table_name => $sql) {
        try {
            $pdo->exec($sql);
            echo "<div class='success'>✅ Table '<strong>$table_name</strong>' created successfully</div>";
        } catch (PDOException $e) {
            echo "<div class='error'>❌ Error creating table '$table_name': " . $e->getMessage() . "</div>";
        }
    }
    
    // Check if admin user exists
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE username = 'admin'");
    if ($stmt->fetchColumn() == 0) {
        // Create default users
        $users = [
            ['admin', password_hash('Admin@123', PASSWORD_DEFAULT), 'admin@welifgiea.org', 'System Administrator', 'admin'],
            ['finance', password_hash('Finance@123', PASSWORD_DEFAULT), 'finance@welifgiea.org', 'Finance Officer', 'finance'],
            ['reg', password_hash('Reg@123', PASSWORD_DEFAULT), 'reg@welifgiea.org', 'Registration Officer', 'registration'],
            ['member', password_hash('Member@123', PASSWORD_DEFAULT), 'member@welifgiea.org', 'Sample Member', 'member']
        ];
        
        $insert = $pdo->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $success = true;
        foreach ($users as $user) {
            try {
                $insert->execute($user);
                echo "<div class='success'>✅ User '<strong>{$user[0]}</strong>' created successfully</div>";
            } catch (PDOException $e) {
                echo "<div class='error'>❌ Error creating user '{$user[0]}': " . $e->getMessage() . "</div>";
                $success = false;
            }
        }
        
        if ($success) {
            echo "<div class='success'>🎉 All default users created successfully!</div>";
        }
    } else {
        echo "<div class='info'>ℹ️ Users already exist, skipping user creation.</div>";
    }
    
    // Create upload directories
    $dirs = [
        UPLOAD_PATH,
        UPLOAD_PATH . 'bank_statements/',
        UPLOAD_PATH . 'receipts/',
        UPLOAD_PATH . 'attachments/'
    ];
    
    foreach ($dirs as $dir) {
        if (!file_exists($dir)) {
            if (mkdir($dir, 0755, true)) {
                echo "<div class='success'>✅ Created directory: " . basename($dir) . "</div>";
            } else {
                echo "<div class='error'>❌ Failed to create directory: " . basename($dir) . "</div>";
            }
        } else {
            echo "<div class='info'>ℹ️ Directory already exists: " . basename($dir) . "</div>";
        }
    }
    
    echo "<h2 style='color: green; margin-top: 20px;'>✅ Installation completed successfully!</h2>";
    echo "<p>You can now:</p>";
    echo "<ul>";
    echo "<li><a href='login.php'>Login to the system</a></li>";
    echo "<li><a href='contributions.php'>View Contributions</a></li>";
    echo "<li><a href='members.php'>View Members</a></li>";
    echo "</ul>";
    
} catch (PDOException $e) {
    echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
    echo "<p>Please check your database settings in config.php</p>";
}
?>
</div>
</body>
</html>