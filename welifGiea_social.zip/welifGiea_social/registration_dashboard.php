<?php
require_once 'config.php';
requireLogin('registration');

$roleAccess = getRoleAccess($pdo);
$currentUser = getCurrentUser($pdo);

// Get registration stats
$stats = [
    'new_members_month' => $pdo->prepare("SELECT COUNT(*) FROM members WHERE MONTH(registration_date) = ? AND YEAR(registration_date) = ?")->execute([date('m'), date('Y')])->fetchColumn(),
    'total_members' => $pdo->query("SELECT COUNT(*) FROM members")->fetchColumn(),
    'total_family' => $pdo->query("SELECT COUNT(*) FROM family_members")->fetchColumn(),
    'pending_approvals' => $pdo->query("SELECT COUNT(*) FROM members WHERE status = 'pending'")->fetchColumn()
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Registration Dashboard</h1>
                <div class="user-info">
                    <span class="material-icons">app_registration</span>
                    <span>Welcome, <?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    <span class="role-badge registration">Registration Officer</span>
                </div>
            </header>
            
            <!-- Quick Actions -->
            <div style="display: flex; gap: 15px; margin-bottom: 30px;">
                <a href="add_member.php" class="btn btn-primary">
                    <span class="material-icons">person_add</span> Register New Member
                </a>
                <a href="members.php" class="btn btn-secondary">
                    <span class="material-icons">list</span> Manage Members
                </a>
                <a href="family.php" class="btn btn-secondary">
                    <span class="material-icons">family_restroom</span> Family Management
                </a>
            </div>
            
            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <span class="material-icons">person_add</span>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $stats['new_members_month']; ?></h3>
                        <p>New Members This Month</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon green">
                        <span class="material-icons">people</span>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $stats['total_members']; ?></h3>
                        <p>Total Members</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon gold">
                        <span class="material-icons">family_restroom</span>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $stats['total_family']; ?></h3>
                        <p>Family Members</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon orange">
                        <span class="material-icons">pending</span>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $stats['pending_approvals']; ?></h3>
                        <p>Pending Approvals</p>
                    </div>
                </div>
            </div>
            
            <!-- Recent Registrations -->
            <div style="background: white; border-radius: 15px; padding: 20px; margin-top: 30px;">
                <h3 style="margin-bottom: 20px;">Recent Registrations</h3>
                <?php
                $recentMembers = $pdo->query("
                    SELECT m.*, COUNT(fm.id) as family_count
                    FROM members m
                    LEFT JOIN family_members fm ON m.id = fm.member_id
                    GROUP BY m.id
                    ORDER BY m.created_at DESC
                    LIMIT 10
                ")->fetchAll();
                ?>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Member #</th>
                            <th>Full Name</th>
                            <th>Registration Date</th>
                            <th>Family Members</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentMembers as $member): ?>
                        <tr>
                            <td><?php echo $member['member_number']; ?></td>
                            <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                            <td><?php echo date('M j, Y', strtotime($member['registration_date'])); ?></td>
                            <td><?php echo $member['family_count']; ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $member['status']; ?>">
                                    <?php echo ucfirst($member['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="view_member.php?id=<?php echo $member['id']; ?>" class="btn-icon">
                                    <span class="material-icons">visibility</span>
                                </a>
                                <a href="edit_member.php?id=<?php echo $member['id']; ?>" class="btn-icon">
                                    <span class="material-icons">edit</span>
                                </a>
                                <a href="add_family.php?member_id=<?php echo $member['id']; ?>" class="btn-icon">
                                    <span class="material-icons">family_restroom</span>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>