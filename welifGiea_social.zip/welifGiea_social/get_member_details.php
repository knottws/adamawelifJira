<?php
require_once 'config.php';
requireLogin();

if (!isset($_POST['member_id'])) {
    die('Member ID not provided');
}

$member_id = (int)$_POST['member_id'];
$pdo = getDB();

// Get member details
$stmt = $pdo->prepare("
    SELECT m.*, 
           COUNT(DISTINCT fm.id) as family_count,
           COUNT(DISTINCT c.id) as contribution_count,
           SUM(c.amount) as total_contributions
    FROM members m
    LEFT JOIN family_members fm ON m.id = fm.member_id
    LEFT JOIN contributions c ON m.id = c.member_id
    WHERE m.id = ?
    GROUP BY m.id
");
$stmt->execute([$member_id]);
$member = $stmt->fetch();

if (!$member) {
    die('Member not found');
}

// Get own family members
$stmt = $pdo->prepare("SELECT * FROM family_members WHERE member_id = ? AND family_type = 'own_family' ORDER BY relationship");
$stmt->execute([$member_id]);
$own_family = $stmt->fetchAll();

// Get wife's family members
$stmt = $pdo->prepare("SELECT * FROM family_members WHERE member_id = ? AND family_type = 'wife_family' ORDER BY relationship");
$stmt->execute([$member_id]);
$wife_family = $stmt->fetchAll();

// Get recent contributions
$stmt = $pdo->prepare("
    SELECT * FROM contributions 
    WHERE member_id = ? 
    ORDER BY contribution_date DESC 
    LIMIT 10
");
$stmt->execute([$member_id]);
$contributions = $stmt->fetchAll();
?>

<div style="padding: 20px;">
    <!-- Member Basic Info -->
    <div style="display: flex; align-items: center; gap: 30px; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #f0f0f0;">
        <div style="width: 100px; height: 100px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 3em;">
            <i class="fas fa-user-circle"></i>
        </div>
        <div>
            <h2 style="font-size: 2em; margin-bottom: 5px;"><?php echo htmlspecialchars($member['full_name']); ?></h2>
            <p style="color: #667eea; font-weight: 600; margin-bottom: 10px;">#<?php echo htmlspecialchars($member['member_number']); ?></p>
            <div style="display: flex; gap: 20px; color: #666;">
                <span><i class="fas fa-calendar"></i> Registered: <?php echo date('F j, Y', strtotime($member['registration_date'])); ?></span>
                <span><i class="fas <?php echo $member['status'] == 'active' ? 'fa-check-circle text-success' : 'fa-times-circle text-danger'; ?>"></i> Status: <?php echo ucfirst($member['status']); ?></span>
            </div>
        </div>
    </div>

    <!-- Contact Information -->
    <div style="margin-bottom: 30px;">
        <h3 style="margin-bottom: 15px;"><i class="fas fa-address-card"></i> Contact Information</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
            <?php if ($member['phone']): ?>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">
                <i class="fas fa-phone" style="color: #667eea;"></i>
                <strong style="margin-left: 10px;">Phone:</strong>
                <p style="margin-top: 5px;"><?php echo htmlspecialchars($member['phone']); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ($member['email']): ?>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">
                <i class="fas fa-envelope" style="color: #667eea;"></i>
                <strong style="margin-left: 10px;">Email:</strong>
                <p style="margin-top: 5px;"><?php echo htmlspecialchars($member['email']); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ($member['occupation']): ?>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">
                <i class="fas fa-briefcase" style="color: #667eea;"></i>
                <strong style="margin-left: 10px;">Occupation:</strong>
                <p style="margin-top: 5px;"><?php echo htmlspecialchars($member['occupation']); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ($member['address']): ?>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">
                <i class="fas fa-map-marker-alt" style="color: #667eea;"></i>
                <strong style="margin-left: 10px;">Address:</strong>
                <p style="margin-top: 5px;"><?php echo nl2br(htmlspecialchars($member['address'])); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Family Summary -->
    <div style="margin-bottom: 30px;">
        <h3 style="margin-bottom: 15px;"><i class="fas fa-users"></i> Family Summary</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px;">
                <div style="font-size: 2em; font-weight: 700;"><?php echo count($own_family); ?></div>
                <div>Own Family Members</div>
            </div>
            <div style="background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%); color: white; padding: 20px; border-radius: 10px;">
                <div style="font-size: 2em; font-weight: 700;"><?php echo count($wife_family); ?></div>
                <div>Wife's Family Members</div>
            </div>
            <div style="background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%); color: white; padding: 20px; border-radius: 10px;">
                <div style="font-size: 2em; font-weight: 700;"><?php echo $member['family_count']; ?></div>
                <div>Total Family Members</div>
            </div>
        </div>
    </div>

    <!-- Own Family Members -->
    <?php if (!empty($own_family)): ?>
    <div style="margin-bottom: 30px;">
        <h3 style="margin-bottom: 15px;"><i class="fas fa-home"></i> Own Family Members</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
            <?php foreach ($own_family as $family): ?>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <span style="background: #667eea; color: white; padding: 3px 10px; border-radius: 15px; font-size: 0.8em;">
                            <?php echo ucfirst($family['relationship']); ?>
                        </span>
                        <h4 style="margin: 10px 0 5px;"><?php echo htmlspecialchars($family['full_name']); ?></h4>
                        <?php if ($family['age']): ?>
                        <p style="color: #666; font-size: 0.9em;"><i class="fas fa-birthday-cake"></i> Age: <?php echo $family['age']; ?></p>
                        <?php endif; ?>
                        <?php if ($family['occupation']): ?>
                        <p style="color: #666; font-size: 0.9em;"><i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($family['occupation']); ?></p>
                        <?php endif; ?>
                        <?php if ($family['phone']): ?>
                        <p style="color: #666; font-size: 0.9em;"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($family['phone']); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Wife's Family Members -->
    <?php if (!empty($wife_family)): ?>
    <div style="margin-bottom: 30px;">
        <h3 style="margin-bottom: 15px;"><i class="fas fa-heart"></i> Wife's Family Members</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
            <?php foreach ($wife_family as $family): ?>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <span style="background: #e74c3c; color: white; padding: 3px 10px; border-radius: 15px; font-size: 0.8em;">
                            <?php echo ucfirst($family['relationship']); ?>
                        </span>
                        <h4 style="margin: 10px 0 5px;"><?php echo htmlspecialchars($family['full_name']); ?></h4>
                        <?php if ($family['age']): ?>
                        <p style="color: #666; font-size: 0.9em;"><i class="fas fa-birthday-cake"></i> Age: <?php echo $family['age']; ?></p>
                        <?php endif; ?>
                        <?php if ($family['occupation']): ?>
                        <p style="color: #666; font-size: 0.9em;"><i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($family['occupation']); ?></p>
                        <?php endif; ?>
                        <?php if ($family['phone']): ?>
                        <p style="color: #666; font-size: 0.9em;"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($family['phone']); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Contribution History -->
    <?php if (!empty($contributions)): ?>
    <div>
        <h3 style="margin-bottom: 15px;"><i class="fas fa-history"></i> Recent Contributions</h3>
        <div style="background: #f8f9fa; border-radius: 10px; overflow: hidden;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #e9ecef;">
                        <th style="padding: 12px; text-align: left;">Date</th>
                        <th style="padding: 12px; text-align: left;">Month</th>
                        <th style="padding: 12px; text-align: left;">Amount</th>
                        <th style="padding: 12px; text-align: left;">Method</th>
                        <th style="padding: 12px; text-align: left;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($contributions as $contribution): ?>
                    <tr style="border-top: 1px solid #dee2e6;">
                        <td style="padding: 12px;"><?php echo date('d/m/Y', strtotime($contribution['contribution_date'])); ?></td>
                        <td style="padding: 12px;"><?php echo date('F Y', strtotime($contribution['payment_month'])); ?></td>
                        <td style="padding: 12px; font-weight: 600;"><?php echo formatCurrency($contribution['amount']); ?></td>
                        <td style="padding: 12px;"><?php echo ucfirst(str_replace('_', ' ', $contribution['payment_method'])); ?></td>
                        <td style="padding: 12px;">
                            <span class="payment-status status-<?php echo $contribution['status']; ?>">
                                <?php echo ucfirst($contribution['status']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>