<?php
// users.php
require_once 'config.php';

// Check if user is logged in and has admin role
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Only admin can access user management
if ($_SESSION['user_role'] !== 'admin') {
    $_SESSION['flash_message'] = 'You do not have permission to access user management.';
    $_SESSION['flash_type'] = 'error';
    header('Location: dashboard.php');
    exit();
}

$pdo = getDB();
$message = '';
$error = '';

// Handle user actions (delete, toggle status)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token.';
    } else {
        $action = $_POST['action'];
        $user_id = (int)$_POST['user_id'];

        try {
            if ($action === 'delete' && $user_id != $_SESSION['user_id']) {
                // Don't allow deleting yourself
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role != 'admin'");
                $stmt->execute([$user_id]);
                if ($stmt->rowCount() > 0) {
                    logActivity('Delete User', "Deleted user ID: $user_id");
                    $_SESSION['flash_message'] = 'User deleted successfully.';
                    $_SESSION['flash_type'] = 'success';
                }
            } elseif ($action === 'toggle_status') {
                $stmt = $pdo->prepare("UPDATE users SET is_active = NOT is_active WHERE id = ? AND id != ?");
                $stmt->execute([$user_id, $_SESSION['user_id']]);
                logActivity('Toggle User Status', "Toggled status for user ID: $user_id");
                $_SESSION['flash_message'] = 'User status updated successfully.';
                $_SESSION['flash_type'] = 'success';
            }
        } catch (Exception $e) {
            error_log("User management error: " . $e->getMessage());
            $_SESSION['flash_message'] = 'An error occurred.';
            $_SESSION['flash_type'] = 'error';
        }
        header('Location: users.php');
        exit();
    }
}

// Get all users
$stmt = $pdo->query("SELECT u.*, 
                     (SELECT full_name FROM users WHERE id = u.created_by) as created_by_name 
                     FROM users u ORDER BY u.created_at DESC");
$users = $stmt->fetchAll();

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - WelifGiea</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .main-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: white;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 25px;
            border-bottom: 1px solid #e0e0e0;
        }

        .sidebar-header .logo {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5em;
            margin-bottom: 15px;
        }

        .sidebar-header h3 {
            color: #333;
            font-size: 1.2em;
        }

        .sidebar-header p {
            color: #666;
            font-size: 0.9em;
        }

        .nav-menu {
            padding: 20px;
        }

        .nav-item {
            list-style: none;
            margin-bottom: 5px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #666;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            gap: 10px;
        }

        .nav-link i {
            width: 20px;
            font-size: 1.1em;
        }

        .nav-link:hover, .nav-link.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .content-header {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .content-header h1 {
            color: #333;
            font-size: 1.8em;
        }

        .content-header p {
            color: #666;
            margin-top: 5px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-size: 1em;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .btn-danger {
            background: #dc2626;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            font-size: 0.9em;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-danger:hover {
            background: #b91c1c;
        }

        .btn-success {
            background: #10b981;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            font-size: 0.9em;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            font-size: 0.9em;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .users-table-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .users-table {
            width: 100%;
            border-collapse: collapse;
        }

        .users-table th {
            text-align: left;
            padding: 15px;
            color: #666;
            font-weight: 600;
            border-bottom: 2px solid #e0e0e0;
        }

        .users-table td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            color: #333;
        }

        .users-table tr:hover {
            background: #f8fafc;
        }

        .role-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 500;
        }

        .role-admin {
            background: #667eea20;
            color: #4361ee;
        }

        .role-finance {
            background: #10b98120;
            color: #059669;
        }

        .role-registration {
            background: #f59e0b20;
            color: #d97706;
        }

        .role-member {
            background: #9b59b620;
            color: #7e3f9e;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 500;
        }

        .status-active {
            background: #10b98120;
            color: #059669;
        }

        .status-inactive {
            background: #ef444420;
            color: #b91c1c;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 8px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            color: white;
            font-size: 0.9em;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 35px;
            height: 35px;
        }

        .action-btn.edit {
            background: #10b981;
        }

        .action-btn.status {
            background: #f59e0b;
        }

        .action-btn.delete {
            background: #ef4444;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            opacity: 0.9;
        }

        .action-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }

        .flash-message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .flash-success {
            background: #10b98120;
            color: #059669;
            border-left: 4px solid #10b981;
        }

        .flash-error {
            background: #ef444420;
            color: #b91c1c;
            border-left: 4px solid #ef4444;
        }

        .search-box {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            width: 300px;
            font-size: 1em;
            transition: all 0.3s ease;
        }

        .search-box:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-users-cog"></i>
                </div>
                <h3>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></h3>
                <p><i class="fas fa-shield-alt"></i> Administrator</p>
            </div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="users.php" class="nav-link active">
                        <i class="fas fa-users"></i> Users
                    </a>
                </li>
                <li class="nav-item">
                    <a href="members.php" class="nav-link">
                        <i class="fas fa-user-circle"></i> Members
                    </a>
                </li>
                <li class="nav-item">
                    <a href="contributions.php" class="nav-link">
                        <i class="fas fa-hand-holding-usd"></i> Contributions
                    </a>
                </li>
                <li class="nav-item">
                    <a href="loans.php" class="nav-link">
                        <i class="fas fa-money-bill-wave"></i> Loans
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.php" class="nav-link">
                        <i class="fas fa-user-cog"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <div>
                    <h1>User Management</h1>
                    <p>Manage system users and their permissions</p>
                </div>
                <a href="user_add.php" class="btn-primary">
                    <i class="fas fa-plus"></i> Add New User
                </a>
            </div>

            <?php echo displayFlashMessage(); ?>

            <div class="users-table-container">
                <div style="margin-bottom: 20px; display: flex; gap: 15px;">
                    <input type="text" class="search-box" id="searchInput" placeholder="Search users...">
                    <select class="search-box" id="roleFilter" style="width: auto;">
                        <option value="">All Roles</option>
                        <option value="admin">Admin</option>
                        <option value="finance">Finance</option>
                        <option value="registration">Registration</option>
                        <option value="member">Member</option>
                    </select>
                </div>

                <table class="users-table" id="usersTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Created By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td>#<?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <span class="role-badge role-<?php echo $user['role']; ?>">
                                    <i class="fas fa-<?php 
                                        echo $user['role'] === 'admin' ? 'shield-alt' : 
                                            ($user['role'] === 'finance' ? 'coins' : 
                                            ($user['role'] === 'registration' ? 'user-plus' : 'user'));
                                    ?>"></i>
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                    <i class="fas fa-<?php echo $user['is_active'] ? 'check-circle' : 'times-circle'; ?>"></i>
                                    <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?>
                            </td>
                            <td><?php echo $user['created_by_name'] ?? 'System'; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="user_edit.php?id=<?php echo $user['id']; ?>" class="action-btn edit" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    
                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to <?php echo $user['is_active'] ? 'deactivate' : 'activate'; ?> this user?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" class="action-btn status" title="<?php echo $user['is_active'] ? 'Deactivate' : 'Activate'; ?>">
                                                <i class="fas fa-<?php echo $user['is_active'] ? 'ban' : 'check'; ?>"></i>
                                            </button>
                                        </form>

                                        <?php if ($user['role'] !== 'admin'): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" class="action-btn delete" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            filterTable();
        });

        document.getElementById('roleFilter').addEventListener('change', function() {
            filterTable();
        });

        function filterTable() {
            const searchText = document.getElementById('searchInput').value.toLowerCase();
            const roleFilter = document.getElementById('roleFilter').value.toLowerCase();
            const rows = document.querySelectorAll('#usersTable tbody tr');

            rows.forEach(row => {
                const username = row.cells[1].textContent.toLowerCase();
                const fullName = row.cells[2].textContent.toLowerCase();
                const email = row.cells[3].textContent.toLowerCase();
                const role = row.cells[4].textContent.toLowerCase();
                
                const matchesSearch = username.includes(searchText) || 
                                     fullName.includes(searchText) || 
                                     email.includes(searchText);
                const matchesRole = roleFilter === '' || role.includes(roleFilter);
                
                row.style.display = matchesSearch && matchesRole ? '' : 'none';
            });
        }
    </script>
</body>
</html>