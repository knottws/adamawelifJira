<?php
/**
 * Debug Login Script
 * Use this to test database connection and user credentials
 */

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include database configuration
require_once __DIR__ . '/config.php';

echo "<h1>Login Debug Tool</h1>";

// Test database connection
echo "<h2>1. Database Connection Test</h2>";
if (isset($pdo) && $pdo instanceof PDO) {
    echo "<p style='color: green;'>✓ Database connection successful!</p>";
} else {
    echo "<p style='color: red;'>✗ Database connection failed!</p>";
    exit();
}

// Check if users table exists
echo "<h2>2. Users Table Check</h2>";
try {
    $result = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($result->rowCount() > 0) {
        echo "<p style='color: green;'>✓ Users table exists</p>";
    } else {
        echo "<p style='color: red;'>✗ Users table does not exist!</p>";
        echo "<p>Creating users table...</p>";
        
        // Create users table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                full_name VARCHAR(100),
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('admin', 'finance', 'registration', 'member') DEFAULT 'member',
                is_active TINYINT(1) DEFAULT 1,
                is_locked TINYINT(1) DEFAULT 0,
                login_attempts INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        echo "<p style='color: green;'>✓ Users table created</p>";
    }
} catch (PDOException $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

// Check for test users
echo "<h2>3. User Records</h2>";
try {
    $stmt = $pdo->query("SELECT id, username, email, role, is_active, is_locked, login_attempts FROM users");
    $users = $stmt->fetchAll();
    
    if (count($users) > 0) {
        echo "<p>Found " . count($users) . " user(s):</p>";
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Active</th><th>Locked</th><th>Login Attempts</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>" . $user['id'] . "</td>";
            echo "<td>" . htmlspecialchars($user['username']) . "</td>";
            echo "<td>" . htmlspecialchars($user['email']) . "</td>";
            echo "<td>" . $user['role'] . "</td>";
            echo "<td>" . ($user['is_active'] ? 'Yes' : 'No') . "</td>";
            echo "<td>" . ($user['is_locked'] ? 'Yes' : 'No') . "</td>";
            echo "<td>" . $user['login_attempts'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: orange;'>⚠ No users found in database!</p>";
        echo "<p>Creating default admin user...</p>";
        
        // Create default admin
        $hashed_password = password_hash('Admin@123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO users (username, full_name, email, password, role, is_active) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute(['admin', 'System Administrator', 'admin@welifgiea.org', $hashed_password, 'admin', 1]);
        
        // Create test users
        $test_users = [
            ['finance', 'Finance Officer', 'finance@welifgiea.org', 'Finance@123', 'finance'],
            ['registration', 'Registration Officer', 'registration@welifgiea.org', 'Reg@123', 'registration'],
            ['member', 'Society Member', 'member@welifgiea.org', 'Member@123', 'member']
        ];
        
        foreach ($test_users as $test_user) {
            $hashed = password_hash($test_user[3], PASSWORD_DEFAULT);
            $stmt->execute([$test_user[0], $test_user[1], $test_user[2], $hashed, $test_user[4], 1]);
        }
        
        echo "<p style='color: green;'>✓ Default users created!</p>";
    }
} catch (PDOException $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

// Test password verification
echo "<h2>4. Password Verification Test</h2>";
echo "<form method='POST' style='margin: 20px 0; padding: 20px; border: 1px solid #ccc; border-radius: 5px;'>";
echo "<h3>Test Login Credentials</h3>";
echo "<div style='margin-bottom: 10px;'>";
echo "<label>Username or Email:</label><br>";
echo "<input type='text' name='username' style='width: 300px; padding: 5px;' required>";
echo "</div>";
echo "<div style='margin-bottom: 10px;'>";
echo "<label>Password:</label><br>";
echo "<input type='text' name='password' style='width: 300px; padding: 5px;' required>";
echo "</div>";
echo "<button type='submit' style='padding: 8px 20px; background: #4CAF50; color: white; border: none; border-radius: 3px; cursor: pointer;'>Test Login</button>";
echo "</form>";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    echo "<h3>Test Results:</h3>";
    
    // Find user
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "<p style='color: green;'>✓ User found: " . htmlspecialchars($user['username']) . " (" . $user['email'] . ")</p>";
        
        // Check password
        if (password_verify($password, $user['password'])) {
            echo "<p style='color: green; font-weight: bold;'>✓ Password CORRECT!</p>";
            
            // Show password info
            echo "<p>Password hash: " . $user['password'] . "</p>";
            
            // Check if rehash needed
            if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
                echo "<p style='color: orange;'>⚠ Password needs rehashing</p>";
                $new_hash = password_hash($password, PASSWORD_DEFAULT);
                echo "<p>New hash would be: " . $new_hash . "</p>";
            }
        } else {
            echo "<p style='color: red; font-weight: bold;'>✗ Password INCORRECT!</p>";
            
            // Show what the hash should be for this password
            $correct_hash = password_hash($password, PASSWORD_DEFAULT);
            echo "<p>For debugging, the correct hash for '" . htmlspecialchars($password) . "' would be:</p>";
            echo "<code style='background: #f4f4f4; padding: 10px; display: block;'>" . $correct_hash . "</code>";
            
            echo "<p>Stored hash in database:</p>";
            echo "<code style='background: #f4f4f4; padding: 10px; display: block;'>" . $user['password'] . "</code>";
        }
        
        // Check account status
        echo "<h4>Account Status:</h4>";
        echo "<ul>";
        echo "<li>Active: " . ($user['is_active'] ? 'Yes' : 'No') . "</li>";
        echo "<li>Locked: " . ($user['is_locked'] ? 'Yes' : 'No') . "</li>";
        echo "<li>Login Attempts: " . $user['login_attempts'] . "</li>";
        echo "<li>Role: " . $user['role'] . "</li>";
        echo "</ul>";
    } else {
        echo "<p style='color: red;'>✗ User not found with username/email: " . htmlspecialchars($username) . "</p>";
    }
}

// Show all users with their password hashes
echo "<h2>5. All Users (with password hashes)</h2>";
try {
    $stmt = $pdo->query("SELECT id, username, email, role, password FROM users");
    $users = $stmt->fetchAll();
    
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Password Hash</th></tr>";
    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . $user['id'] . "</td>";
        echo "<td>" . htmlspecialchars($user['username']) . "</td>";
        echo "<td>" . htmlspecialchars($user['email']) . "</td>";
        echo "<td>" . $user['role'] . "</td>";
        echo "<td><code style='font-size: 11px;'>" . $user['password'] . "</code></td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (PDOException $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

// Fix passwords if needed
echo "<h2>6. Quick Fix</h2>";
echo "<p>Click below to reset all user passwords to known values:</p>";
echo "<form method='POST'>";
echo "<input type='hidden' name='fix_passwords' value='1'>";
echo "<button type='submit' style='padding: 10px 20px; background: #ff9800; color: white; border: none; border-radius: 3px; cursor: pointer;'>Reset All Passwords</button>";
echo "</form>";

if (isset($_POST['fix_passwords'])) {
    try {
        // Reset admin password
        $admin_hash = password_hash('Admin@123', PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE username = 'admin' OR email LIKE '%admin%'")->execute([$admin_hash]);
        
        // Reset finance password
        $finance_hash = password_hash('Finance@123', PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE username = 'finance' OR email LIKE '%finance%'")->execute([$finance_hash]);
        
        // Reset registration password
        $reg_hash = password_hash('Reg@123', PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE username = 'registration' OR email LIKE '%registration%'")->execute([$reg_hash]);
        
        // Reset member password
        $member_hash = password_hash('Member@123', PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE username = 'member' OR email LIKE '%member%'")->execute([$member_hash]);
        
        echo "<p style='color: green; font-weight: bold;'>✓ All passwords have been reset!</p>";
        echo "<p>Use these credentials:</p>";
        echo "<ul>";
        echo "<li>admin@welifgiea.org / Admin@123</li>";
        echo "<li>finance@welifgiea.org / Finance@123</li>";
        echo "<li>registration@welifgiea.org / Reg@123</li>";
        echo "<li>member@welifgiea.org / Member@123</li>";
        echo "</ul>";
        
        // Redirect to refresh
        echo "<script>setTimeout(() => window.location.reload(), 3000);</script>";
    } catch (PDOException $e) {
        echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    }
}
?>