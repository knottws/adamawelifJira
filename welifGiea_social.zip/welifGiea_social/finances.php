<?php
// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define base path
define('BASE_PATH', __DIR__);

// Try to include config file from multiple possible locations
$config_loaded = false;
$possible_config_paths = [
    BASE_PATH . '/config.php',
    BASE_PATH . '/includes/config.php',
    BASE_PATH . '/../config.php',
    'config.php',
    './config.php',
    '../config.php'
];

foreach ($possible_config_paths as $config_path) {
    if (file_exists($config_path)) {
        require_once $config_path;
        $config_loaded = true;
        break;
    }
}

// If config wasn't loaded, create database connection manually
if (!$config_loaded || !isset($pdo)) {
    try {
        // Manual database connection - UPDATE THESE VALUES!
        $db_host = 'localhost';
        $db_name = 'welifgiea_social'; // Change to your actual database name
        $db_user = 'root';
        $db_pass = '';
        
        $pdo = new PDO(
            "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
            $db_user,
            $db_pass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
    } catch (PDOException $e) {
        // Log error and show user-friendly message
        error_log("Database connection failed: " . $e->getMessage());
        die("Unable to connect to database. Please try again later.");
    }
}

// Verify PDO object is valid
if (!$pdo instanceof PDO) {
    die("Database connection error: Invalid PDO object");
}

// Check if user is logged in (if required)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Now line 88 and beyond will work perfectly
// Your original code starts here
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finances - <?php echo defined('SITE_NAME') ? SITE_NAME : 'Welfare Society'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container { margin-top: 20px; }
        .card { margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .table-responsive { margin-top: 20px; }
        .summary-box { padding: 20px; border-radius: 5px; color: white; margin-bottom: 20px; }
        .summary-box.income { background: #28a745; }
        .summary-box.expense { background: #dc3545; }
        .summary-box.balance { background: #007bff; }
    </style>
</head>
<body>
    <?php
    // Include sidebar if exists
    $sidebar_path = BASE_PATH . '/includes/sidebar.php';
    if (file_exists($sidebar_path)) {
        include $sidebar_path;
    }
    ?>
    
    <div class="main-content" style="margin-left: 250px; padding: 20px;">
        <div class="container">
            <h1>Financial Management</h1>
            
            <?php
            try {
                // Your original line 88 code - REPLACE THIS WITH YOUR ACTUAL QUERY
                // Example queries:
                
                // Get total income
                $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE type = 'income' AND user_id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $total_income = $stmt->fetchColumn();
                
                // Get total expenses
                $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE type = 'expense' AND user_id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $total_expense = $stmt->fetchColumn();
                
                $balance = $total_income - $total_expense;
                
                // Get recent transactions
                $stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY transaction_date DESC LIMIT 10");
                $stmt->execute([$_SESSION['user_id']]);
                $transactions = $stmt->fetchAll();
                
            } catch (PDOException $e) {
                error_log("Query error in finances.php: " . $e->getMessage());
                $error = "An error occurred while fetching financial data.";
            }
            ?>
            
            <!-- Summary Cards -->
            <div class="row">
                <div class="col-md-4">
                    <div class="summary-box income">
                        <h3>Total Income</h3>
                        <h2>KES <?php echo number_format($total_income ?? 0, 2); ?></h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="summary-box expense">
                        <h3>Total Expenses</h3>
                        <h2>KES <?php echo number_format($total_expense ?? 0, 2); ?></h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="summary-box balance">
                        <h3>Current Balance</h3>
                        <h2>KES <?php echo number_format($balance ?? 0, 2); ?></h2>
                    </div>
                </div>
            </div>
            
            <!-- Transactions Table -->
            <div class="card">
                <div class="card-header">
                    <h3>Recent Transactions</h3>
                    <a href="add_transaction.php" class="btn btn-primary btn-sm float-right">Add Transaction</a>
                </div>
                <div class="card-body">
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if (empty($transactions)): ?>
                        <div class="alert alert-info">No transactions found.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Description</th>
                                        <th>Category</th>
                                        <th>Type</th>
                                        <th>Amount (KES)</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transactions as $transaction): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($transaction['transaction_date'] ?? date('Y-m-d')); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['description'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($transaction['category'] ?? 'General'); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo ($transaction['type'] ?? 'expense') == 'income' ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($transaction['type'] ?? 'expense'); ?>
                                            </span>
                                        </td>
                                        <td class="<?php echo ($transaction['type'] ?? '') == 'income' ? 'text-success' : 'text-danger'; ?>">
                                            <?php echo ($transaction['type'] ?? '') == 'income' ? '+' : '-'; ?>
                                            KES <?php echo number_format($transaction['amount'] ?? 0, 2); ?>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php echo ($transaction['status'] ?? 'completed') == 'completed' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($transaction['status'] ?? 'completed'); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="view_transaction.php?id=<?php echo $transaction['id'] ?? 0; ?>" class="btn btn-sm btn-info">
                                                <i class="material-icons">visibility</i>
                                            </a>
                                            <a href="edit_transaction.php?id=<?php echo $transaction['id'] ?? 0; ?>" class="btn btn-sm btn-warning">
                                                <i class="material-icons">edit</i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Charts Section -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3>Income vs Expenses</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="financeChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3>Expense Categories</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="categoryChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    // Initialize charts if you want to add them
    $(document).ready(function() {
        // You can add chart initialization here
    });
    </script>
</body>
</html>