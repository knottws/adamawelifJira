<?php
require_once 'config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        // Generate member number
        $year = date('Y');
        $stmt = $pdo->query("SELECT COUNT(*) FROM members WHERE YEAR(registration_date) = $year");
        $count = $stmt->fetchColumn() + 1;
        $member_number = 'M' . $year . str_pad($count, 4, '0', STR_PAD_LEFT);
        
        // Insert member
        $stmt = $pdo->prepare("
            INSERT INTO members (member_number, full_name, phone, email, address, occupation, registration_date, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $member_number,
            $_POST['full_name'],
            $_POST['phone'],
            $_POST['email'],
            $_POST['address'],
            $_POST['occupation'],
            $_POST['registration_date'],
            $_POST['status']
        ]);
        
        $member_id = $pdo->lastInsertId();
        
        // Insert family members
        if (isset($_POST['family']) && is_array($_POST['family'])) {
            $stmt = $pdo->prepare("
                INSERT INTO family_members (member_id, family_type, relationship, full_name, age, occupation, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($_POST['family'] as $family) {
                if (!empty($family['full_name'])) {
                    $stmt->execute([
                        $member_id,
                        $family['type'],
                        $family['relationship'],
                        $family['full_name'],
                        $family['age'] ?: null,
                        $family['occupation'] ?: null,
                        $family['notes'] ?: null
                    ]);
                }
            }
        }
        
        $pdo->commit();
        header('Location: members.php?msg=added');
        exit();
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Member - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Add New Member</h1>
                <a href="members.php" class="btn btn-secondary">Back to Members</a>
            </header>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="" class="form-container">
                <div class="form-section">
                    <h2>Member Information</h2>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" id="full_name" name="full_name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email">
                        </div>
                        
                        <div class="form-group">
                            <label for="occupation">Occupation</label>
                            <input type="text" id="occupation" name="occupation">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="registration_date">Registration Date *</label>
                            <input type="date" id="registration_date" name="registration_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea id="address" name="address" rows="3"></textarea>
                    </div>
                </div>
                
                <div class="form-section">
                    <h2>Family Members</h2>
                    <p class="section-note">Add family members (parents, siblings, spouse, children)</p>
                    
                    <div id="family-members-container">
                        <!-- Family members will be added here dynamically -->
                    </div>
                    
                    <button type="button" id="add-family" class="btn btn-secondary">
                        <span class="material-icons">add</span> Add Family Member
                    </button>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Save Member</button>
                    <a href="members.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </main>
    </div>
    
    <script>
    // Template for family member form
    const familyTemplate = `
        <div class="family-member-card">
            <div class="family-header">
                <h4>Family Member</h4>
                <button type="button" class="btn-icon remove-family" onclick="this.closest('.family-member-card').remove()">
                    <span class="material-icons">close</span>
                </button>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Family Type</label>
                    <select name="family[INDEX][type]">
                        <option value="own">Own Family</option>
                        <option value="wife">Wife's Family</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Relationship</label>
                    <select name="family[INDEX][relationship]">
                        <option value="spouse">Spouse</option>
                        <option value="child">Child</option>
                        <option value="father">Father</option>
                        <option value="mother">Mother</option>
                        <option value="brother">Brother</option>
                        <option value="sister">Sister</option>
                        <option value="other">Other</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="family[INDEX][full_name]" required>
                </div>
                <div class="form-group">
                    <label>Age</label>
                    <input type="number" name="family[INDEX][age]">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Occupation</label>
                    <input type="text" name="family[INDEX][occupation]">
                </div>
                <div class="form-group">
                    <label>Notes</label>
                    <input type="text" name="family[INDEX][notes]">
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('add-family').addEventListener('click', function() {
        const container = document.getElementById('family-members-container');
        const index = container.children.length;
        const html = familyTemplate.replace(/INDEX/g, index);
        container.insertAdjacentHTML('beforeend', html);
    });
    </script>
    
    <script src="js/script.js"></script>
</body>
</html>