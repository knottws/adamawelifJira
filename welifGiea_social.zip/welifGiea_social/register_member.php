<?php
require_once 'config.php';

// Check if user has registration role or is admin
if (!hasRole('registration') && !hasRole('admin')) {
    header('Location: dashboard.php');
    exit();
}

$pdo = getDB();
$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        // Generate member number
        $year = date('Y');
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM members WHERE YEAR(registration_date) = $year");
        $count = $stmt->fetch()['count'] + 1;
        $member_number = 'MEM' . $year . str_pad($count, 4, '0', STR_PAD_LEFT);
        
        // Insert main member
        $stmt = $pdo->prepare("
            INSERT INTO members (
                member_number, full_name, phone, email, occupation, address, 
                registration_date, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $status = isset($_POST['status']) ? $_POST['status'] : 'active';
        
        $stmt->execute([
            $member_number,
            $_POST['full_name'],
            $_POST['phone'],
            $_POST['email'],
            $_POST['occupation'],
            $_POST['address'],
            $_POST['registration_date'],
            $status
        ]);
        
        $member_id = $pdo->lastInsertId();
        
        // Insert own family members
        if (!empty($_POST['own_family']) && is_array($_POST['own_family'])) {
            $family_stmt = $pdo->prepare("
                INSERT INTO family_members (
                    member_id, family_type, relationship, full_name, age, occupation, phone, notes
                ) VALUES (?, 'own_family', ?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($_POST['own_family'] as $family) {
                if (!empty($family['full_name'])) {
                    $family_stmt->execute([
                        $member_id,
                        $family['relationship'],
                        $family['full_name'],
                        !empty($family['age']) ? $family['age'] : null,
                        !empty($family['occupation']) ? $family['occupation'] : null,
                        !empty($family['phone']) ? $family['phone'] : null,
                        !empty($family['notes']) ? $family['notes'] : null
                    ]);
                }
            }
        }
        
        // Insert wife's family members
        if (!empty($_POST['wife_family']) && is_array($_POST['wife_family'])) {
            $family_stmt = $pdo->prepare("
                INSERT INTO family_members (
                    member_id, family_type, relationship, full_name, age, occupation, phone, notes
                ) VALUES (?, 'wife_family', ?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($_POST['wife_family'] as $family) {
                if (!empty($family['full_name'])) {
                    $family_stmt->execute([
                        $member_id,
                        $family['relationship'],
                        $family['full_name'],
                        !empty($family['age']) ? $family['age'] : null,
                        !empty($family['occupation']) ? $family['occupation'] : null,
                        !empty($family['phone']) ? $family['phone'] : null,
                        !empty($family['notes']) ? $family['notes'] : null
                    ]);
                }
            }
        }
        
        // Create user account for member if requested
        if (isset($_POST['create_user_account']) && $_POST['create_user_account'] == '1') {
            // Generate username from name
            $username = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $_POST['full_name'])) . $member_id;
            
            // Check if username exists
            $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $check->execute([$username]);
            if ($check->fetch()) {
                $username = $username . rand(10, 99);
            }
            
            $password = password_hash('Member@123', PASSWORD_DEFAULT);
            
            $user_stmt = $pdo->prepare("
                INSERT INTO users (username, password, email, full_name, role, member_id, is_active)
                VALUES (?, ?, ?, ?, 'member', ?, 1)
            ");
            
            $user_stmt->execute([
                $username,
                $password,
                $_POST['email'] ?: $username . '@member.welifgiea.org',
                $_POST['full_name'],
                $member_id
            ]);
        }
        
        $pdo->commit();
        $message = "Member registered successfully! Member Number: " . $member_number;
        
        // Log activity
        logActivity('Register Member', "Registered new member: {$_POST['full_name']} ({$member_number})");
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error registering member: " . $e->getMessage();
        error_log("Member registration error: " . $e->getMessage());
    }
}

// Get members for reference (if any)
$members = $pdo->query("SELECT id, member_number, full_name FROM members ORDER BY full_name LIMIT 10")->fetchAll();

// Get relationship options
$relationships = [
    'father' => 'Father',
    'mother' => 'Mother',
    'brother' => 'Brother',
    'sister' => 'Sister',
    'son' => 'Son',
    'daughter' => 'Daughter',
    'husband' => 'Husband',
    'wife' => 'Wife',
    'grandfather' => 'Grandfather',
    'grandmother' => 'Grandmother',
    'uncle' => 'Uncle',
    'aunt' => 'Aunt',
    'cousin' => 'Cousin',
    'nephew' => 'Nephew',
    'niece' => 'Niece',
    'father_in_law' => 'Father-in-Law',
    'mother_in_law' => 'Mother-in-Law',
    'brother_in_law' => 'Brother-in-Law',
    'sister_in_law' => 'Sister-in-Law',
    'other' => 'Other'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Member - WelifGiea</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f5f5f5;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5em;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 0.9em;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .menu-item i {
            width: 20px;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h1 {
            font-size: 1.8em;
            color: #333;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .logout-btn {
            padding: 8px 20px;
            background: #ff4444;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .logout-btn:hover {
            background: #cc0000;
        }

        .form-container {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .form-section {
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f0f0f0;
        }

        .form-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .section-title {
            font-size: 1.3em;
            color: #333;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: #667eea;
            font-size: 1.2em;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 0.95em;
        }

        .form-group label i {
            color: #667eea;
            margin-right: 5px;
            width: 16px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 0.95em;
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .required-field::after {
            content: "*";
            color: #e74c3c;
            margin-left: 4px;
        }

        .family-row {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            position: relative;
            border: 1px solid #e0e0e0;
        }

        .family-row-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #ccc;
        }

        .family-row-title {
            font-weight: 600;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .remove-family {
            background: none;
            border: none;
            color: #e74c3c;
            cursor: pointer;
            font-size: 1.2em;
            padding: 5px;
            transition: all 0.3s ease;
        }

        .remove-family:hover {
            transform: scale(1.1);
            color: #c0392b;
        }

        .add-family-btn {
            background: #667eea;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 0.95em;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .add-family-btn:hover {
            background: #5a67d8;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }

        .form-actions {
            display: flex;
            gap: 20px;
            justify-content: flex-end;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #f0f0f0;
        }

        .btn {
            padding: 14px 35px;
            border: none;
            border-radius: 10px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .btn-secondary {
            background: #e0e0e0;
            color: #333;
        }

        .btn-secondary:hover {
            background: #d0d0d0;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .info-text {
            color: #666;
            font-size: 0.85em;
            margin-top: 5px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            margin: 0;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            .sidebar-header h2,
            .sidebar-header p,
            .menu-item span {
                display: none;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .sidebar {
                display: none;
            }
            .form-actions {
                flex-direction: column;
            }
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>WelifGiea</h2>
                <p>Member Registration</p>
            </div>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-home"></i> <span>Dashboard</span>
                </a>
                <a href="members.php" class="menu-item">
                    <i class="fas fa-users"></i> <span>Members</span>
                </a>
                <a href="register_member.php" class="menu-item active">
                    <i class="fas fa-user-plus"></i> <span>Register Member</span>
                </a>
                <?php if (hasRole('finance') || hasRole('admin')): ?>
                <a href="finance_dashboard.php" class="menu-item">
                    <i class="fas fa-chart-line"></i> <span>Finance</span>
                </a>
                <a href="contributions.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i> <span>Contributions</span>
                </a>
                <?php endif; ?>
                <a href="reports.php" class="menu-item">
                    <i class="fas fa-file-alt"></i> <span>Reports</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1><i class="fas fa-user-plus"></i> Register New Member</h1>
                <div class="user-info">
                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" id="registrationForm">
                    <!-- Main Member Information -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-user-circle"></i>
                            Main Member Information
                        </h2>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="required-field">
                                    <i class="fas fa-user"></i> Full Name
                                </label>
                                <input type="text" name="full_name" required 
                                       placeholder="Enter full name"
                                       value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                            </div>

                            <div class="form-group">
                                <label class="required-field">
                                    <i class="fas fa-phone"></i> Phone Number
                                </label>
                                <input type="tel" name="phone" required 
                                       placeholder="Enter phone number"
                                       value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                            </div>

                            <div class="form-group">
                                <label>
                                    <i class="fas fa-envelope"></i> Email
                                </label>
                                <input type="email" name="email" 
                                       placeholder="Enter email address"
                                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                            </div>

                            <div class="form-group">
                                <label>
                                    <i class="fas fa-briefcase"></i> Occupation
                                </label>
                                <input type="text" name="occupation" 
                                       placeholder="Enter occupation"
                                       value="<?php echo isset($_POST['occupation']) ? htmlspecialchars($_POST['occupation']) : ''; ?>">
                            </div>

                            <div class="form-group">
                                <label class="required-field">
                                    <i class="fas fa-calendar"></i> Registration Date
                                </label>
                                <input type="date" name="registration_date" 
                                       value="<?php echo isset($_POST['registration_date']) ? $_POST['registration_date'] : date('Y-m-d'); ?>" 
                                       required>
                            </div>

                            <div class="form-group">
                                <label>
                                    <i class="fas fa-toggle-on"></i> Status
                                </label>
                                <select name="status">
                                    <option value="active" selected>Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>

                            <div class="form-group" style="grid-column: span 2;">
                                <label>
                                    <i class="fas fa-map-marker-alt"></i> Address
                                </label>
                                <textarea name="address" rows="3" placeholder="Enter full address"><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
                            </div>

                            <div class="form-group checkbox-group">
                                <input type="checkbox" name="create_user_account" id="create_user_account" value="1" checked>
                                <label for="create_user_account">
                                    <i class="fas fa-user-circle"></i> Create user account for member
                                </label>
                                <div class="info-text">Member can login with auto-generated username and password 'Member@123'</div>
                            </div>
                        </div>
                    </div>

                    <!-- Own Family Section -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-home"></i>
                            Member's Own Family
                        </h2>
                        
                        <div id="own-family-container">
                            <!-- Own family members will be added here via JavaScript -->
                        </div>
                        
                        <button type="button" class="add-family-btn" onclick="addFamilyMember('own')">
                            <i class="fas fa-plus-circle"></i>
                            Add Own Family Member
                        </button>
                    </div>

                    <!-- Wife's Family Section -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-heart"></i>
                            Wife's Family
                        </h2>
                        
                        <div id="wife-family-container">
                            <!-- Wife's family members will be added here via JavaScript -->
                        </div>
                        
                        <button type="button" class="add-family-btn" onclick="addFamilyMember('wife')">
                            <i class="fas fa-plus-circle"></i>
                            Add Wife's Family Member
                        </button>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='members.php'">
                            <i class="fas fa-times"></i>
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            Register Member
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        let ownFamilyCount = 0;
        let wifeFamilyCount = 0;

        // Relationship options from PHP
        const relationships = <?php echo json_encode($relationships); ?>;

        function addFamilyMember(type) {
            const container = document.getElementById(type + '-family-container');
            const index = type === 'own' ? ownFamilyCount++ : wifeFamilyCount++;
            
            // Create family row
            const row = document.createElement('div');
            row.className = 'family-row';
            row.innerHTML = `
                <div class="family-row-header">
                    <span class="family-row-title">
                        <i class="fas fa-user-friends"></i>
                        ${type === 'own' ? 'Own' : "Wife's"} Family Member #${index + 1}
                    </span>
                    <button type="button" class="remove-family" onclick="this.closest('.family-row').remove()">
                        <i class="fas fa-times-circle"></i>
                    </button>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label class="required-field">Full Name</label>
                        <input type="text" name="${type}_family[${index}][full_name]" required placeholder="Enter full name">
                    </div>
                    <div class="form-group">
                        <label class="required-field">Relationship</label>
                        <select name="${type}_family[${index}][relationship]" required>
                            <option value="">Select Relationship</option>
                            ${Object.entries(relationships).map(([key, value]) => 
                                `<option value="${key}">${value}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Age</label>
                        <input type="number" name="${type}_family[${index}][age]" placeholder="Age" min="0" max="120">
                    </div>
                    <div class="form-group">
                        <label>Occupation</label>
                        <input type="text" name="${type}_family[${index}][occupation]" placeholder="Occupation">
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" name="${type}_family[${index}][phone]" placeholder="Phone number">
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Notes</label>
                        <textarea name="${type}_family[${index}][notes]" rows="2" placeholder="Additional notes..."></textarea>
                    </div>
                </div>
            `;
            
            container.appendChild(row);
        }

        // Form validation
        document.getElementById('registrationForm').addEventListener('submit', function(e) {
            const fullName = document.querySelector('input[name="full_name"]').value.trim();
            const phone = document.querySelector('input[name="phone"]').value.trim();
            
            if (!fullName) {
                e.preventDefault();
                alert('Please enter member full name');
                return false;
            }
            
            if (!phone) {
                e.preventDefault();
                alert('Please enter phone number');
                return false;
            }
            
            // Validate family members
            const familyRows = document.querySelectorAll('.family-row');
            for (let row of familyRows) {
                const nameInput = row.querySelector('input[type="text"][name*="[full_name]"]');
                const relationSelect = row.querySelector('select[name*="[relationship]"]');
                
                if (nameInput && !nameInput.value.trim()) {
                    e.preventDefault();
                    alert('Please enter family member name');
                    nameInput.focus();
                    return false;
                }
                
                if (relationSelect && !relationSelect.value) {
                    e.preventDefault();
                    alert('Please select relationship for family member');
                    relationSelect.focus();
                    return false;
                }
            }
        });

        // Optional: Add one empty row for each family type by default
        window.onload = function() {
            // Uncomment these lines if you want default empty rows
            // addFamilyMember('own');
            // addFamilyMember('wife');
        };
    </script>
</body>
</html>